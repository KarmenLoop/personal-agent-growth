# Review correction

The anticipated soft-limit timestamp concern came from an older apply snippet. Current source db6f16b239c69cb01bec4722edc631fbbeb12d3c1a10278c89bab2506b942ea9 already freezes after revision increment. The additional 998-event and 1000-event late-read assertions passed in a fresh process with unchanged source. Files originally named capacity-soft-stop-red actually contain exit 0 and four passing tests; identical copies now have green names. This is not a newly reproduced defect and is not counted as a red test.
