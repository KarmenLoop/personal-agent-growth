# Operator recovery drill: common task

Create a useful English operator runbook and portable Python drill for resuming a Personal Agent Growth adaptive run when an action outcome or observation receipt is uncertain. Read the actual current helper contract. Explain how the operator distinguishes no pending action, awaiting observation, needs reconciliation, delivered, and exhausted limits; what evidence permits continuation; and when a user decision is necessary.

Actually exercise a local controlled scenario with a real file effect: preserve the same pending start while its outcome is unknown, inspect the actual effect, settle it without repeating the effect, and reject an observation carrying another start token. Do not claim a production incident, native wakeup, human training outcome or real loss of infrastructure. Controlled loss/unknown setup must be labeled. Keep all failures.

Deliver a concise runbook, a script accepting --skill and --work (fresh directory), exact command/output receipts and a self-check with honest scope. Artifact acceptance: executable recovery drill; unique-start binding; no duplicate file effect; original unknown and rejection preserved; usable operator decisions and explicit evidence limits. These criteria are fixed for all arms. Do not silently change them to match output.

Use Python 3.11+ standard library. No external accounts or production changes. Do not edit the repository. Record real intake/end and preparation/execution/review time where available, unknown native tokens/USD as null. Use one own adaptive_learning run in shared memory for the actual Agent work, not just the controlled drill. Deliver only after root independently reviews actual files.
