# Predeclared Propose–Probe–Compose comparison

Recorded before dispatching any operations arm. All arms receive the common task and same final helper implementations. Each arm is a fresh real host Agent with the inherited default model configuration; backend weight identity and native billing are unavailable.

## Baseline

Use current technical source/docs and task-driven planning. Do not load the new mechanism experience library. This isolates the added experience-use guidance, not model knowledge.

## General candidate

Save initial task judgment, retrieve experience by problem structure/mechanism from the same shared Markdown root, read original scope and counterexamples, map differences, then decide what to adapt or reject. Read the prior instructional-design task context and latest node before continuing. Test whether evidence changes the recovery runbook.

## Domain candidate

Use the same technical sources without mechanism-library retrieval. Add operations-specific diagnosis: separate observed external effect, durable receipt and intended next action; define a decision table before implementation; validate a non-repeating recovery drill. This tests a domain planning change separately from general experience retrieval.

## Evaluation and composition

Root reviews full usable artifacts against the fixed common acceptance, checks actual drill receipts and sampled reproduction, records failures, actual elapsed and unavailable cost. One run per arm is exploratory; it cannot qualify a statistical speed claim or bypass the existing comparator's repeat/quality/cost gates. If combining changed components, run the composition; otherwise retain the unchanged reviewed candidate with explicit provenance. No automatic promotion to a globally better policy from these three examples. A later held-out task is still required for generality.
