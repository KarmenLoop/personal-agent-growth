---
{
  "task_id": "ops-general",
  "state": "delivered",
  "revision": 12,
  "at": "2026-11-03T14:52:17.398614+00:00",
  "next_condition": "A distinct authorized recovery task or held-out probe; no wakeup registered."
}
---
Read context.md, cold-judgment.json, transfer-mapping.md, review-correction.md, transfer-use-feedback.md, task-timing.json, root review, and actual run status before reuse. Query the same-root mechanism library; new lesson remains a hypothesis. The original failure was a test-attribution defect: exit 2 came from a stale revision, not pending. Final script checks both exact diagnostics. Root and author both found the defect during review; discovery priority is not established.
