---
{
  "id": "ops-general-rejection-cause-binding",
  "type": "mechanism-experience",
  "source_task_id": "ops-general",
  "domain": "operations-probe-design",
  "problem_structure": [
    "changing-evidence",
    "stale-plan",
    "uncertain-external-effect"
  ],
  "mechanisms": [
    "evidence-binding",
    "recorder-executor-separation",
    "rejection-cause-binding"
  ],
  "required_conditions": {
    "target-artifact-can-be-revised": true,
    "raw-rejection-diagnostic-available": true
  },
  "exceptions": [
    "Only a controlled local file-effect recovery drill and current helper were reviewed; no production incident or arbitrary provider exactly-once claim.",
    "The original negative probe returned a true rejection for the wrong reason; executable success alone was insufficient.",
    "Cold judgment already anticipated nonrepetition and token binding. Actual retrieval influence is narrower than causal improvement.",
    "Root and author both reported the attribution defect during review; discovery priority is not established.",
    "One exploratory arm and local reproduction do not establish cross-domain strategy superiority, human learning, native scheduling, or global policy adoption."
  ],
  "intervention": "Before attributing a negative recovery probe to a guard, satisfy preceding prerequisites, retain exact stderr and exit status, assert the intended diagnostic, then independently review operator advice.",
  "explanation": "The original pending-plan probe had based_on_revision 0 at current revision 3 and hit the stale-plan gate. A preserved revised script used a valid current proposal and verified the actual pending-action gate plus exact foreign-token rejection. A single real file effect was inspected and reconciled under its original start without repetition.",
  "validation": "hypothesis",
  "executor": "/root/operations_general",
  "reviewer": "root",
  "artifacts": [
    {
      "path": "operations-experiment/general/transfer-use-feedback.md",
      "sha256": "b37ff31cab0fa772476cdc7ff5e53ebd9f76a974ffe0c7e639b3e847636de941"
    },
    {
      "path": "operations-experiment/general/review-correction.md",
      "sha256": "78666bec09ec1b70859b35583d2d7d08badfda780e309342919993f73c64b934"
    },
    {
      "path": "operations-experiment/general/drill-01/receipts/05-replan-while-unknown-rejected/stderr.txt",
      "sha256": "a56b4921a6dbd28698e87b55f481935c37769b1f1b85c2bc681d399b0613be01"
    },
    {
      "path": "operations-experiment/general/drill-reviewed/summary.json",
      "sha256": "f46b4e97fc335968297cafbe594adc0042b0e19620b93c919173fd0ca347cfbb"
    },
    {
      "path": "operations-experiment/general/recovery_drill.reviewed.py",
      "sha256": "b8982d297e796d6ce25ced2eb7e3d28c518a9d9cb2db53723cb0f03cd5f6f6c3"
    },
    {
      "path": "operations-experiment/review-general/review.md",
      "sha256": "d09894cba8977e1058b5d2d061980e99c7806662537e9b23627cb7d62e26e757"
    },
    {
      "path": "experience/mechanism/instruction-vocabulary-role-boundaries/experience.md",
      "sha256": "19969fc0b1e60bc010892a5910bbe2941e0db32802f4a629bc6a8f07e11279dd"
    }
  ]
}
---
Derived from the actual instructional-design mechanism, mapped into a distinct operator recovery task. Original source, counterexample, cold judgment, and rejected attempt are retained. Transfer-use outcome: inconclusive for causal benefit. Narrow local artifact acceptance is independently reviewed; this mechanism explanation remains a hypothesis. Future probe: a distinct recovery scenario with independently reviewed guard attribution and uncertain external effects, without replacing prior acceptance criteria.
