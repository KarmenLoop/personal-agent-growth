# Review correction: reject for the intended reason

The root independently reviewed the complete script and identified the same defect as the author's raw-diagnostic inspection: the original pending-replan probe reused a plan with based_on_revision 0 while current revision was 3. Its exit 2 was real, but the diagnostic was Stale plan revision. It did not isolate pending-action refusal. This is a defect in the probe's attribution, not a helper product defect, and does not invalidate the original foreign-token and single-file-effect checks.

Original script, runbook, observation and all drill-01 and relocation receipts are preserved. The reviewed script writes a structurally valid new proposal based_on_revision 3 and asserts the exact Run cannot accept a new plan error. It also requires the exact Observation does not match the pending start token error for the foreign-token check. A fresh drill-reviewed run returned exit 0, ten successful helper calls and two expected rejections. One original file effect remained unchanged and the same pending start was settled.

Hypothesis change: a negative exit code does not identify which safeguard was exercised. Recovery probes must satisfy preceding prerequisites and bind the rejection diagnostic as well as exit status. This extends the prior instructional counterexample (successful execution did not establish semantic accuracy) into an operations test-design candidate. It still does not establish causal improvement from retrieval: the cold plan already contained nonrepetition and token checks, and both direct inspection and root review found this defect.

Final delivery remains gated on root reading the revised files and its actual review artifact.
