# Draft self-check

Actual drill-01: twelve CLI calls; ten exit 0 and two expected exit 2. Original unknown remains in event 000003; successful settlement is event 000004. Main run starts exactly one action and writes exactly one JSONL row. Before/after effect hashes match. Foreign token rejection leaves revision 3 and original pending unchanged. Controlled no-effect foreign fixture ends with a preserved failed observation, not an invented delivery.

Executable recovery, token binding, nonrepetition, and preserved original records are covered by actual drill assertions and receipts. Operator decisions are drafted from actual source and await root's independent semantic review. Delivered state and corruption are source-based explanation only. Native cost remains null; this trial does not prove causal benefit of experience retrieval.

Source notice: parent reported a concurrent journal-inventory fix before drill execution. Execution receipts record the actual post-fix helper hash. Earlier read had no hash recorded and is not represented as frozen-source verification. Early local helper calls used default Python bytecode settings; later calls explicitly use -B. No source/Git edits were intentionally made; possible interpreter cache activity is not source modification evidence.
