---
{
  "id": "foreign-token-observation",
  "type": "learning-observation",
  "start_id": "start-902850ef2f85f940ddfdfa82",
  "action_id": "write-once",
  "outcome": "unknown",
  "finding": "This token belongs to another controlled run.",
  "hypothesis_change": "Inspect the actual effect before deciding whether anything may run again.",
  "resolved_questions": [],
  "artifacts": [],
  "executor": "controlled-drill-host",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Controlled local drill.
