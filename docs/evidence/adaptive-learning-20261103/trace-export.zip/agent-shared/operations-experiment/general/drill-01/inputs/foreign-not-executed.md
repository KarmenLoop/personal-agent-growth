---
{
  "id": "foreign-not-executed",
  "type": "learning-observation",
  "start_id": "start-ebab02e7585f7a80a6a50dea",
  "action_id": "write-once",
  "outcome": "failed",
  "finding": "Token fixture only; external action was deliberately not executed.",
  "hypothesis_change": "Inspect the actual effect before deciding whether anything may run again.",
  "resolved_questions": [],
  "artifacts": [
    {
      "path": "foreign-no-effect.txt",
      "sha256": "988d1e65650f329b9db01cfb920a959d2f16285a944106c0f1c1c83f37f16149"
    }
  ],
  "executor": "controlled-drill-host",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Controlled local drill.
