---
{
  "id": "foreign-token",
  "type": "learning-request",
  "goal": "Reconcile one controlled file effect without repeating it",
  "domain": "operations-drill",
  "acceptance": [
    "single effect reconciled"
  ],
  "budget_seconds": 300,
  "max_actions": 1,
  "allowed_actions": [
    "tool"
  ]
}
---
Controlled local drill.
