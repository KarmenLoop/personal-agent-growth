---
{
  "id": "recovery-plan",
  "type": "learning-plan",
  "based_on_revision": 0,
  "unknowns": [
    {
      "id": "effect",
      "question": "Did the single intended file effect occur?",
      "importance": 1
    }
  ],
  "actions": [
    {
      "id": "write-once",
      "kind": "tool",
      "question_ids": [
        "effect"
      ],
      "description": "Host writes one local effect with its start token",
      "expected_information_gain": 1,
      "estimated_seconds": 1,
      "preconditions": []
    }
  ],
  "experience_refs": [],
  "artifacts": []
}
---
Controlled local drill.
