---
{
  "id": "drill-observed",
  "type": "learning-observation",
  "start_id": "start-f515f9a8032cb6f62afc4d69",
  "action_id": "build-drill",
  "outcome": "progress",
  "finding": "Wrote a new operator recovery runbook and ran controlled real-file recovery. Twelve CLI calls: ten exit 0 and two expected exit 2. Same pending start retained, foreign token refused, one effect unchanged, original reconciled.",
  "hypothesis_change": "Technical behavior supports the local drill; wording and actual usefulness require independent root review.",
  "resolved_questions": [
    "drill"
  ],
  "artifacts": [
    {
      "path": "operations-experiment/general/recovery_drill.py",
      "sha256": "39bce0e210300d6f4d1ce3d7c36903042c700b8881ee9229aacfefc7c4368657"
    },
    {
      "path": "operations-experiment/general/RUNBOOK.md",
      "sha256": "35b3b6c6055252e198d38d50b1f25312602c6552d321de6e0202a7e6134a6fd9"
    },
    {
      "path": "operations-experiment/general/drill-01/summary.json",
      "sha256": "b13932b5d0353de639a7e5424d492b608a216b49f1b16b2d39c59b8b5e380148"
    }
  ],
  "executor": "/root/operations_general",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---

