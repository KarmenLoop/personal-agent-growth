---
{
  "id": "build-recovery",
  "type": "learning-plan",
  "based_on_revision": 3,
  "unknowns": [
    {
      "id": "drill",
      "question": "Will a portable real-file drill reconcile the original unknown start and reject a foreign token without repeating its effect?",
      "importance": 1
    }
  ],
  "actions": [
    {
      "id": "build-drill",
      "kind": "experiment",
      "question_ids": [
        "drill"
      ],
      "description": "Write operator runbook and a new controlled recovery drill, execute and inspect actual receipts",
      "expected_information_gain": 1,
      "estimated_seconds": 180,
      "preconditions": []
    }
  ],
  "experience_refs": [
    {
      "path": "experience/mechanism/instruction-vocabulary-role-boundaries/experience.md",
      "sha256": "19969fc0b1e60bc010892a5910bbe2941e0db32802f4a629bc6a8f07e11279dd",
      "revision": 0,
      "head_sha256": "19969fc0b1e60bc010892a5910bbe2941e0db32802f4a629bc6a8f07e11279dd"
    }
  ],
  "artifacts": [
    {
      "path": "operations-experiment/general/transfer-mapping.md",
      "sha256": "72cbc827d9238938ef4d1bbf02b1527a4d276081d409b62e84c5effd2c956a77"
    }
  ]
}
---

