from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,sys
ROOT=Path('$LEARNING_ROOT')
HERE=ROOT/'operations-experiment/general'
SKILL=Path('$REPO')
def now(): return datetime.now(timezone.utc).isoformat()
def write(name,data,body=''):
 p=HERE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('---\n'+json.dumps(data,indent=2)+'\n---\n'+body+'\n');return p
def call(name,helper,*args,expected=0):
 p=HERE/'receipts'/name;p.mkdir(parents=True)
 cmd=[sys.executable,'-B',str(SKILL/'scripts'/helper),*map(str,args)]
 start=now();r=subprocess.run(cmd,text=True,capture_output=True);end=now()
 (p/'stdout.txt').write_text(r.stdout);(p/'stderr.txt').write_text(r.stderr)
 (p/'receipt.json').write_text(json.dumps({'argv':cmd,'started_at':start,'ended_at':end,'exit_code':r.returncode,'expected_exit':expected,'helper_sha256':hashlib.sha256((SKILL/'scripts'/helper).read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(r.stdout.encode()).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr.encode()).hexdigest()},indent=2)+'\n')
 assert r.returncode==expected,(name,r.stderr,r.stdout)
 return json.loads(r.stdout) if r.stdout else None
def adaptive(name,command,*args,expected=0):return call(name,'adaptive_learning.py',command,'--root',ROOT,'--id','ops-general',*args,expected=expected)
def artifact(name):
 p=ROOT/name;return {'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
if __name__=='__main__':
 req=write('request.md',{'id':'ops-general','type':'learning-request','goal':'Produce and independently review a usable operator recovery runbook and a portable nonrepeating controlled file-effect recovery drill','domain':'operations','acceptance':['executable recovery drill','unique-start binding','no duplicate file effect','original unknown and rejection preserved','usable operator decisions and explicit evidence limits'],'budget_seconds':900,'max_actions':6,'allowed_actions':['retrieve','experiment','reflect','deliver']})
 adaptive('init','init','--request',req)
 plan=write('plan-1.md',{'id':'retrieve-context','type':'learning-plan','based_on_revision':0,'unknowns':[{'id':'transfer','question':'What scoped mechanism from the prior instructional task can change recovery decisions?','importance':1}],'actions':[{'id':'retrieve','kind':'retrieve','question_ids':['transfer'],'description':'Inspect actual prior run status and retrieve mechanism scope, conditions and counterexamples','expected_information_gain':0.8,'estimated_seconds':60,'preconditions':[]}],'experience_refs':[],'artifacts':[artifact('operations-experiment/general/cold-judgment.json')]})
 adaptive('plan-1','plan','--proposal',plan,'--expected-revision',0)
 adaptive('start-1','start','--action','retrieve','--expected-revision',1)
 call('instruction-status','adaptive_learning.py','status','--root',ROOT,'--id','instruction')
 q=write('query.md',{'id':'ops-general-query','type':'transfer-query','task_id':'ops-general','domain':'operations','problem_structure':['changing-evidence','stale-plan','unfamiliar-task'],'mechanisms':['evidence-binding','recorder-executor-separation'],'facts':{'explicit-label-retrieval':True,'target-artifact-can-be-revised':True,'new-evidence-available':True},'keywords':['unknown','reconciliation']},'Vocabulary explicitly aligned from the inspected prior-task mechanism; this is not semantic search.')
 r=call('retrieve','experience_transfer.py','retrieve','--root',ROOT,'--query',q,'--limit',5)
 print(json.dumps({'matched_count':r['matched_count'],'candidates':[{'id':c['id'],'eligible':c['eligible_for_probe'],'feedback':c['relevant_feedback'],'snapshot_ref':c['snapshot_ref']} for c in r['candidates']]},indent=2))
 for c in r['candidates']:call('experience-'+c['id'],'experience_transfer.py','status','--root',ROOT,'--id',c['id'])
