# General-arm evidence index

Use `RUNBOOK.reviewed.md` with `recovery_drill.reviewed.py`. The original `RUNBOOK.md` and `recovery_drill.py` are immutable earlier drafts retained for attribution.

| Evidence | Location |
| --- | --- |
| Cold judgment before experience loading | `cold-judgment.json` |
| Same-root instructional run readback | `receipts/instruction-status/` |
| Actual experience retrieval and exact source snapshots | `receipts/retrieve/`, `receipts/experience-instruction-vocabulary-role-boundaries/`, `receipts/experience-feedback-invalidates-plan/` |
| Adaptation, rejection and cold-plan overlap | `transfer-mapping.md` |
| Original controlled run and negative-test attribution defect | `drill-01/`, `review-correction.md` |
| Earlier same-host relocation run | `drill-relocated/`, `receipts/relocated-top-level/` |
| Corrected controlled run | `drill-reviewed/summary.json`, `drill-reviewed/manifest.json` |
| Complete corrected invocation, stdout, stderr, exit and hashes | `receipts/reviewed-top-level/` and `drill-reviewed/receipts/` |
| Original unknown and later same-token settlement | `drill-reviewed/memory/learning-runs/recovery/events/000003.md`, `000004.md` |
| Actual one-row effect and read-only inspection | `drill-reviewed/memory/effect.jsonl`, `drill-reviewed/effect-inspection.json` |
| Exact rejection diagnostics | `drill-reviewed/receipts/05-replan-while-unknown-rejected/stderr.txt`, `drill-reviewed/receipts/09-foreign-token-rejected/stderr.txt` |
| Agent work, separate from controlled fixtures | `../../learning-runs/ops-general/` in the same shared root |
| Runtime/source identity | `source-fingerprints.json` and individual helper receipts |

All learning-observation costs are unknown (`null`). Helper cost `known_sum: 0` must not be presented as actual free work: it sums only known increments and has nonzero unknown_count. No external account or production effect was exercised. Root review is a distinct actual task step; delivery waits for its final artifact.
