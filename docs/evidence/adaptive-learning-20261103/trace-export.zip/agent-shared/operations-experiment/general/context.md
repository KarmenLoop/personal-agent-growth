---
{
  "task_id": "ops-general",
  "state": "delivered",
  "revision": 12,
  "updated_at": "2026-11-03T14:52:17.398614+00:00"
}
---
Deliverables: RUNBOOK.reviewed.md and recovery_drill.reviewed.py. Actual root acceptance: ../review-general/review.md. Same shared root holds learning-runs/ops-general and experience/mechanism/ops-general-rejection-cause-binding. Preserve original scripts, unknown event, stale-revision misattribution, and all receipts. Cross-domain causal improvement remains inconclusive.
