---
{
  "id": "review-recovery",
  "type": "learning-plan",
  "based_on_revision": 6,
  "unknowns": [
    {
      "id": "review",
      "question": "Can the relocated drill execute and does independent root review accept the actual operator decisions and evidence limits?",
      "importance": 1
    }
  ],
  "actions": [
    {
      "id": "review-artifacts",
      "kind": "reflect",
      "question_ids": [
        "review"
      ],
      "description": "Execute a relocated standalone script and obtain actual independent root semantic review before delivery",
      "expected_information_gain": 1,
      "estimated_seconds": 120,
      "preconditions": []
    }
  ],
  "experience_refs": [
    {
      "path": "experience/mechanism/instruction-vocabulary-role-boundaries/experience.md",
      "sha256": "19969fc0b1e60bc010892a5910bbe2941e0db32802f4a629bc6a8f07e11279dd",
      "revision": 0,
      "head_sha256": "19969fc0b1e60bc010892a5910bbe2941e0db32802f4a629bc6a8f07e11279dd"
    }
  ],
  "artifacts": [
    {
      "path": "operations-experiment/general/self-check.md",
      "sha256": "bd539e611764fdc20542fd22b60b0407531f5eb0afa42fed50b0863f76a6bfe2"
    }
  ]
}
---

