---
{
  "id": "ops-general-query",
  "type": "transfer-query",
  "task_id": "ops-general",
  "domain": "operations",
  "problem_structure": [
    "changing-evidence",
    "stale-plan",
    "unfamiliar-task"
  ],
  "mechanisms": [
    "evidence-binding",
    "recorder-executor-separation"
  ],
  "facts": {
    "explicit-label-retrieval": true,
    "target-artifact-can-be-revised": true,
    "new-evidence-available": true
  },
  "keywords": [
    "unknown",
    "reconciliation"
  ]
}
---
Vocabulary explicitly aligned from the inspected prior-task mechanism; this is not semantic search.
