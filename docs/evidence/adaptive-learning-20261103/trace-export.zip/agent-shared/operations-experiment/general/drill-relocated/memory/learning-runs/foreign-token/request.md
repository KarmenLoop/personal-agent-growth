---
{
  "schema": 1,
  "type": "adaptive-run",
  "id": "foreign-token",
  "created_at": "2026-11-03T14:46:55.028126+00:00",
  "request": {
    "id": "foreign-token",
    "type": "learning-request",
    "goal": "Reconcile one controlled file effect without repeating it",
    "domain": "operations-drill",
    "acceptance": [
      "single effect reconciled"
    ],
    "budget_seconds": 300,
    "max_actions": 1,
    "allowed_actions": [
      "tool"
    ]
  }
}
---

Controlled local drill.
