---
{
  "id": "foreign-token-observation",
  "type": "learning-observation",
  "start_id": "start-c572d825f043b63c574a477e",
  "action_id": "write-once",
  "outcome": "unknown",
  "finding": "This token belongs to another controlled run.",
  "hypothesis_change": "Inspect the actual effect before deciding whether anything may run again.",
  "resolved_questions": [],
  "artifacts": [],
  "executor": "controlled-drill-host",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Controlled local drill.
