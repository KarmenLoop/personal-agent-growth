---
{
  "id": "original-unknown",
  "type": "learning-observation",
  "start_id": "start-effe35aa0dc6b952a28185cc",
  "action_id": "write-once",
  "outcome": "unknown",
  "finding": "Controlled uncertainty: outcome observation deliberately withheld pending recovery inspection.",
  "hypothesis_change": "Inspect the actual effect before deciding whether anything may run again.",
  "resolved_questions": [],
  "artifacts": [],
  "executor": "controlled-drill-host",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Controlled local drill.
