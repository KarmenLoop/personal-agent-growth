---
{
  "id": "retrieve-context",
  "type": "learning-plan",
  "based_on_revision": 0,
  "unknowns": [
    {
      "id": "transfer",
      "question": "What scoped mechanism from the prior instructional task can change recovery decisions?",
      "importance": 1
    }
  ],
  "actions": [
    {
      "id": "retrieve",
      "kind": "retrieve",
      "question_ids": [
        "transfer"
      ],
      "description": "Inspect actual prior run status and retrieve mechanism scope, conditions and counterexamples",
      "expected_information_gain": 0.8,
      "estimated_seconds": 60,
      "preconditions": []
    }
  ],
  "experience_refs": [],
  "artifacts": [
    {
      "path": "operations-experiment/general/cold-judgment.json",
      "sha256": "08815cffc9829075e8fe7ecbddc5447c093d4e89e1d42d070904ab0f3500ff19"
    }
  ]
}
---

