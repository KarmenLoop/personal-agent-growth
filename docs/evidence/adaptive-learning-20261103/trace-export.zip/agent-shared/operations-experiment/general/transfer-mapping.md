# Experience use in the operations task

Cold judgment preceded context and library loading. Actual retrieval used explicit labels observed in the prior mechanism; no semantic-search claim. The current instruction run is revision 15, delivered, pending null. Original experience and feedback snapshots were read using experience_transfer status. Both histories currently have zero feedback observations.

Selected instruction-vocabulary-role-boundaries (hypothesis, instructional-design). Its original result was a reviewed workshop and controlled helper receipts, not human learning. Conditions explicit-label-retrieval and target-artifact-can-be-revised are both true here. It warns that executable success did not prevent incorrect reconciliation wording. The source's semantic correction is the relevant counterexample.

Mapping: a learner confusing start with execution corresponds to an operator confusing a durable start receipt with the actual external effect. The revised lesson's unknown/terminal distinction corresponds to recovery branches. Adaptation: inspect actual pending start plus a separate file-effect receipt; document exactly when to preserve versus clear the pending action. Ask root for independent semantic review after executable checks. Reject the implication that a working lab demonstrates production recovery, authenticated actor identity, human learning, or globally better policy.

The second retrieved hypothesis feedback-invalidates-plan was ineligible because decision-can-be-revised was not supplied in the query. Its controlled software-validation evidence is read for provenance only; no direct activation or silent condition completion. A changed label alone is explicitly not new evidence.

Difference from cold judgment: the cold plan already included nonrepetition and token binding. Retrieval therefore cannot be credited with inventing them. It added a concrete semantic-review target: prevent blanket advice to replan after an unknown observation. It also motivates explicitly explaining recorder versus executor and the narrower evidence scope. Causal benefit remains unproved.

Disconfirmation: a reviewer finds language that repeats a possibly completed effect; another-start observation changes the journal; or an accepted file receipt cannot establish the intended effect. Any such result blocks delivery without erasing the original attempt.
