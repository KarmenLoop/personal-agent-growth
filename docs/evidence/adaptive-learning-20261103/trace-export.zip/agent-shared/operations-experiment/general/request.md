---
{
  "id": "ops-general",
  "type": "learning-request",
  "goal": "Produce and independently review a usable operator recovery runbook and a portable nonrepeating controlled file-effect recovery drill",
  "domain": "operations",
  "acceptance": [
    "executable recovery drill",
    "unique-start binding",
    "no duplicate file effect",
    "original unknown and rejection preserved",
    "usable operator decisions and explicit evidence limits"
  ],
  "budget_seconds": 900,
  "max_actions": 6,
  "allowed_actions": [
    "retrieve",
    "experiment",
    "reflect",
    "deliver"
  ]
}
---

