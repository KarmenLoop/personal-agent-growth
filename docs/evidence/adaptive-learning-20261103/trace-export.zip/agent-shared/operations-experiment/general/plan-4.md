---
{
  "id": "deliver-recovery",
  "type": "learning-plan",
  "based_on_revision": 9,
  "unknowns": [],
  "actions": [
    {
      "id": "deliver",
      "kind": "deliver",
      "question_ids": [],
      "description": "Deliver independently reviewed runbook, portable drill, preserved receipts and scoped hypothesis",
      "expected_information_gain": 1,
      "estimated_seconds": 10,
      "preconditions": []
    }
  ],
  "experience_refs": [],
  "artifacts": [
    {
      "path": "operations-experiment/review-general/review.md",
      "sha256": "d09894cba8977e1058b5d2d061980e99c7806662537e9b23627cb7d62e26e757"
    },
    {
      "path": "operations-experiment/general/self-check.reviewed.md",
      "sha256": "ac42cb79920a601fc71c4f5bc6f1469c3f25e77787ded0dc703904d85f49bdee"
    }
  ]
}
---

