---
{
  "id": "same-start-settlement",
  "type": "learning-observation",
  "start_id": "start-919e1b188e47358b29cff3fe",
  "action_id": "write-once",
  "outcome": "progress",
  "finding": "Read-only inspection found one exact token-bound file; no effect retry occurred.",
  "hypothesis_change": "Separate actual effect from durable observation; retain original start for settlement.",
  "resolved_questions": [
    "effect"
  ],
  "artifacts": [
    {
      "path": "effect.jsonl",
      "sha256": "d690dd365340b8b3348a91bf9e8345f85a35152ca74dbc70a48ce9d5fa1a7c36"
    },
    {
      "path": "inspection.json",
      "sha256": "aac12ba0303b42dc6dd9189e762bb915dcffc087bdfd9f2a60ca5086558852f0"
    }
  ],
  "executor": "controlled-drill-host",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Controlled fixture. This record does not certify production recovery or independent delivery review.
