---
{
  "id": "ops-domain-plan-1",
  "type": "learning-plan",
  "based_on_revision": 0,
  "unknowns": [
    {
      "id": "recovery",
      "question": "Can actual helper state be reconciled with one file effect and retained rejection evidence?",
      "importance": 1.0,
      "blocking": true
    }
  ],
  "actions": [
    {
      "id": "implement-drill",
      "kind": "experiment",
      "question_ids": [
        "recovery"
      ],
      "description": "Implement and execute a controlled same-start recovery drill from the decision table and actual source.",
      "expected_information_gain": 0.9,
      "estimated_seconds": 420,
      "preconditions": []
    }
  ],
  "experience_refs": [],
  "artifacts": [
    {
      "path": "operations-experiment/domain/decision-table.md",
      "sha256": "16ad51e7d91faf73ab475f190a66c34271aaf3cd44a79be51e41ad18802de2a6"
    }
  ]
}
---
If unknown permits a new start or mismatch changes the journal, preserve the failure and revise the recovery explanation. If controlled recovery succeeds, submit files to root for semantic review.
