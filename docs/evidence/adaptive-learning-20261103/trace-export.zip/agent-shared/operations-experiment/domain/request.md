---
{
  "id": "ops-domain-request",
  "type": "learning-request",
  "goal": "Deliver an evidence-based operator runbook and portable controlled non-repeating recovery drill.",
  "domain": "operations-recovery",
  "acceptance": [
    "Executable controlled recovery with a real file effect and no duplicate.",
    "Unknown state and wrong-start rejection preserved with command and hash receipts.",
    "Operator decisions distinguish effects, durable receipts and next actions, with honest scope."
  ],
  "budget_seconds": 900,
  "max_actions": 6,
  "allowed_actions": [
    "research",
    "experiment",
    "reflect",
    "deliver"
  ]
}
---
Authorized domain arm only. No mechanism-library retrieval, no other arms read, no repository edits. Native costs unavailable. Independent root review is required before delivery.
