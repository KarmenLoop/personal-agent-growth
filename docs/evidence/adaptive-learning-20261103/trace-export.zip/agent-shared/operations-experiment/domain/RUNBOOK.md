# Resume an adaptive run without repeating its effect

Use one actual learning root and the installed `scripts/adaptive_learning.py` helper. Python 3.11+ and its standard library are sufficient. The helper records decisions and observations; the host performs the action and judges evidence. A successful `start` is an intent record, not evidence that a file, message, payment, or remote operation completed.

## Establish three separate facts

Read `status` before making a change. Preserve the current revision, `pending.start_id`, action ID, start time, goal, limits, and original evidence. Independently establish: **what effect occurred**, **what observation is durable**, and **what action is now authorized**. A missing tool reply is not evidence of a missing effect. Do not repeat an uncertain operation to find out whether it happened.

```sh
python3 -B /path/to/skill/scripts/adaptive_learning.py status --root /path/to/learning --id actual-run
```

Use `py -3 -B -X utf8` with the same arguments on Windows. Substitute actual paths and IDs; do not copy the illustrative placeholders unchanged. Keep receipts and artifact paths inside the actual root. Artifact paths in input Markdown are relative to that root.

| Replayed state | Effect evidence | Durable receipt | Next action |
|---|---|---|---|
| `active`, `pending: null` | Previous effects may exist | Prior start is settled, or none was started | Use the current revision to submit a new plan and start one eligible authorized action |
| `awaiting_observation` | Not established by start alone | Start exists; terminal observation absent | Inspect actual operation evidence and settle this pending start; do not start again |
| `needs_reconciliation` | Unknown until inspection | `unknown` remains in the journal; original token remains pending | Resolve through read-only target/receipt inspection, then observe the same start |
| Pending action with `remaining_seconds: 0` or overrun | Effect still needs settlement | Pending state takes precedence over limit labels | Reconcile the existing start; expiry does not authorize another action |
| `delivered` | Accepted artifacts and review support delivery | Deliver action has a terminal observation with every acceptance check true | Stop; do not restart the old plan |
| `budget_exhausted`, `action_limit`, `plan_limit`, `journal_limit`, `paused_no_progress` | Earlier effects remain relevant | No pending action remains | Stop new work and report the concrete next condition; seek a user decision for expanded scope/budget or consequential remediation |
| Status rejects a gap, drift, or malformed record | Do not infer absence or success | Replay is not a sound basis for a new write | Preserve files and rejection; verify correct root, original evidence and journal integrity before continuing |

## Reconcile the existing start

1. Identify the operation from its original input, exact command/tool receipt, target, token or application operation ID, and timestamps. Read the actual target and any authoritative provider receipt. Preserve stdout, stderr, exit status, file contents or readback, and SHA-256 hashes. A hash binds bytes; it does not prove the content is true.
2. If the result remains unknown, append an `unknown` observation for the pending start. Leave `resolved_questions` empty. It may omit artifact references, but its finding must explain exactly what is missing. The helper keeps the pending token and prevents new plans/starts. Do not manufacture `progress` to unlock work.
3. If inspection establishes the effect and result, append a new observation with the **same** `start_id` and `action_id`, a fresh observation ID, and the latest expected revision. Choose `progress`, `failed`, or `no_progress` according to the actual result. Failure does not imply no external effect; document any partial effect explicitly. Terminal observations require real, unchanged artifact references. Resolve only questions targeted by this action and supported by evidence; failed/no-progress observations cannot resolve questions.
4. Read `status` back. Settlement clears both pending action and old plan. Keep the original unknown event. A continuation requires a fresh plan from the new revision, renewed evidence checks, available limits and existing authority. Never reuse an old queued action.

For example, the following is an input **template**, not an already supported observation. Replace every placeholder, compute hashes of actual stable artifacts, and select only a supported outcome:

```markdown
---
{
  "id": "reconciliation-unique-id",
  "type": "learning-observation",
  "start_id": "COPY-ACTUAL-PENDING-START",
  "action_id": "COPY-ACTUAL-ACTION-ID",
  "outcome": "progress",
  "finding": "Describe the observed effect, receipt, and remaining uncertainty.",
  "hypothesis_change": "Explain why inspection supports settlement without another effect.",
  "resolved_questions": [],
  "artifacts": [{"path": "evidence/actual-readback.json", "sha256": "ACTUAL-64-HEX-HASH"}],
  "executor": "actual-host-identity",
  "reviewer": null,
  "cost": {"tokens": null, "usd": null},
  "acceptance_checks": {}
}
---
Explain the limits of the evidence and preserve links to earlier uncertainty.
```

```sh
python3 -B /path/to/skill/scripts/adaptive_learning.py observe --root /path/to/learning --id actual-run --observation /path/to/settlement.md --expected-revision CURRENT_REVISION
python3 -B /path/to/skill/scripts/adaptive_learning.py status --root /path/to/learning --id actual-run
```

Exit code 2 is a rejection, not a successful write. Preserve its error. For a stale revision, re-read state before rebuilding the observation; another writer may already have settled it. For a token mismatch, do not swap tokens merely to pass validation: establish which actual action the evidence belongs to. Changed artifact bytes require investigation, not casually replacing their recorded hash. Do not edit immutable journal events to erase an unknown or rejection.

An empty target or missing file alone may not prove an operation never happened: it could have partially completed, been removed, or used a different target. Keep the uncertainty and escalate when resolving it would require unavailable authority, destructive compensation, material choice between outcomes, or more budget. Ordinary authorized read-only diagnosis does not require asking the user again. A genuinely new retry needs a settled prior start, supported justification, a fresh plan and remaining authorization; remote idempotency must come from the actual service contract, not from this helper.

## Run the controlled drill

```sh
python3 -B recovery_drill.py --skill /path/to/personal-agent-growth --work /path/to/new-recovery-drill
```

`--work` must not exist. The script never uses an existing production run. It creates a recovery fixture and a second control run that supplies a real foreign token with the same action ID. Only the recovery run invokes the file writer. The control run is intentionally left pending with no effect invocation and is confined to the fixture directory.

The script performs an exclusive-create write to `effect.jsonl`, flushes and fsyncs the file, deliberately treats acknowledgement as unconfirmed for the fixture operator, records `unknown`, exercises blocked repeat-start and foreign-token observation, and proves those rejections leave the recovery journal unchanged. A separate read-only subprocess inspects the file. Settlement reuses the original start and never calls the effect again. Exclusive creation protects the local demonstration from overwriting; it is not a guarantee of remote exactly-once execution or power-loss durability.

Inspect `self-check.json`, `inspection.json`, `effect.jsonl`, `receipts/*.json`, input Markdown, and the immutable `learning-runs/recovery` journal. Receipts contain exact argv, real UTC timestamps, elapsed subprocess time, full stdout/stderr, exit code, and source hashes. `manifest.json` hashes the retained files. The top-level drill exits 0 only when its assertions pass; expected helper rejections remain exit-2 receipts. Unexpected failures are preserved in `self-check.json` and existing receipts; rerun only into a different fresh directory after diagnosing them.

The first actual local execution retained one file line and one effect invocation, one recovery action start, the original unknown event, both expected exit-2 rejections, and final `active` state with `pending: null`. It completed the recovery fixture, not a `delivered` learning run. See `drill-execution.json` and `drill-01/self-check.json` for exact values.

## Limits and delivery

The real CLI uses the wall clock. Its budget runs from initialization, including planning and waiting inside the run; earlier setup is separate. Limits stop new work, not an already running host tool. Pending reconciliation remains allowed after expiry. Three consecutive failed/no-progress outcomes pause new work. New plans/starts stop at revision 998, unknown reports stop at 999, and final settlement can use event 1000. These limit behaviors are source-reviewed here; this short drill does not exercise expiry or journal capacity.

`delivered` requires a deliver action, no unresolved blocking questions, actual artifact hashes, every request acceptance check true, and a distinct actual reviewer. Declared identity is not authenticated by the helper, so obtain real independent review before claiming delivery. Unknown native tokens and USD remain `null`; do not report them as zero or charge the same work twice during unknown/settlement reporting. Neither helper execution nor this drill registers a wakeup.

This is one controlled local example. It does not demonstrate a production outage, process crash, infrastructure loss, human learning outcome, remote service idempotency, cross-platform execution, statistical efficiency improvement, or PPC promotion. Technical basis: `scripts/adaptive_learning.py` (`observation_check`, `halted`, `apply`, `append`), `docs/adaptive-learning.en.md`, and `references/adaptive-learning.en.md`; exact execution source hashes are in every command receipt.
