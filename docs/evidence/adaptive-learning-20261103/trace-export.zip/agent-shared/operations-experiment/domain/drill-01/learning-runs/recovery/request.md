---
{
  "schema": 1,
  "type": "adaptive-run",
  "id": "recovery",
  "created_at": "2026-11-03T14:46:05.614864+00:00",
  "request": {
    "id": "recovery-request",
    "type": "learning-request",
    "goal": "Controlled non-repeating recovery",
    "domain": "local-operations-fixture",
    "acceptance": [
      "One file effect is reconciled without repeating it."
    ],
    "budget_seconds": 180,
    "max_actions": 2,
    "allowed_actions": [
      "experiment"
    ]
  }
}
---

Controlled fixture. No production incident, native wakeup or real loss is claimed.
