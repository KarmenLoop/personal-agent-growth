---
{
  "id": "recovery-plan",
  "type": "learning-plan",
  "based_on_revision": 0,
  "unknowns": [
    {
      "id": "effect",
      "question": "Did the intended file effect occur?",
      "importance": 1.0
    }
  ],
  "actions": [
    {
      "id": "write-once",
      "kind": "experiment",
      "question_ids": [
        "effect"
      ],
      "description": "Create one token-bound file, then inspect before settling.",
      "expected_information_gain": 1.0,
      "estimated_seconds": 15,
      "preconditions": []
    }
  ],
  "experience_refs": [],
  "artifacts": []
}
---
The second run only supplies an actual foreign start token; it has no effect invocation.
