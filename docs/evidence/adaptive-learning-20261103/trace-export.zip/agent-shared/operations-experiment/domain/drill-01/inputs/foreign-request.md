---
{
  "id": "foreign-request",
  "type": "learning-request",
  "goal": "Controlled non-repeating recovery",
  "domain": "local-operations-fixture",
  "acceptance": [
    "One file effect is reconciled without repeating it."
  ],
  "budget_seconds": 180,
  "max_actions": 2,
  "allowed_actions": [
    "experiment"
  ]
}
---
Controlled fixture. No production incident, native wakeup or real loss is claimed.
