---
{
  "id": "original-unknown",
  "type": "learning-observation",
  "start_id": "start-9165d3447e37521b0900028c",
  "action_id": "write-once",
  "outcome": "unknown",
  "finding": "CONTROLLED: effect acknowledgement deliberately unconfirmed; inspect before deciding.",
  "hypothesis_change": "Separate actual effect from durable observation; retain original start for settlement.",
  "resolved_questions": [],
  "artifacts": [],
  "executor": "controlled-drill-host",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Controlled fixture. This record does not certify production recovery or independent delivery review.
