---
{
  "id": "same-start-settlement",
  "type": "learning-observation",
  "start_id": "start-9165d3447e37521b0900028c",
  "action_id": "write-once",
  "outcome": "progress",
  "finding": "Read-only inspection found one exact token-bound file; no effect retry occurred.",
  "hypothesis_change": "Separate actual effect from durable observation; retain original start for settlement.",
  "resolved_questions": [
    "effect"
  ],
  "artifacts": [
    {
      "path": "effect.jsonl",
      "sha256": "9c1eb46125e53e0ec7369714075aff56875ecc1729de1de2f0ffad686d10e877"
    },
    {
      "path": "inspection.json",
      "sha256": "c78c619b5637440ed707e0882a2d5b4d623eea348df86770958f59211a24a055"
    }
  ],
  "executor": "controlled-drill-host",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Controlled fixture. This record does not certify production recovery or independent delivery review.
