# Operational decision table — recorded before implementation

| Replayed status | Actual external effect | Durable observation | Intended next action |
|---|---|---|---|
| active; pending null | May exist from earlier action; inspect before a new effect | Last terminal observation settled its start | Plan from current revision; start once only when authorized and eligible |
| awaiting_observation | Not established merely by start receipt | Start exists; terminal receipt absent | Inspect operation evidence and settle this start; do not repeat effect |
| needs_reconciliation | Unknown until independently inspected | Original unknown observation is retained; same start remains pending | Preserve token; inspect target; append supported terminal observation for same token |
| pending plus exceeded budget | Still uncertain or partly established | Pending start survives limit | Reconcile existing action only; limit does not authorize new work |
| delivered | Must be supported by actual accepted artifacts | Delivered observation has real independent review and all checks | Stop; do not restart old plan |
| budget_exhausted / action_limit / plan_limit / journal_limit / paused_no_progress | Could include earlier completed or failed effects | No pending action remains | Stop new work; report concrete next step; request a user decision if more scope/budget or irreversible remediation is needed |
| replay rejects drift / gaps / stale revision | Do not infer absence or success | Journal cannot be trusted as a new-write basis | Preserve files and rejection; inspect correct root/revision and original hashes, no blind rewrite |

The helper records host declarations and validates binding/hashes. It does not execute effects, authenticate reviewers, determine semantic truth, terminate tools, or register wakeups. Existing authorization covers read-only inspection; ask the user only for missing authority, materially ambiguous desired result, budget expansion, or consequential remediation.

Controlled drill design: execute one exclusive-create file write through a real subprocess, deliberately treat its acknowledgement as unconfirmed for the simulated operator, retain `unknown`, reject a foreign start token with unchanged journal, inspect the actual file and settle the original start without calling the effect again. Preserve command stdout/stderr, exit codes, real timestamps and hashes. No production outage, crash, human outcome or infrastructure loss is claimed.
