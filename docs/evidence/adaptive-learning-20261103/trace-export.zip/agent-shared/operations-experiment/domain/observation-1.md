---
{
  "id": "ops-domain-observation-1",
  "type": "learning-observation",
  "start_id": "start-4ccbb5bc6b75847fdea516df",
  "action_id": "implement-drill",
  "outcome": "progress",
  "finding": "Actual controlled drill passed with one file effect, original unknown retained, two exit-2 rejections and same-start settlement. English operator runbook ready for independent review.",
  "hypothesis_change": "Effect inspection and durable journal settlement are separate operations; retained pending identity permits recovery without repeating the effect. Local evidence does not establish remote idempotency or crash durability.",
  "resolved_questions": [
    "recovery"
  ],
  "artifacts": [
    {
      "path": "operations-experiment/domain/decision-table.md",
      "sha256": "16ad51e7d91faf73ab475f190a66c34271aaf3cd44a79be51e41ad18802de2a6"
    },
    {
      "path": "operations-experiment/domain/RUNBOOK.md",
      "sha256": "d542c378a2593b7c97dcf315c91a5e64ce4d68ebacc6b37b0353755dc412ddfa"
    },
    {
      "path": "operations-experiment/domain/recovery_drill.py",
      "sha256": "017290d29cb30f4c9d79e0b15badef642b0f8241b54341df15b47568f1c15d42"
    },
    {
      "path": "operations-experiment/domain/drill-execution.json",
      "sha256": "909df70e19e2fa448ca4a232d2e031ad85a7e846948384229915357df4717951"
    },
    {
      "path": "operations-experiment/domain/drill-01/self-check.json",
      "sha256": "e851e66366c128b47f7369044ad9a0032c08369419f54598f89c34e38d8d6f43"
    },
    {
      "path": "operations-experiment/domain/drill-01/manifest.json",
      "sha256": "3635892d977af91bc065fdad37566739adfea5618692c3ac1ece79e73f429c68"
    }
  ],
  "executor": "root/operations_domain",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Actual artifacts submitted for independent root review; no delivery claimed yet.
