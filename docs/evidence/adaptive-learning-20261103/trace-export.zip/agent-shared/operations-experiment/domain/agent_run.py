import sys,json,subprocess,datetime,time,hashlib
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
SKILL=Path('$REPO')
PY='$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
label=sys.argv[1]
argv=[PY,'-B',str(SKILL/'scripts/adaptive_learning.py'),sys.argv[2],'--root',str(ROOT),'--id','ops-domain',*sys.argv[3:]]
t0=datetime.datetime.now(datetime.timezone.utc).isoformat(); mono=time.monotonic()
p=subprocess.run(argv,capture_output=True,text=True)
r={'argv':argv,'started_utc':t0,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-mono,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'source_sha256':{str(x.relative_to(SKILL)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [SKILL/'scripts/adaptive_learning.py',SKILL/'scripts/capability_ledger.py']}}
f=BASE/'agent-receipts';f.mkdir(exist_ok=True)
(f/(label+'.json')).write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2));sys.exit(p.returncode)
