---
{
  "id": "ops-domain-delivery",
  "type": "learning-observation",
  "start_id": "start-8321e270dc9ebe74bdf523da",
  "action_id": "deliver-reviewed-artifacts",
  "outcome": "delivered",
  "finding": "Actual files accepted by independent root review and fresh reproduction. Runbook, portable drill, original receipts, scope and continuation node are packaged.",
  "hypothesis_change": "Operations-specific separation supports this controlled recovery artifact; one sample does not establish statistical efficiency or general transfer.",
  "resolved_questions": [],
  "artifacts": [
    {
      "path": "operations-experiment/domain/RUNBOOK.md",
      "sha256": "d542c378a2593b7c97dcf315c91a5e64ce4d68ebacc6b37b0353755dc412ddfa"
    },
    {
      "path": "operations-experiment/domain/recovery_drill.py",
      "sha256": "017290d29cb30f4c9d79e0b15badef642b0f8241b54341df15b47568f1c15d42"
    },
    {
      "path": "operations-experiment/domain/drill-execution.json",
      "sha256": "909df70e19e2fa448ca4a232d2e031ad85a7e846948384229915357df4717951"
    },
    {
      "path": "operations-experiment/domain/drill-01/self-check.json",
      "sha256": "e851e66366c128b47f7369044ad9a0032c08369419f54598f89c34e38d8d6f43"
    },
    {
      "path": "operations-experiment/domain/receipt-audit.json",
      "sha256": "412f8f037e4307063bc8a58954bbb25712d2c9551a2821ce35228d8fcba00279"
    },
    {
      "path": "operations-experiment/domain/context.md",
      "sha256": "db0697795d4a30f4a5bb75cbffb6a5f32e7c0e18dcbe684649d2c5eb66a1e968"
    },
    {
      "path": "operations-experiment/domain/node-20261103-domain.md",
      "sha256": "8a962015ae8c809132e3aba2e90fc03a9ecd87106d0881eef34de9eb154e7cee"
    },
    {
      "path": "operations-experiment/review-domain/review.md",
      "sha256": "81cf89aed1c5893fa87b2286db2803fce36f93a1d7abf2e440d4d9fb3b68c392"
    },
    {
      "path": "operations-experiment/review-domain/receipt.json",
      "sha256": "05e062604357df77e764c78537de3ef84eff9a183e7e772ec80313f9a69e454b"
    }
  ],
  "executor": "root/operations_domain",
  "reviewer": "root",
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {
    "Executable controlled recovery with a real file effect and no duplicate.": true,
    "Unknown state and wrong-start rejection preserved with command and hash receipts.": true,
    "Operator decisions distinguish effects, durable receipts and next actions, with honest scope.": true
  }
}
---
Root independently reviewed full files and reproduced final executable before this delivery. Actual review retained under operations-experiment/review-domain.
