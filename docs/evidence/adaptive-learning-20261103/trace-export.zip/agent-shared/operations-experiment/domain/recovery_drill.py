#!/usr/bin/env python3
"""Controlled local recovery drill; Python 3.11+, standard library only.

This simulates an unconfirmed acknowledgement, not a real incident. It invokes
the supplied helper through its public CLI and writes only under a fresh --work.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import traceback


def stamp():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


class Drill:
    def __init__(self, skill, work):
        self.skill, self.work = skill.resolve(), work.resolve()
        self.helper = self.skill / "scripts/adaptive_learning.py"
        if not self.helper.is_file():
            raise ValueError("--skill must contain scripts/adaptive_learning.py")
        self.work.mkdir(parents=True, exist_ok=False)
        (self.work / "receipts").mkdir()
        (self.work / "inputs").mkdir()
        self.seq = 0
        self.sources = {str(p.relative_to(self.skill)): sha(p) for p in (
            self.helper, self.skill / "scripts/capability_ledger.py")}
        dump(self.work / "invocation.json", {
            "argv": sys.argv, "python": sys.executable, "started_utc": stamp(),
            "sources": self.sources, "drill_sha256": sha(Path(__file__)),
            "scenario": "CONTROLLED: acknowledgement intentionally unconfirmed until read-only inspection",
            "cost": {"tokens": None, "usd": None},
        })

    def document(self, name, value, body):
        path = self.work / "inputs" / (name + ".md")
        path.write_text("---\n" + json.dumps(value, indent=2) + "\n---\n" + body + "\n", encoding="utf-8")
        return path

    def command(self, label, argv, expected=0):
        self.seq += 1
        start, mono = stamp(), time.monotonic()
        p = subprocess.run(argv, capture_output=True, text=True, encoding="utf-8", timeout=90)
        receipt = {"argv": argv, "cwd": str(Path.cwd()), "started_utc": start,
                   "ended_utc": stamp(), "elapsed_seconds": time.monotonic()-mono,
                   "exit_code": p.returncode, "expected_exit_code": expected,
                   "stdout": p.stdout, "stderr": p.stderr,
                   "stdout_sha256": hashlib.sha256(p.stdout.encode()).hexdigest(),
                   "stderr_sha256": hashlib.sha256(p.stderr.encode()).hexdigest(),
                   "source_sha256": self.sources}
        dump(self.work / "receipts" / f"{self.seq:03d}-{label}.json", receipt)
        if p.returncode != expected:
            raise AssertionError(f"{label}: exit {p.returncode}, expected {expected}; receipt retained")
        return json.loads(p.stdout if expected == 0 else p.stderr)

    def cli(self, label, verb, run="recovery", expected=0, **args):
        argv = [sys.executable, "-B", str(self.helper), verb, "--root", str(self.work), "--id", run]
        for key, value in args.items():
            argv += ["--" + key.replace("_", "-"), str(value)]
        return self.command(label, argv, expected)

    def ref(self, path):
        return {"path": str(path.relative_to(self.work)), "sha256": sha(path)}

    def inventory(self):
        return {str(p.relative_to(self.work)): sha(p) for p in
                sorted((self.work / "learning-runs/recovery").rglob("*.md"))}

    def setup(self, run):
        request = self.document(run + "-request", {
            "id": run + "-request", "type": "learning-request",
            "goal": "Controlled non-repeating recovery", "domain": "local-operations-fixture",
            "acceptance": ["One file effect is reconciled without repeating it."],
            "budget_seconds": 180, "max_actions": 2, "allowed_actions": ["experiment"],
        }, "Controlled fixture. No production incident, native wakeup or real loss is claimed.")
        state = self.cli(run + "-init", "init", run, request=request)
        assert state["state"] == "active" and state["pending"] is None
        plan = self.document(run + "-plan", {
            "id": run + "-plan", "type": "learning-plan", "based_on_revision": 0,
            "unknowns": [{"id": "effect", "question": "Did the intended file effect occur?", "importance": 1.0}],
            "actions": [{"id": "write-once", "kind": "experiment", "question_ids": ["effect"],
                         "description": "Create one token-bound file, then inspect before settling.",
                         "expected_information_gain": 1.0, "estimated_seconds": 15, "preconditions": []}],
            "experience_refs": [], "artifacts": [],
        }, "The second run only supplies an actual foreign start token; it has no effect invocation.")
        self.cli(run + "-plan", "plan", run, proposal=plan, expected_revision=0)
        state = self.cli(run + "-start", "start", run, action="write-once", expected_revision=1,
                         reason="Controlled token-binding recovery exercise.")
        assert state["state"] == "awaiting_observation"
        return state["pending"]["start_id"]

    def observation(self, name, token, outcome, artifacts, resolved):
        return self.document(name, {
            "id": name, "type": "learning-observation", "start_id": token, "action_id": "write-once",
            "outcome": outcome, "finding": (
                "CONTROLLED: effect acknowledgement deliberately unconfirmed; inspect before deciding."
                if outcome == "unknown" else "Read-only inspection found one exact token-bound file; no effect retry occurred."),
            "hypothesis_change": "Separate actual effect from durable observation; retain original start for settlement.",
            "resolved_questions": resolved, "artifacts": artifacts,
            "executor": "controlled-drill-host", "reviewer": None,
            "cost": {"tokens": None, "usd": None}, "acceptance_checks": {},
        }, "Controlled fixture. This record does not certify production recovery or independent delivery review.")

    def run(self):
        original = self.setup("recovery")
        foreign = self.setup("foreign")
        assert foreign != original
        effect = self.work / "effect.jsonl"
        code = (
            "import json,os,sys; from pathlib import Path; "
            "p=Path(sys.argv[1]); f=p.open('x',encoding='utf-8'); "
            "f.write(json.dumps({'start_id':sys.argv[2],'effect':'controlled-create'})+'\\n'); "
            "f.flush(); os.fsync(f.fileno()); f.close(); "
            "print(json.dumps({'effect_created':True,'path':str(p)}))"
        )
        # A real file effect happens once. The forensic receipt is retained, while
        # the fixture operator initially treats the acknowledgement as unknown.
        self.command("actual-effect-once", [sys.executable, "-B", "-c", code, str(effect), original])
        unknown = self.observation("original-unknown", original, "unknown", [], [])
        state = self.cli("record-unknown", "observe", observation=unknown, expected_revision=2)
        assert state["state"] == "needs_reconciliation" and state["pending"]["start_id"] == original
        unknown_event = self.work / "learning-runs/recovery/events/000003.md"
        unknown_hash = sha(unknown_event)
        before = self.inventory()
        retry = self.cli("blocked-repeat-start", "start", action="write-once", expected_revision=3, expected=2)
        assert retry["status"] == "REJECT" and self.inventory() == before
        wrong = self.observation("foreign-start-observation", foreign, "unknown", [], [])
        rejected = self.cli("wrong-token-rejection", "observe", observation=wrong, expected_revision=3, expected=2)
        assert rejected["error"] == "Observation does not match the pending start token"
        assert self.inventory() == before
        state = self.cli("status-before-inspection", "status")
        assert state["pending"]["start_id"] == original and state["revision"] == 3
        inspect_code = (
            "import json,hashlib,sys; from pathlib import Path; "
            "p=Path(sys.argv[1]); b=p.read_bytes(); rows=b.decode().splitlines(); "
            "print(json.dumps({'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),"
            "'line_count':len(rows),'records':[json.loads(x) for x in rows]}))"
        )
        inspection = self.command("read-only-effect-inspection", [sys.executable, "-B", "-c", inspect_code, str(effect)])
        assert inspection["records"] == [{"start_id": original, "effect": "controlled-create"}]
        assert inspection["line_count"] == 1
        dump(self.work / "inspection.json", inspection)
        settled = self.observation("same-start-settlement", original, "progress",
                                   [self.ref(effect), self.ref(self.work / "inspection.json")], ["effect"])
        state = self.cli("same-start-settlement", "observe", observation=settled, expected_revision=3)
        assert state["state"] == "active" and state["pending"] is None
        assert state["actions_started"] == 1 and state["revision"] == 4
        assert state["last_observation"]["start_id"] == original
        assert sha(effect) == inspection["sha256"] and sha(unknown_event) == unknown_hash
        final = self.cli("final-status", "status")
        result = {
            "result": "PASS", "scope": "Controlled local file recovery only; no delivery certification or outage simulation",
            "ended_utc": stamp(), "original_start": original, "foreign_start": foreign,
            "unknown_event_sha256": unknown_hash, "effect_sha256": sha(effect), "effect_lines": 1,
            "effect_invocations": 1, "actions_started": final["actions_started"],
            "same_start_settled": True, "foreign_token_rejected": True,
            "rejected_commands_preserved": ["blocked-repeat-start", "wrong-token-rejection"],
            "journal_unchanged_on_rejections": True, "original_unknown_preserved": True,
            "final_state": final["state"], "pending": final["pending"],
            "foreign_run_scope": "Control-only pending start with no external effect; not a production task",
            "not_tested": ["process crash", "power loss durability", "remote service idempotency", "native wakeup", "human outcome", "budget expiry behavior"],
            "cost": {"tokens": None, "usd": None},
        }
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skill", required=True, type=Path)
    parser.add_argument("--work", required=True, type=Path, help="New directory; existing path is refused")
    args = parser.parse_args()
    drill = Drill(args.skill, args.work)
    try:
        result = drill.run()
    except Exception as exc:
        result = {"result": "FAIL", "ended_utc": stamp(), "error": repr(exc), "traceback": traceback.format_exc()}
    dump(drill.work / "self-check.json", result)
    dump(drill.work / "manifest.json", {str(p.relative_to(drill.work)): sha(p)
         for p in sorted(drill.work.rglob("*")) if p.is_file() and p.name != "manifest.json"})
    print(json.dumps(result, indent=2))
    return 0 if result["result"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
