# Resume an adaptive run when its outcome is uncertain

Use the existing learning root and run ID. Do not repeat an external action merely because its receipt is missing. The helper records decisions; it does not execute your action, authenticate actors, inspect an external system, or arrange a wakeup.

Before doing anything, preserve the original task, request, journal, action inputs, tool outputs, failures and external identifiers. Read the current project context and latest node in a real host continuation. Confirm authorization still covers the proposed action. Run a read-only status query against the actual root:

```sh
python3 -B "$SKILL/scripts/adaptive_learning.py" status --root "$ROOT" --id "$RUN"
```

Here `SKILL` is the repository, `ROOT` the original learning root and `RUN` the run ID. Save the complete command, exit code, stdout, stderr and UTC time. A rejected status or invalid journal is not permission to create a replacement run. Stop and investigate the saved error; do not patch journal metadata or hashes.

| Returned state | Operator decision |
| --- | --- |
| `active`, `pending: null` | No action is currently pending. Inspect `last_observation` and the durable events to learn whether the previous observation was committed. A terminal observation clears the old plan. Propose a fresh plan at the current revision; start only an eligible authorized action. |
| `awaiting_observation` | A start was recorded, but no terminal observation is recorded. Recover its exact `pending.start_id`, action ID, plan and original inputs. Determine whether the action ran before retrying anything. If the effect cannot yet be established, record `unknown` for that same start. |
| `needs_reconciliation` | An `unknown` observation preserved the same pending action. Inspect the external effect read-only and settle that original start when evidence permits. Do not plan/start a replacement action or repeat the effect to discover what happened. |
| `delivered` | The run is complete according to its recorded declarations. Read the artifacts and independent review; do not reopen it or infer production success. Delivery state itself does not authenticate the reviewer. |
| `budget_exhausted`, `action_limit`, `plan_limit`, `journal_limit` | No new work in this run. Preserve evidence and propose a concrete, newly authorized continuation if still useful. Do not edit the request to evade limits. |
| `paused_no_progress` | Three consecutive failed/no-progress observations stopped useful progress. Explain the unresolved issue and seek a changed approach or missing user decision. |

Pending states take precedence over elapsed budget/action limits. The current helper permits reconciliation of an already-started action after budget expiry; this permits recording what happened, not new external work. The journal reserves limited capacity for unknown and final reconciliation; repeated unknown records can still reach a limit. Preserve external evidence and escalate if an observation is rejected.

## Recover a receipt without repeating the action

1. Save `status`, its revision and pending start token. Check the latest durable observation first. If the original observation was already committed, do not resubmit it or replay the external effect. A lost CLI response does not imply a lost journal event.
2. Bind evidence to this exact action instance: original request/input hashes, tool invocation, target resource identity, provider transaction ID where available, and observed effect. A success string, a similarly named file, or an action ID reused in another run is insufficient. Inspect actual bytes/content or an authoritative provider record without mutation.
3. If the effect is established, write a new observation with the original pending `start_id` and `action_id`, a new observation ID, accurate outcome, finding and hypothesis change. Reference preserved, nonempty artifacts by root-relative path and SHA-256. Mark only questions this action actually resolved. `unknown`, `failed` and `no_progress` cannot resolve questions; every non-unknown outcome needs an artifact. Unknown native token usage or USD is `null`.
4. Submit at the current revision, then query status and verify the exact committed observation and cleared pending action. A revision conflict requires a fresh read, not a blind retry. If the observation response is lost, repeat step 1. Replaying the same observation is not an idempotent recovery API.

```sh
python3 -B "$SKILL/scripts/adaptive_learning.py" observe \
  --root "$ROOT" --id "$RUN" --observation "$OBSERVATION" \
  --expected-revision "$REVISION"
```

Use `unknown` while evidence remains ambiguous; keep the start pending. If authoritative evidence proves the action failed or did not progress, record that accurately and propose any retry as a new action only after settlement, within the remaining authority and limits. Do not infer absence from an unavailable or eventually consistent lookup. Ask the user when recovery requires a new permission, an irreversible repeat/compensation decision, a changed budget or acceptance criterion, or the missing business facts only they can supply. Read-only authorized diagnosis need not wait for such decisions. Never fabricate user approval to satisfy a field.

Delivery requires a `deliver` action after blocking questions are resolved, all requested acceptance checks true, artifact evidence, and a distinct actual reviewer. Actor names are unverified declarations in this helper: retain the real review receipt. A local controlled drill cannot stand in for production acceptance.

## Run the controlled drill

Python 3.11+ standard library; no accounts or repository edits. Choose a new or empty work directory outside the repository:

```sh
python3 recovery_drill.py --skill /path/to/personal-agent-growth --work /path/to/new-drill-output
```

The script creates one real local file in a child process, deliberately records its outcome as unknown before trusting the acknowledgment, and reads the effect to reconcile the original start without invoking the writer again. This is controlled uncertainty injection: the child acknowledgment is preserved, so no real infrastructure loss is claimed. A separate run supplies a genuine different start token; its action is deliberately never executed and remains pending. The wrong-token observation and attempted repeat/stale starts must fail. These expected rejections remain in raw receipts; unexpected failures remain in `failure.txt` and do not delete prior output.

Inspect `self-check.json`, `inspection.json`, `effect.jsonl`, `receipts/`, `inputs/`, `learning-runs/` and `manifest.json`. The intended recovery state ends `active` with no pending action, one start and one file record. It is not marked delivered by the script. Rerun only into another fresh directory; never clean the first run to hide a failure.

This drill validates the current local helper's token/revision/unknown behavior and a simple observed file effect. It does not prove exactly-once execution for remote providers, recovery from process crash at every instruction, fsync/power-loss durability, native scheduling, reviewer authentication, a real Agent's general learning ability, or statistical efficiency. The accompanying real host-Agent run and independent review are separate evidence.
