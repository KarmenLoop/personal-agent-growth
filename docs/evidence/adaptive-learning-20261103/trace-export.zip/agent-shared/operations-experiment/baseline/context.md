# Baseline task context

Goal: deliver a useful English operator recovery runbook and portable Python drill for an uncertain adaptive action outcome or observation receipt. This baseline uses actual current source and its adaptive-learning reference; it does not retrieve the new mechanism library or read other-arm answers.

Fixed acceptance: executable recovery drill; unique-start binding; no duplicate file effect; original unknown and rejection preserved; usable operator decisions; explicit evidence limits.

Authorized scope: own baseline directory and shared `learning-runs/ops-baseline`; source repository is read-only. Python standard library, real UTC, no production actions, no mocked model or human review. Maximum six own adaptive actions and 900 seconds; actual run used two actions. Native tokens/USD are unavailable.

The original draft, source-input hash receipt and rejected calls are immutable evidence. Root changed helper inventory counting after preparation; the actual drill and independent reproduction used the final helper. Preparation and actual hashes are retained in source-version-receipt.json.

Read latest-node.md, timing.json and actual adaptive run status before continuing. Do not replay the drill in its existing output directory. Any future correction must preserve already hash-bound artifacts, use a new version path, and retain original failures.
