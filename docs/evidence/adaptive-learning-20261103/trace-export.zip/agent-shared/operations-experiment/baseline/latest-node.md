# Baseline latest node

State: reviewed and delivered. Root read the complete runbook and drill source, then independently reproduced the drill in a fresh directory. Review is `../review-baseline/review.md`; actual reproduction command/output/exit are alongside it. No correction was requested.

The real host Agent's run `learning-runs/ops-baseline` is revision 6, delivered, no pending action, two actions started, no budget overrun. Delivery references actual reviewer `root` and the preserved review artifact. `final-status.json` and `agent-receipts/` retain readback and CLI output.

Controlled result: one actual child file write; an unknown outcome retained its original start; an observation with a genuine foreign start token rejected without changing revision; read-only file inspection settled the original action without repeating its effect. Repeat-start and stale-plan negative checks also rejected. The controlled main run ends active with no pending action; the auxiliary token donor stays pending without an executed effect, as disclosed.

No unexpected local drill failure occurred. All three expected rejections and original unknown are retained. This is one exploratory sample with unavailable native cost, not a statistical speedup, production incident, human-learning result or general policy promotion. No wakeup is registered and no further action is needed for the accepted artifact.

Useful files: RUNBOOK.md, recovery_drill.py, EVIDENCE.md, drill-01/self-check.json, timing.json and source-version-receipt.json. Future reuse remains a separate observed task.
