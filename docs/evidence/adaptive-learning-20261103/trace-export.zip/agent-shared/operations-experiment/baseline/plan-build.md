---
{
  "id": "plan-build",
  "type": "learning-plan",
  "based_on_revision": 0,
  "unknowns": [
    {
      "id": "recovery",
      "question": "Which evidence permits safe non-repeating recovery under the current contract?",
      "importance": 1
    }
  ],
  "actions": [
    {
      "id": "build",
      "kind": "experiment",
      "question_ids": [
        "recovery"
      ],
      "description": "Author source-grounded operator runbook and run the actual controlled file-effect drill.",
      "expected_information_gain": 1,
      "estimated_seconds": 300,
      "preconditions": []
    }
  ],
  "experience_refs": [],
  "artifacts": [
    {
      "path": "operations-experiment/baseline/source-inputs.json",
      "sha256": "1fdf23b5a55ed64192e2bafa09f8554f43d19fb7eb4cf4c4417ca152c39e7b25"
    }
  ]
}
---

Baseline uses current technical source, not the mechanism library.
