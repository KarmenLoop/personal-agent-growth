---
{
  "id": "plan-delivery",
  "type": "learning-plan",
  "based_on_revision": 3,
  "unknowns": [],
  "actions": [
    {
      "id": "delivery",
      "kind": "deliver",
      "question_ids": [],
      "description": "Submit actual artifacts for independent root review; deliver only after review.",
      "expected_information_gain": 1,
      "estimated_seconds": 180,
      "preconditions": []
    }
  ],
  "experience_refs": [],
  "artifacts": [
    {
      "path": "operations-experiment/baseline/RUNBOOK.md",
      "sha256": "a67ab7a1cc3039c7f9949a9aad95fb14f251b527ea3c9893d449629ac361722e"
    },
    {
      "path": "operations-experiment/baseline/recovery_drill.py",
      "sha256": "2e94fb96c8438e6c148b44da6fa88e75e430a23391e94bcf3815f3b9442b8b29"
    },
    {
      "path": "operations-experiment/baseline/drill-01/self-check.json",
      "sha256": "c0c4fc309312f95d101673f748c44034501751392d6af5fb1a7bec7294b9604d"
    }
  ]
}
---

Baseline uses current technical source, not the mechanism library.
