#!/usr/bin/env python3
"""Controlled unknown-outcome drill, Python 3.11+, standard library only.
The controller intentionally withholds trust in a completed child's acknowledgment;
this is an injected uncertainty condition, not a real lost production receipt.
"""
import argparse
import hashlib
import json
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path


def stamp():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ensure(condition, message):
    if not condition:
        raise RuntimeError(message)


class Drill:
    def __init__(self, skill, work):
        self.skill, self.work = skill, work
        self.calls = []
        (work / 'receipts').mkdir()
        (work / 'inputs').mkdir()

    def markdown(self, name, data, body):
        path = self.work / 'inputs' / (name + '.md')
        path.write_text('---\n' + json.dumps(data, indent=2) + '\n---\n\n' + body + '\n', encoding='utf-8')
        return path

    def execute(self, label, argv, expected=0):
        receipt = {'label': label, 'argv': argv, 'started_at': stamp(), 'expected_exit_code': expected}
        try:
            result = subprocess.run(argv, capture_output=True, text=True, timeout=30)
            receipt.update(exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr)
        except Exception as error:
            receipt.update(exit_code=None, error=repr(error))
            raise
        finally:
            receipt['ended_at'] = stamp()
            self.calls.append(receipt)
            (self.work / 'receipts' / f'{len(self.calls):03d}-{label}.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        ensure(result.returncode == expected, f'{label}: unexpected exit {result.returncode}; inspect retained receipt')
        return result

    def helper(self, command, run='recovery', expected=0, **kwargs):
        argv = [sys.executable, '-B', str(self.skill / 'scripts/adaptive_learning.py'), command,
                '--root', str(self.work), '--id', run]
        for key, value in kwargs.items():
            argv.extend(['--' + key.replace('_', '-'), str(value)])
        result = self.execute(run + '-' + command, argv, expected)
        return json.loads(result.stdout if expected == 0 else result.stderr)

    def setup(self, run):
        request = self.markdown(run+'-request', {
            'id':run, 'type':'learning-request', 'goal':'Controlled unique-start recovery drill',
            'domain':'local operator recovery', 'acceptance':['one effect reconciled'],
            'budget_seconds':900, 'max_actions':6, 'allowed_actions':['tool'], 'max_plans':6
        }, 'Controlled drill. No production action and no authenticated actor assertions.')
        self.helper('init', run=run, request=request)
        plan = self.markdown(run+'-plan', {
            'id':run+'-plan', 'type':'learning-plan', 'based_on_revision':0,
            'unknowns':[{'id':'effect', 'question':'Did the file effect occur?', 'importance':1}],
            'actions':[{'id':'write-effect', 'kind':'tool', 'question_ids':['effect'],
                        'description':'Create one exclusive local file associated with this start token.',
                        'expected_information_gain':1, 'estimated_seconds':10, 'preconditions':[]}],
            'experience_refs':[], 'artifacts':[]
        }, 'The foreign run is only a token donor; its action is never executed.')
        self.helper('plan', run=run, proposal=plan, expected_revision=0)
        return self.helper('start', run=run, action='write-effect', expected_revision=1,
                           reason='Controlled local file-effect exercise.')

    def observation(self, name, start_id, outcome, artifacts, resolved):
        return self.markdown(name, {
            'id':name, 'type':'learning-observation', 'start_id':start_id,
            'action_id':'write-effect', 'outcome':outcome,
            'finding':('Controlled uncertainty injection: do not yet trust the child acknowledgment; inspect the file.'
                       if outcome=='unknown' else 'Read-only inspection matched exact intended content and start token; no repeat effect.'),
            'hypothesis_change':('Outcome remains unresolved pending inspection.' if outcome=='unknown'
                                 else 'Observed file content supports one completed effect within this isolated drill.'),
            'resolved_questions':resolved, 'artifacts':artifacts,
            'executor':'controlled-drill-process', 'reviewer':None,
            'cost':{'tokens':None,'usd':None}, 'acceptance_checks':{}
        }, 'Scripted controlled drill observation, not a model judgment or independent review.')

    def run(self):
        initial = self.setup('recovery')
        token = initial['pending']['start_id']
        ensure(initial['state']=='awaiting_observation', 'Start must be pending')
        other = self.setup('foreign')
        foreign_token = other['pending']['start_id']
        ensure(token != foreign_token, 'Start tokens must be distinct')
        effect = self.work / 'effect.jsonl'
        content = json.dumps({'start_id':token, 'effect':'one local record'}, sort_keys=True)+'\n'
        # A separate real process performs the effect exactly once. Its output is retained.
        writer = self.work / 'inputs' / 'write_effect.py'
        writer.write_text("import pathlib,sys\np=pathlib.Path(sys.argv[1])\nwith p.open('x',encoding='utf-8') as f:\n f.write(sys.argv[2])\nprint('CREATED',p.name)\n", encoding='utf-8')
        self.execute('actual-file-effect', [sys.executable, '-B', str(writer), str(effect), content])
        unknown = self.observation('original-unknown', token, 'unknown', [], [])
        state = self.helper('observe', observation=unknown, expected_revision=2)
        ensure(state['state']=='needs_reconciliation' and state['pending']['start_id']==token,
               'Unknown must retain the original start')
        blocked = self.helper('start', expected=2, action='write-effect', expected_revision=3,
                              reason='Negative check: pending uncertainty must prevent repeat execution.')
        ensure(blocked['status']=='REJECT', 'A second start must reject')
        wrong = self.observation('wrong-start-token', foreign_token, 'progress',
                                 [{'path':'effect.jsonl','sha256':sha(effect)}], ['effect'])
        rejected = self.helper('observe', expected=2, observation=wrong, expected_revision=3)
        ensure(rejected['error']=='Observation does not match the pending start token', 'Wrong-token rejection reason differs')
        unchanged = self.helper('status')
        ensure(unchanged['revision']==3 and unchanged['pending']['start_id']==token,
               'Rejected observation must not mutate the journal')
        # Inspection is read-only. It checks content and binding; it never calls the writer.
        observed = effect.read_text(encoding='utf-8')
        ensure(observed==content and len(observed.splitlines())==1, 'Actual effect does not match exactly one intended record')
        before = sha(effect)
        inspection = {'inspected_at':stamp(), 'effect_sha256':before, 'record_count':1,
                      'start_id':token, 'exact_content_match':True, 'effect_write_invocations':1}
        inspect_path = self.work / 'inspection.json'
        inspect_path.write_text(json.dumps(inspection,indent=2),encoding='utf-8')
        settled = self.observation('reconciled-original-start', token, 'progress',
                                  [{'path':'effect.jsonl','sha256':before},
                                   {'path':'inspection.json','sha256':sha(inspect_path)}], ['effect'])
        final = self.helper('observe', observation=settled, expected_revision=3)
        ensure(final['state']=='active' and final['pending'] is None and final['revision']==4,
               'Reconciliation must settle without manufacturing delivery')
        ensure(sha(effect)==before, 'Reconciliation altered the effect')
        stale = self.helper('start', expected=2, action='write-effect', expected_revision=4,
                            reason='Negative check: the consumed plan must not start again.')
        ensure(stale['status']=='REJECT', 'Old plan must not start')
        final = self.helper('status')
        unknown_event = self.work / 'learning-runs/recovery/events/000003.md'
        ensure('original-unknown' in unknown_event.read_text(), 'Original unknown evidence missing')
        checks = {'unique_actual_start_tokens':token!=foreign_token,
                  'unknown_preserved_same_pending':True, 'wrong_start_rejected_without_state_change':True,
                  'repeat_start_rejected':True, 'stale_plan_rejected':True,
                  'effect_writer_invocations':sum(c['label']=='actual-file-effect' for c in self.calls),
                  'effect_record_count':1, 'effect_hash_unchanged_during_settlement':sha(effect)==before,
                  'original_unknown_journal_preserved':True, 'final_state':final['state'],
                  'final_pending':final['pending'], 'final_actions_started':final['actions_started'],
                  'foreign_run':'awaiting_observation; token donor action deliberately never executed',
                  'scope':'Controlled scripted uncertainty; actual file effect and helper CLI. No production failure, model execution, reviewer authentication, delivery certification, native wakeup, human outcome, or statistical comparison.',
                  'native_tokens':None, 'native_usd':None, 'finished_at':stamp()}
        ensure(checks['effect_writer_invocations']==1 and final['actions_started']==1, 'Duplicate effect/start')
        (self.work/'self-check.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
        return checks


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skill',type=Path,required=True,help='Unmodified personal-agent-growth repository root')
    parser.add_argument('--work',type=Path,required=True,help='New or empty directory; never reuse a drill output')
    args=parser.parse_args()
    ensure(sys.version_info >= (3,11), 'Python 3.11+ required')
    skill=args.skill.expanduser().resolve()
    work=args.work.expanduser().absolute()
    ensure((skill/'scripts/adaptive_learning.py').is_file(), 'Missing helper')
    ensure(not work.is_symlink(), 'Work cannot be a symlink')
    work.mkdir(parents=True,exist_ok=True)
    ensure(not any(work.iterdir()), 'Work directory must be fresh and empty')
    work=work.resolve()
    (work/'invocation.json').write_text(json.dumps({'argv':sys.argv,'python':sys.executable,
        'started_at':stamp(),'input_hashes':{p:sha(skill/p) for p in ['scripts/adaptive_learning.py','scripts/capability_ledger.py']},
        'script_sha256':sha(Path(__file__))},indent=2),encoding='utf-8')
    try:
        checks=Drill(skill,work).run()
    except Exception:
        (work/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8')
        raise
    finally:
        manifest={str(p.relative_to(work)):sha(p) for p in sorted(work.rglob('*')) if p.is_file() and p.name!='manifest.json'}
        (work/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(json.dumps(checks,indent=2))


if __name__=='__main__':
    main()
