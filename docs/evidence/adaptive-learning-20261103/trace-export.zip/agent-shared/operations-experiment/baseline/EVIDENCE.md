# Baseline evidence

This is one exploratory baseline sample. No mechanism-library records, other-arm outputs or standard answers were read. The host Agent read the common brief, predeclared proposal, current helper source and adaptive-learning reference, then authored and actually ran the operator recovery drill.

- `RUNBOOK.md`: source-grounded operator decisions, portable commands and explicit limits.
- `recovery_drill.py`: executable Python 3.11+ drill, accepting `--skill` and a fresh `--work`.
- `drill-01/invocation.json`: actual interpreter, command arguments, start time and helper/script input hashes.
- `drill-01/receipts/`: exact subprocess commands, stdout, stderr, UTC boundaries and exits, including all three expected rejections.
- `drill-01/learning-runs/`: append-only helper records; the original unknown remains in recovery event `000003.md`.
- `drill-01/inspection.json` and `effect.jsonl`: actual inspected effect and exact start binding.
- `drill-01/self-check.json`: checked bounded claims. Main run ends active with no pending action, one action start and one actual writer invocation.
- `drill-01/manifest.json`: hashes covering the drill's saved evidence.
- `source-version-receipt.json`: preparation and execution hashes. Root changed the helper's journal inventory counting between these phases; actual drill uses the fixed source. Earlier source hashes remain preserved.
- `agent-receipts/`, `build-start.json`, `build-observation.md`: real host Agent's separate adaptive run, not a simulated model.
- `timing.json`: first observed intake clock, preparation, first exercised draft, first reviewable result, review wait, and eventual completion. Native token/USD fields are null.

The controlled drill intentionally creates uncertainty after a real child file write while retaining its acknowledgment. It does not claim real receipt loss or infrastructure failure. Its foreign-token donor run is deliberately left awaiting observation without executing that action. No automatic cleanup hides this state.

The controlled script does not certify delivery or pretend to be an independent reviewer. The actual host run is `learning-runs/ops-baseline` in the shared learning root. Its delivery observation must reference the real root review, after that review occurs; `final-status.json` is produced only after this settlement. A reported zero known cost sum is not a claim of zero cost: native costs are unavailable.

All current controlled checks passed. Expected wrong-token/repeat-start/stale-plan failures are preserved. No production actions, authenticated review tests, scheduling tests, remote exactly-once guarantees, human learning outcomes or statistical speedup claims are included.
