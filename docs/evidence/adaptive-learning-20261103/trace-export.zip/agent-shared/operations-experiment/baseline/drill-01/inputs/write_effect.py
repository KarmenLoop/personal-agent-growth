import pathlib,sys
p=pathlib.Path(sys.argv[1])
with p.open('x',encoding='utf-8') as f:
 f.write(sys.argv[2])
print('CREATED',p.name)
