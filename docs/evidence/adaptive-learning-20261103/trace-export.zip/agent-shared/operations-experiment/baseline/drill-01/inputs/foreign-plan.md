---
{
  "id": "foreign-plan",
  "type": "learning-plan",
  "based_on_revision": 0,
  "unknowns": [
    {
      "id": "effect",
      "question": "Did the file effect occur?",
      "importance": 1
    }
  ],
  "actions": [
    {
      "id": "write-effect",
      "kind": "tool",
      "question_ids": [
        "effect"
      ],
      "description": "Create one exclusive local file associated with this start token.",
      "expected_information_gain": 1,
      "estimated_seconds": 10,
      "preconditions": []
    }
  ],
  "experience_refs": [],
  "artifacts": []
}
---

The foreign run is only a token donor; its action is never executed.
