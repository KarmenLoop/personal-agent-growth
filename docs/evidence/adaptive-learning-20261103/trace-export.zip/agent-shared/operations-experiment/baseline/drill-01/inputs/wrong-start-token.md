---
{
  "id": "wrong-start-token",
  "type": "learning-observation",
  "start_id": "start-5246467abe00604c9b748de9",
  "action_id": "write-effect",
  "outcome": "progress",
  "finding": "Read-only inspection matched exact intended content and start token; no repeat effect.",
  "hypothesis_change": "Observed file content supports one completed effect within this isolated drill.",
  "resolved_questions": [
    "effect"
  ],
  "artifacts": [
    {
      "path": "effect.jsonl",
      "sha256": "c08d03646670efd2033079e1b6fe599bd110b133a430d66824dde132ad3fe25e"
    }
  ],
  "executor": "controlled-drill-process",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---

Scripted controlled drill observation, not a model judgment or independent review.
