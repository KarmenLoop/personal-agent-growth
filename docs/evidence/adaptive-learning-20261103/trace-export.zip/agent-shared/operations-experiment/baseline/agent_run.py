#!/usr/bin/env python3
"""Receipt recorder for the real host Agent's work; contains no model or simulated review."""
import sys, json, hashlib, subprocess
from pathlib import Path
from datetime import datetime, timezone
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
SKILL=Path('$REPO')
RUN='ops-baseline'
ACCEPT=['executable recovery drill','unique-start binding','no duplicate file effect','original unknown and rejection preserved','usable operator decisions','explicit evidence limits']
def now():return datetime.now(timezone.utc).isoformat()
def write(name,obj,body):
 p=BASE/name;p.write_text('---\n'+json.dumps(obj,indent=2)+'\n---\n\n'+body+'\n');return p

def call(cmd,*args):
 d=BASE/'agent-receipts';d.mkdir(exist_ok=True)
 n=len(list(d.glob('*.json')))+1
 argv=[sys.executable,'-B',str(SKILL/'scripts/adaptive_learning.py'),cmd,'--root',str(ROOT),'--id',RUN,*map(str,args)]
 start=now();r=subprocess.run(argv,text=True,capture_output=True)
 rec={'argv':argv,'started_at':start,'ended_at':now(),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
 (d/f'{n:03d}-{cmd}.json').write_text(json.dumps(rec,indent=2))
 if r.returncode:raise RuntimeError(rec)
 return json.loads(r.stdout)
def artifact(name):
 p=BASE/name;return {'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def plan(rev,aid,kind,questions,artifacts):
 q=[{'id':x,'question':y,'importance':1} for x,y in questions]
 p=write('plan-'+aid+'.md',{'id':'plan-'+aid,'type':'learning-plan','based_on_revision':rev,'unknowns':q,'actions':[{'id':aid,'kind':kind,'question_ids':[x for x,y in questions],'description':{'build':'Author source-grounded operator runbook and run the actual controlled file-effect drill.','delivery':'Submit actual artifacts for independent root review; deliver only after review.'}[aid],'expected_information_gain':1,'estimated_seconds':300 if aid=='build' else 180,'preconditions':[]}],'experience_refs':[],'artifacts':artifacts},'Baseline uses current technical source, not the mechanism library.')
 return call('plan','--proposal',p,'--expected-revision',rev)
if sys.argv[1]=='begin':
 (BASE/'timing.json').write_text(json.dumps({'task_intake_at':'2026-11-03T14:40:28+00:00','preparation_end_at':now(),'first_usable_at':None,'task_end_at':None,'native_tokens':None,'native_usd':None},indent=2))
 paths=['scripts/adaptive_learning.py','scripts/capability_ledger.py','references/adaptive-learning.en.md']
 (BASE/'source-inputs.json').write_text(json.dumps({p:hashlib.sha256((SKILL/p).read_bytes()).hexdigest() for p in paths},indent=2))
 req=write('request.md',{'id':RUN,'type':'learning-request','goal':'Produce and independently review an operator recovery runbook and executable drill using current helper behavior.','domain':'operator recovery','acceptance':ACCEPT,'budget_seconds':900,'max_actions':6,'allowed_actions':['experiment','deliver'],'max_plans':12},'Real host Agent baseline arm; one exploratory sample; no native cost data.')
 s=call('init','--request',req)
 s=plan(s['revision'],'build','experiment',[('recovery','Which evidence permits safe non-repeating recovery under the current contract?')],[artifact('source-inputs.json')])
 s=call('start','--action','build','--expected-revision',s['revision'],'--reason','Direct source learning and one local controlled experiment address the acceptance criteria.')
 (BASE/'build-start.json').write_text(json.dumps(s,indent=2))
 print(json.dumps(s,indent=2))
elif sys.argv[1]=='ready':
 s=call('status');p=s['pending']
 obs=write('build-observation.md',{'id':'build-actual-result','type':'learning-observation','start_id':p['start_id'],'action_id':'build','outcome':'progress','finding':'The real host Agent wrote the runbook and executable drill, then executed the drill with a real exclusive file creation. Actual receipts and self-check are attached.','hypothesis_change':'Source interpretation agrees with observed unknown retention, wrong-token rejection, and reconciliation without repeating the file effect. Production uncertainty remains outside scope.','resolved_questions':['recovery'],'artifacts':[artifact('RUNBOOK.md'),artifact('recovery_drill.py'),artifact('drill-01/self-check.json')],'executor':'host-agent-operations-baseline','reviewer':None,'cost':{'tokens':None,'usd':None},'acceptance_checks':{}},'Actual author observation. Independent review is still pending.')
 s=call('observe','--observation',obs,'--expected-revision',s['revision'])
 s=plan(s['revision'],'delivery','deliver',[],[artifact('RUNBOOK.md'),artifact('recovery_drill.py'),artifact('drill-01/self-check.json')])
 s=call('start','--action','delivery','--expected-revision',s['revision'],'--reason','Artifacts exist; independent reviewer must inspect them before a delivered observation is written.')
 t=json.loads((BASE/'timing.json').read_text());t['first_usable_at']=now();t['review_wait_started_at']=now();(BASE/'timing.json').write_text(json.dumps(t,indent=2));print(json.dumps(s,indent=2))
elif sys.argv[1]=='finalize':
 review_path=Path(sys.argv[2]).resolve()
 if not review_path.is_file() or not review_path.is_relative_to(ROOT):raise SystemExit('Real review artifact must exist within the shared learning root')
 review_text=review_path.read_text()
 if 'Reviewer: root' not in review_text or 'PASS:' not in review_text:raise SystemExit('The actual root PASS review is required')
 review={'reviewed_at':None}
 review_received_at=now()
 s=call('status');p=s['pending']
 if p is None or p['action']['id']!='delivery':raise SystemExit('No pending delivery')
 review_ref={'path':str(review_path.relative_to(ROOT)),'sha256':hashlib.sha256(review_path.read_bytes()).hexdigest()}
 obs=write('delivery-observation.md',{'id':'delivery-after-root-review','type':'learning-observation','start_id':p['start_id'],'action_id':'delivery','outcome':'delivered','finding':'The real host Agent completed the runbook and actual controlled drill; root independently reviewed the real artifacts and accepted the fixed common criteria.','hypothesis_change':'Accept this bounded operator artifact. One exploratory baseline sample establishes no statistical speedup, general mastery, or production recovery guarantee.','resolved_questions':[],'artifacts':[artifact('RUNBOOK.md'),artifact('recovery_drill.py'),artifact('drill-01/self-check.json'),review_ref],'executor':'host-agent-operations-baseline','reviewer':'root','cost':{'tokens':None,'usd':None},'acceptance_checks':{x:True for x in ACCEPT}},'Delivery follows an actual external-to-this-agent root review; actor labels themselves are not authentication.')
 s=call('observe','--observation',obs,'--expected-revision',s['revision'])
 (BASE/'final-status.json').write_text(json.dumps(call('status'),indent=2))
 t=json.loads((BASE/'timing.json').read_text());t['task_end_at']=now();t['review_finished_at']=review.get('reviewed_at');t['review_complete_observed_at']=review_received_at;parse=lambda x:datetime.fromisoformat(x.replace('Z','+00:00'))
 t['preparation_seconds']=(parse(t['preparation_end_at'])-parse(t['task_intake_at'])).total_seconds()
 t['execution_and_authoring_seconds']=(parse(t['first_usable_at'])-parse(t['preparation_end_at'])).total_seconds()
 t['review_coordination_seconds']=(parse(t['task_end_at'])-parse(t['review_wait_started_at'])).total_seconds()
 t['total_elapsed_seconds']=(parse(t['task_end_at'])-parse(t['task_intake_at'])).total_seconds()
 t['drill_execution_seconds']=(parse(t['drill_finished_at'])-parse(t['drill_started_at'])).total_seconds()
 (BASE/'timing.json').write_text(json.dumps(t,indent=2));print(json.dumps({'status':s,'timing':t},indent=2))
