---
{
  "id": "wrong-start-token",
  "type": "learning-observation",
  "start_id": "start-f8d8f85af268d9e59dfdc722",
  "action_id": "write-effect",
  "outcome": "progress",
  "finding": "Read-only inspection matched exact intended content and start token; no repeat effect.",
  "hypothesis_change": "Observed file content supports one completed effect within this isolated drill.",
  "resolved_questions": [
    "effect"
  ],
  "artifacts": [
    {
      "path": "effect.jsonl",
      "sha256": "228f929718927548b4bd3ccf5f050b2bac3546e7b20e8e010d7a4f6b22ada03f"
    }
  ],
  "executor": "controlled-drill-process",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---

Scripted controlled drill observation, not a model judgment or independent review.
