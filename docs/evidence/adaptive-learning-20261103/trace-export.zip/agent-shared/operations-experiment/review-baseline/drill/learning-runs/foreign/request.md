---
{
  "schema": 1,
  "type": "adaptive-run",
  "id": "foreign",
  "created_at": "2026-11-03T14:45:13.442863+00:00",
  "request": {
    "id": "foreign",
    "type": "learning-request",
    "goal": "Controlled unique-start recovery drill",
    "domain": "local operator recovery",
    "acceptance": [
      "one effect reconciled"
    ],
    "budget_seconds": 900,
    "max_actions": 6,
    "allowed_actions": [
      "tool"
    ],
    "max_plans": 6
  }
}
---

Controlled drill. No production action and no authenticated actor assertions.
