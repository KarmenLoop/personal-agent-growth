from trial import *
original=(HERE/'workshop.en.md').read_text()
old='After an observation, propose the next action against the current revision; do not continue an old queue silently.'
new='After a known terminal outcome clears the pending action, propose the next action against the current revision; do not continue an old queue silently. An `unknown` outcome keeps the same pending action and start token: reconcile its actual effect before any new plan or retry.'
assert original.count(old)==1
(HERE/'workshop.reviewed.en.md').write_text(original.replace(old,new))
write('revision-receipt.md',{'at':now(),'original':ref(HERE/'workshop.en.md'),'revised':ref(HERE/'workshop.reviewed.en.md'),'review':ref(ROOT/'review-instruction/review.md')},'Root actually reviewed the handout and independently ran the unknown-condition variation. One required wording repair: distinguish known terminal observation from unknown pending reconciliation. Original hash-bound handout preserved; revised version changes exactly this sentence. Awaiting final root read before delivered observation.')
