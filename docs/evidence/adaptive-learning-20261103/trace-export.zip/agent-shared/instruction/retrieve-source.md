---
{
  "id": "retrieve-source",
  "type": "learning-plan",
  "based_on_revision": 0,
  "unknowns": [
    {
      "id": "transfer",
      "question": "Which shared mechanism can inform this workshop, and which conditions differ?",
      "importance": 1.0,
      "blocking": true
    }
  ],
  "actions": [
    {
      "id": "retrieve-source",
      "kind": "retrieve",
      "question_ids": [
        "transfer"
      ],
      "description": "Retrieve and inspect source experience after saving the cold prediction.",
      "expected_information_gain": 0.8,
      "estimated_seconds": 180,
      "preconditions": []
    }
  ],
  "experience_refs": [],
  "artifacts": []
}
---
Host chooses this bounded action because its result determines the next practical step. Estimates are not measured costs.
