import datetime as dt
import hashlib
import json
import pathlib
import subprocess
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
REPO = pathlib.Path('$REPO')
PY = sys.executable
ACTOR = '/root/adaptive_instruction_trial'
RUN = 'instruction'
def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ref(p):
    p = pathlib.Path(p)
    return {'path': str(p.relative_to(ROOT)), 'sha256': sha(p)}
def write(name, obj, body=''):
    p = HERE / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text('---\n'+json.dumps(obj, indent=2)+'\n---\n'+body+'\n')
    return p
def call(label, argv, expected=0):
    folder = HERE/'receipts'/label
    folder.mkdir(parents=True, exist_ok=False)
    t, mono = now(), time.monotonic()
    p = subprocess.run([str(a) for a in argv], cwd=REPO, capture_output=True)
    (folder/'stdout.txt').write_bytes(p.stdout)
    (folder/'stderr.txt').write_bytes(p.stderr)
    receipt = {'started_at':t,'ended_at':now(),'elapsed_seconds':time.monotonic()-mono,'cwd':str(REPO),'argv':[str(a) for a in argv], 'exit_code':p.returncode,'expected_exit':expected,'stdout_sha256':sha(folder/'stdout.txt'),'stderr_sha256':sha(folder/'stderr.txt'), 'program_sha256':sha(argv[2]) if len(argv)>2 and pathlib.Path(str(argv[2])).is_file() else None}
    (folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(label, p.returncode, flush=True)
    if p.returncode != expected: raise RuntimeError(p.stderr.decode(errors='replace'))
    try: return json.loads(p.stdout)
    except ValueError: return p.stdout.decode(errors='replace')
def cli(label, command, *args): return call(label,[PY,'-B',REPO/'scripts/adaptive_learning.py',command,'--root',ROOT,'--id',RUN,*args])
def plan(label, revision, unknowns, kind, description, experience_refs=(), artifacts=()):
    p=write(label+'.md',{'id':label,'type':'learning-plan','based_on_revision':revision,'unknowns':unknowns,'actions':[{'id':label,'kind':kind,'question_ids':[q['id'] for q in unknowns],'description':description,'expected_information_gain':0.8,'estimated_seconds':180,'preconditions':[]}],'experience_refs':list(experience_refs),'artifacts':list(artifacts)},'Host chooses this bounded action because its result determines the next practical step. Estimates are not measured costs.')
    cli(label+'-plan','plan','--proposal',p,'--expected-revision',str(revision))
    return cli(label+'-start','start','--action',label,'--reason',description,'--expected-revision',str(revision+1))
def observe(label, state, finding, change, resolved, artifacts, outcome='progress',reviewer=None,checks=None):
    p=write(label+'-observation.md',{'id':label+'-observation','type':'learning-observation','start_id':state['pending']['start_id'],'action_id':state['pending']['action']['id'],'outcome':outcome,'finding':finding,'hypothesis_change':change,'resolved_questions':resolved,'artifacts':[ref(a) for a in artifacts],'executor':ACTOR,'reviewer':reviewer,'cost':{'tokens':None,'usd':None},'acceptance_checks':checks or {}},'Actual commands, raw stdout/stderr, exit codes, wall clocks, and artifact hashes are in instruction/receipts. Unknown native token usage and USD are not zero.')
    return cli(label+'-observe','observe','--observation',p,'--expected-revision',str(state['revision']))
if __name__ == '__main__':
    write('cold-judgment.md',{'saved_at':now(),'task_id':'instruction','stage':'intake-before-shared-experience-retrieval'},'''Goal: a public-ready English 15-minute contributor workshop, runnable commands, useful handout, failure criteria, and attributed sources. Prior source reading: SKILL.en.md, adaptive-learning reference/tutorial, actual helper help/schema, and capability-learning reference. This is not a zero-knowledge trial.
Prediction: a short worked example plus a deliberate stale-revision error will make the helper contract easier to inspect than prose alone. This is a design hypothesis, not evidence of human learning.
Unknown 1: which shared mechanism, if any, transfers from software validation to instruction without confusing executable verification with learning?
Unknown 2: can a novice-facing practice script exercise plan/start/observe and a meaningful failure using only standard-library Python?
Unknown 3: can a reviewer use the handout without private paths or an invented reviewer identity?
Disconfirmation: if executable checks pass while an independent reader cannot distinguish start from completed action or cannot run the examples, the mechanism is insufficient for teaching.
Budget: at most 8 real learning actions, 1800 elapsed seconds, 12 plans. The parent requests a useful draft in about 8 minutes. Whole-task intake preparation precedes helper init and is not included in run timing. Human learning, delayed retention, PPC strategy adoption, model changes, and scheduling are out of scope.
Native token usage and USD are unavailable. No retrospective intake timestamp is fabricated; saved_at is the actual receipt-writing time.''')
    acceptance=['The English handout contains a 15-minute agenda, runnable practice, and source attribution.','Actual CLI receipts verify success and expected failure behavior in controlled fixtures.','An independent Agent reviews the deliverable and limitations without claiming human learning.']
    request=write('request-input.md',{'id':'instruction-request','type':'learning-request','goal':'Create and verify a useful 15-minute contributor workshop for the adaptive learning helpers.','domain':'instructional-design','acceptance':acceptance,'budget_seconds':1800,'max_actions':8,'max_plans':12,'allowed_actions':['retrieve','research','experiment','reflect','deliver']},'User-authorized learning and artifact creation only. Repo read-only; owned instruction artifacts and one learning run. No external publication, model changes, or human-learning claims.')
    cli('init','init','--request',request)
    q=[{'id':'transfer','question':'Which shared mechanism can inform this workshop, and which conditions differ?','importance':1.0,'blocking':True}]
    st=plan('retrieve-source',0,q,'retrieve','Retrieve and inspect source experience after saving the cold prediction.')
    query=write('query.md',{'id':'instruction-query','type':'transfer-query','task_id':'instruction','domain':'instructional-design','problem_structure':['evidence-boundary','unfamiliar-task','verification-before-delivery','claims-exceed-evidence'],'mechanisms':['evidence-gated-claims','prediction-before-observation','counterexample-testing'],'facts':{},'keywords':['evidence','review','failure']},'The potential correspondence is claim to observable check. Learner comprehension differs from software contract conformance; successful execution cannot prove instruction is effective.')
    data=call('retrieve-initial',[PY,'-B',REPO/'scripts/experience_transfer.py','retrieve','--root',ROOT,'--query',query,'--limit','5'])
    print(json.dumps(data,indent=2))
