---
{
  "id": "build-practice-observation",
  "type": "learning-observation",
  "start_id": "start-6af531417312f9e895ab625d",
  "action_id": "build-practice",
  "outcome": "progress",
  "finding": "Eight-call lab and unknown-condition variation actually executed; expected stale rejection retained; output and status match bounded teaching claims.",
  "hypothesis_change": "Retain runnable practice, add independent condition variation and keep instruction effectiveness separate.",
  "resolved_questions": [
    "usable-lab"
  ],
  "artifacts": [
    {
      "path": "instruction/practice-findings.md",
      "sha256": "4e5ae3e4866d8b9b35b2125350c2b28509f191de594cf1332685b2ed6e9cad73"
    },
    {
      "path": "instruction/workshop.en.md",
      "sha256": "fa33b7cf23f787b9cab38374efccb9db2f8930ce00686cebf8fc06e24f582a53"
    },
    {
      "path": "instruction/practice.py",
      "sha256": "57673f4c4bdab507c5477eabdbc09808b5435d207073984cff677e4c1fd26b4b"
    },
    {
      "path": "instruction/lab-01/summary.json",
      "sha256": "895954d3274a318bbefb328c5edab2a652bdd20147d24752a9ff8da4bdb2a582"
    },
    {
      "path": "instruction/receipts/variation-unknown/stdout.txt",
      "sha256": "a39609276fa4db2a4c58ce30241c8741d2d5b2821238b30442843a452ebac9da"
    },
    {
      "path": "instruction/source-fingerprint.json",
      "sha256": "45ccbdee30bcf309c75b33dc2eb49a05af8ad87800823513fc893f4b34b52fa4"
    }
  ],
  "executor": "/root/adaptive_instruction_trial",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Actual commands, raw stdout/stderr, exit codes, wall clocks, and artifact hashes are in instruction/receipts. Unknown native token usage and USD are not zero.
