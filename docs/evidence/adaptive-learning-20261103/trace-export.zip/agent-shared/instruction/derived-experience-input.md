---
{
  "id": "instruction-vocabulary-role-boundaries",
  "type": "mechanism-experience",
  "source_task_id": "instruction",
  "domain": "instructional-design",
  "problem_structure": [
    "changing-evidence",
    "stale-plan",
    "unfamiliar-task",
    "zero-match-retrieval"
  ],
  "mechanisms": [
    "evidence-binding",
    "vocabulary-alignment",
    "recorder-executor-separation"
  ],
  "required_conditions": {
    "explicit-label-retrieval": true,
    "target-artifact-can-be-revised": true
  },
  "exceptions": [
    "The actual task produced a reviewed instructional artifact and controlled CLI receipts; it did not measure human comprehension, completion time, or retention.",
    "Label alignment can find candidates but cannot establish that the proposed analogy is true.",
    "A semantic correction was still necessary after executable checks passed; successful CLI execution does not establish complete instructional correctness.",
    "No baseline/general/domain comparison or composition trial was performed, so this is not adopted PPC strategy."
  ],
  "intervention": "After a zero-match result, inspect and explicitly align structural vocabulary; after executable practice, obtain a separate content review that checks recorder, executor, and reconciliation roles.",
  "explanation": "The first workshop query returned zero matches; aligning the real source labels retrieved a candidate. Controlled helper practice passed, but independent review still found an overbroad replanning instruction. A separate reviewed revision corrected unknown-effect reconciliation. This suggests complementary checks, not a measured teaching-effect improvement.",
  "validation": "hypothesis",
  "executor": "/root/adaptive_instruction_trial",
  "reviewer": null,
  "artifacts": [
    {
      "path": "instruction/cold-judgment.md",
      "sha256": "d8b23de157aa0cf288415cfbebdcd9a2bd75dbcf37d7dd0b4a67b594fb11e81e"
    },
    {
      "path": "instruction/receipts/retrieve-initial/stdout.txt",
      "sha256": "0c6178b95169628a81454e02492ae335f9790069c64eb03e1b5f1e37b74197dd"
    },
    {
      "path": "instruction/receipts/retrieve-aligned/stdout.txt",
      "sha256": "d5bdf2190e4b410b1d2bc14088202505f8ada1bb943ef4fa5d7b00ffb9ae7193"
    },
    {
      "path": "instruction/transfer-mapping.md",
      "sha256": "65f8c0eda0328effe2e4709ad68a6ffe9e37371ac8bbeb945568a80d396bfb1a"
    },
    {
      "path": "instruction/lab-01/summary.json",
      "sha256": "895954d3274a318bbefb328c5edab2a652bdd20147d24752a9ff8da4bdb2a582"
    },
    {
      "path": "review-instruction/review.md",
      "sha256": "0b3478037d337aa679b2774fa1f47343f02f222f3fd0792bee8e1fc58830adfc"
    },
    {
      "path": "review-instruction/receipt.json",
      "sha256": "b385525454d2ea5116c7a0f06f93e4472251eb7eca80907ad965fb0201f220c0"
    },
    {
      "path": "instruction/revision-receipt.md",
      "sha256": "2e474a48888fb6e055ad2201a920b9885e2963b4b9b0de8aff84f3f95b40156f"
    },
    {
      "path": "instruction/workshop.reviewed.en.md",
      "sha256": "d52fb8135036dc5d2353d07180720069b9e1a4bc128cab199b472e4074e5daf2"
    }
  ]
}
---
Derived from experience/mechanism/feedback-invalidates-plan/experience.md. The prior source remains unchanged. Its software-validation hypothesis was adapted to actual instructional design: draft a public workshop, execute learner examples, inspect failure, seek independent critique, and repair a specific misleading sentence. The current task is not merely the prior task renamed; the output and acceptance concern teachable instructions, with CLI practice supporting only part of acceptance.
Actual counterevidence: code execution succeeded while the first handout still overgeneralized observation-to-replan behavior. Review narrowed the wording to known terminal outcomes; unknown effects retain the same pending action.
Transfer verdict: source experience influenced what was checked and revised, but causal improvement and human-learning benefit remain inconclusive. The mechanism is a candidate, not a universal policy. A future task should predict its failure mode, independently execute a new scenario, and compare the outcome before claiming stronger transfer.
Next probe: ask a distinct contributor to follow the handout on an unfamiliar input, inspect their artifacts and explanation, and record whether role confusion remains. Do not create a wakeup without an actual future purpose and host registration.
