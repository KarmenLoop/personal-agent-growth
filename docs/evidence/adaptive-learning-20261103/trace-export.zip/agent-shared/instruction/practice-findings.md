---
{
  "saved_at": "2026-11-03T14:36:03.531584+00:00",
  "actual_cli_calls": 9,
  "unexpected_failures": 0,
  "expected_stale_rejection_count": 1
}
---
The eight-call lab completed with seven exit-0 calls and one expected stale start rejection (exit 2). The actual host code checked that output did not exist after start, then wrote and read back it. Status was revision 3, active, progress, pending null. A ninth actual helper call changed one required condition to null: candidate remained visible but was ineligible. These are controlled fixture results, not actual learner evidence.
The handout retains the first real trial's no-match lesson and explicitly separates query vocabulary from semantic understanding. Plan revised from generic stale-error example to an inspectable source-label condition variation. Independent reviewer may still find usability defects; actual human timing and learning are unknown.
The top-level first practice command was invoked through exec_command and its stdout/exit are in the task tool receipt; nested helper calls each have durable local receipts. No failed or incomplete attempts were deleted.
