---
{
  "id": "instruction-query",
  "type": "transfer-query",
  "task_id": "instruction",
  "domain": "instructional-design",
  "problem_structure": [
    "evidence-boundary",
    "unfamiliar-task",
    "verification-before-delivery",
    "claims-exceed-evidence"
  ],
  "mechanisms": [
    "evidence-gated-claims",
    "prediction-before-observation",
    "counterexample-testing"
  ],
  "facts": {},
  "keywords": [
    "evidence",
    "review",
    "failure"
  ]
}
---
The potential correspondence is claim to observable check. Learner comprehension differs from software contract conformance; successful execution cannot prove instruction is effective.
