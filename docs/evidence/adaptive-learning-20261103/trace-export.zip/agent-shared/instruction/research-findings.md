---
{
  "saved_at": "2026-11-03T14:33:43.417531+00:00",
  "sources": [
    "docs/adaptive-learning.en.md",
    "scripts/adaptive_learning.py",
    "scripts/experience_transfer.py"
  ]
}
---
Use JSON front matter, explicit root, immutable input files, exact revision and actual start token. A controlled lab can show add/retrieve plus init/plan/stale-start/start/host-action/observe/status. It must stop at progress, with reviewer null, rather than inventing reviewed delivery. A fresh plan is needed after observation. Expected stale revision failure is exit 2. All commands capture stdout/stderr and actual clocks. A failed second retrieval may mean mismatched labels, not absence of useful knowledge.
Revision to cold proposal: do not demonstrate delivery with a fake reviewer. Teach the review gate in the challenge and keep the executable lab at actual progress. Add explicit terminology-alignment explanation because the first actual retrieval failed to match.
