---
{
  "id": "fixture-evidence-binding",
  "type": "mechanism-experience",
  "source_task_id": "fixture-source",
  "domain": "software-validation",
  "problem_structure": [
    "changing-evidence"
  ],
  "mechanisms": [
    "evidence-binding"
  ],
  "required_conditions": {
    "decision-can-be-revised": true
  },
  "exceptions": [
    "Fixture data cannot prove human learning or a general causal mechanism."
  ],
  "intervention": "Bind a revisable decision to inspected source bytes.",
  "explanation": "Controlled example for understanding retrieval fields.",
  "validation": "hypothesis",
  "executor": "workshop-fixture",
  "reviewer": null,
  "artifacts": [
    {
      "path": "fixture-source.txt",
      "sha256": "3258f9e7ccbd51e1375b7fc09a2b89db7ae999a595f396fbfd557c23e130e6c0"
    }
  ],
  "schema": 1,
  "created_at": "2026-11-03T14:35:16.521037+00:00"
}
---

CONTROLLED FIXTURE: not an observed historical task.
