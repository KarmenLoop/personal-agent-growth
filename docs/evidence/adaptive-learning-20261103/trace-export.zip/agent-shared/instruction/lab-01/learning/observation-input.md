---
{
  "id": "fixture-observation",
  "type": "learning-observation",
  "start_id": "start-e93d2edb1dd0c5a31eb36697",
  "action_id": "write-evidence",
  "outcome": "progress",
  "finding": "After start the output was absent; an actual host file write created it and read it back.",
  "hypothesis_change": "Retain the distinction between recorded start and host execution.",
  "resolved_questions": [
    "host-action"
  ],
  "artifacts": [
    {
      "path": "host-output.txt",
      "sha256": "179f9d2822828534e1c14859e558243f76985f74b1a9606fc0b2efbac1c152b6"
    },
    {
      "path": "host-action.json",
      "sha256": "3a66a873bfedec21bb0d507030f63189388abc0b726d03220e32275ad3a34d1a"
    }
  ],
  "executor": "workshop-fixture",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Actual local fixture execution only. Tokens and USD unknown. No delivery or teaching effectiveness is claimed.
