---
{
  "schema": 1,
  "type": "adaptive-run",
  "id": "practice",
  "created_at": "2026-11-03T14:35:16.711687+00:00",
  "request": {
    "id": "fixture-request",
    "type": "learning-request",
    "goal": "Check that start records intent and the host separately creates an artifact.",
    "domain": "contributor-workshop",
    "acceptance": [
      "A real host action produces an evidence-bound observation."
    ],
    "budget_seconds": 300,
    "max_actions": 3,
    "max_plans": 4,
    "allowed_actions": [
      "experiment",
      "reflect",
      "deliver"
    ]
  }
}
---

Controlled practice. No human learning, independent review, or actual delivery is asserted.
