---
{
  "id": "fixture-query",
  "type": "transfer-query",
  "task_id": "fixture-current",
  "domain": "instructional-design",
  "problem_structure": [
    "changing-evidence"
  ],
  "mechanisms": [
    "evidence-binding"
  ],
  "facts": {
    "decision-can-be-revised": true
  },
  "keywords": [
    "source"
  ]
}
---
Matching labels demonstrate retrieval only, not successful transfer.
