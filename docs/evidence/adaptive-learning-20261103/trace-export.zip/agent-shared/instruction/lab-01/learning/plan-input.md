---
{
  "id": "fixture-plan",
  "type": "learning-plan",
  "based_on_revision": 0,
  "unknowns": [
    {
      "id": "host-action",
      "question": "Does start create the output file, or does the host need to act?",
      "importance": 1.0,
      "blocking": true
    }
  ],
  "actions": [
    {
      "id": "write-evidence",
      "kind": "experiment",
      "question_ids": [
        "host-action"
      ],
      "description": "Start, inspect absent output, then have the host write it.",
      "expected_information_gain": 0.8,
      "estimated_seconds": 30,
      "preconditions": []
    }
  ],
  "experience_refs": [
    {
      "path": "experience/mechanism/fixture-evidence-binding/experience.md",
      "sha256": "28e4505e346f9fbf969ce65a77d23a6811246045815db284666c58a9833a7c08",
      "revision": 0,
      "head_sha256": "28e4505e346f9fbf969ce65a77d23a6811246045815db284666c58a9833a7c08"
    }
  ],
  "artifacts": [
    {
      "path": "fixture-source.txt",
      "sha256": "3258f9e7ccbd51e1375b7fc09a2b89db7ae999a595f396fbfd557c23e130e6c0"
    }
  ]
}
---
Prediction: start will not create host-output.txt. The host must execute the action.
