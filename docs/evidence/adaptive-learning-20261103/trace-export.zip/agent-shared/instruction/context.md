---
{
  "updated_at": "2026-11-03T14:38:42.999800+00:00",
  "task_id": "instruction",
  "state": "delivered",
  "latest_node": "instruction/latest-node.md"
}
---
Original goal: useful 15-minute English contributor workshop for adaptive helpers. Actual files: instruction/workshop.reviewed.en.md, instruction/practice.py, instruction/contributor-workshop-0.6.0.zip. Parent root independently reviewed and corrected one semantic sentence; actual reviewer approval is review-instruction/final-review.md. Never rewrite the original hash-bound handout.
Same physical root holds learning-runs/instruction and experience/mechanism/instruction-vocabulary-role-boundaries. Source was read-only. Controlled fixture practice does not imply human learning. Check hashes/current source before reuse; experience_transfer changed concurrently after practice, preserved in source-at-delivery.json. No future scheduler or PPC policy adopted.
