---
{
  "at": "2026-11-03T14:36:42.539655+00:00",
  "original": {
    "path": "instruction/workshop.en.md",
    "sha256": "fa33b7cf23f787b9cab38374efccb9db2f8930ce00686cebf8fc06e24f582a53"
  },
  "revised": {
    "path": "instruction/workshop.reviewed.en.md",
    "sha256": "d52fb8135036dc5d2353d07180720069b9e1a4bc128cab199b472e4074e5daf2"
  },
  "review": {
    "path": "review-instruction/review.md",
    "sha256": "0b3478037d337aa679b2774fa1f47343f02f222f3fd0792bee8e1fc58830adfc"
  }
}
---
Root actually reviewed the handout and independently ran the unknown-condition variation. One required wording repair: distinguish known terminal observation from unknown pending reconciliation. Original hash-bound handout preserved; revised version changes exactly this sentence. Awaiting final root read before delivered observation.
