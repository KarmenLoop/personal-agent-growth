---
{
  "at": "2026-11-03T14:38:42.398335+00:00",
  "archive": {
    "path": "instruction/contributor-workshop-0.6.0.zip",
    "sha256": "cd933ec4a742e8dcb79159231b1b22543b3aa6ee1f1ed5cb4f809c106751528e"
  },
  "public_manifest": {
    "path": "instruction/public/MANIFEST.json",
    "sha256": "3b718f0aae92d0b42fe7659d56fd7c664c07d3865216b7f0bc8684822dc02fd9"
  },
  "integrity": "all members read and matched manifest",
  "reviewed_handout_sha256": "d52fb8135036dc5d2353d07180720069b9e1a4bc128cab199b472e4074e5daf2"
}
---
Actual zipfile creation and readback performed by finish.py; inspect the saved source. Packaging check is separate from original command execution and independent content review.
