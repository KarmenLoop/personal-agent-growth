---
{
  "id": "research-contract-observation",
  "type": "learning-observation",
  "start_id": "start-442e09976554d9be6ef8777c",
  "action_id": "research-contract",
  "outcome": "progress",
  "finding": "Actual docs and CLI help support a minimal controlled lab that stops at progress; delivered requires distinct actual review.",
  "hypothesis_change": "Narrow worked example to genuine progress; remove simulated delivery and add terminology alignment.",
  "resolved_questions": [
    "lab-contract"
  ],
  "artifacts": [
    {
      "path": "instruction/research-findings.md",
      "sha256": "5b2a795622cb04b2a37c5c67d2794f3cdd7777d05526641181f97a82a09d8686"
    },
    {
      "path": "instruction/receipts/source-tutorial/receipt.json",
      "sha256": "1de7ab90db9069e48d17ec1f20da976094b2679f216da6258ee35f9dd00a4ea8"
    },
    {
      "path": "instruction/receipts/help-start/stdout.txt",
      "sha256": "8dc39932066e2533918932fe56bc226195b3a3add4f337770de954a0ef052f7c"
    }
  ],
  "executor": "/root/adaptive_instruction_trial",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Actual commands, raw stdout/stderr, exit codes, wall clocks, and artifact hashes are in instruction/receipts. Unknown native token usage and USD are not zero.
