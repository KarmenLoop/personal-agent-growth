# Workshop evidence

Scope: a real Agent authored and revised an English contributor workshop. Its practice uses explicitly controlled fixtures. This is not a human-learning or measured retention trial.

- First actual shared-experience retrieval: zero candidates. Explicit label alignment then retrieved the software-validation hypothesis `feedback-invalidates-plan`.
- Actual practice: eight CLI calls, seven exit 0 and one expected stale-revision exit 2. The host separately wrote and read back an artifact. Final status: revision 3, active, progress, no pending action.
- Actual author variation and independent root variation: an unknown required condition retained the candidate and set probe eligibility false.
- Independent root review found one conceptual wording error despite executable practice passing: an unknown outcome must reconcile the same pending action; only a known terminal outcome permits fresh planning. Original draft retained; revised handout approved.
- The 15-minute agenda is proposed facilitation timing, not an observed learner duration. Whole-Agent native tokens and charges are unavailable, not zero. No human mastery, causal learning benefit, universal transfer, model changes, or PPC policy adoption is claimed.

This public summary is an explicitly sanitized derivative of local receipts. It omits local absolute paths and is not a byte-identical replay bundle. The commands in `practice.py` generate new complete local receipts when actually run. Historical local receipt and review hashes below retain provenance; those private files are not included here.

| Original local artifact | SHA-256 |
| --- | --- |
| lab-01/summary.json | 895954d3274a318bbefb328c5edab2a652bdd20147d24752a9ff8da4bdb2a582 |
| original handout | fa33b7cf23f787b9cab38374efccb9db2f8930ce00686cebf8fc06e24f582a53 |
| reviewed handout | d52fb8135036dc5d2353d07180720069b9e1a4bc128cab199b472e4074e5daf2 |
| root independent receipt | b385525454d2ea5116c7a0f06f93e4472251eb7eca80907ad965fb0201f220c0 |
| root final review | 20322608f2a9d56d933cf8229f006747bb35301874e0c476427dd872a56ef78d |

`source-fingerprint.json` distinguishes sources observed for practice from sources present at packaging. A concurrent helper update does not rewrite the historical result.
