---
{
  "saved_at": "2026-11-03T14:32:43.327603+00:00",
  "task_id": "instruction",
  "stage": "intake-before-shared-experience-retrieval"
}
---
Goal: a public-ready English 15-minute contributor workshop, runnable commands, useful handout, failure criteria, and attributed sources. Prior source reading: SKILL.en.md, adaptive-learning reference/tutorial, actual helper help/schema, and capability-learning reference. This is not a zero-knowledge trial.
Prediction: a short worked example plus a deliberate stale-revision error will make the helper contract easier to inspect than prose alone. This is a design hypothesis, not evidence of human learning.
Unknown 1: which shared mechanism, if any, transfers from software validation to instruction without confusing executable verification with learning?
Unknown 2: can a novice-facing practice script exercise plan/start/observe and a meaningful failure using only standard-library Python?
Unknown 3: can a reviewer use the handout without private paths or an invented reviewer identity?
Disconfirmation: if executable checks pass while an independent reader cannot distinguish start from completed action or cannot run the examples, the mechanism is insufficient for teaching.
Budget: at most 8 real learning actions, 1800 elapsed seconds, 12 plans. The parent requests a useful draft in about 8 minutes. Whole-task intake preparation precedes helper init and is not included in run timing. Human learning, delayed retention, PPC strategy adoption, model changes, and scheduling are out of scope.
Native token usage and USD are unavailable. No retrospective intake timestamp is fabricated; saved_at is the actual receipt-writing time.
