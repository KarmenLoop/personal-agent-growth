from trial import *
lab=HERE/'lab-01'
qpath=lab/'learning/query.md'
parts=qpath.read_text().split('---',2)
data=json.loads(parts[1]); data['id']='fixture-query-unknown'; data['facts']['decision-can-be-revised']=None
var=lab/'learning/query-unknown.md'
var.write_text('---\n'+json.dumps(data,indent=2)+'\n---\nControlled variation: this fact is unknown.\n')
result=call('variation-unknown',[PY,'-B',REPO/'scripts/experience_transfer.py','retrieve','--root',lab/'learning','--query',var])
assert len(result['candidates'])==1 and result['candidates'][0]['eligible_for_probe'] is False
assert result['candidates'][0]['unresolved_conditions']==['decision-can-be-revised']
fingerprint={str(p.relative_to(REPO)):sha(p) for p in [REPO/'SKILL.en.md', REPO/'docs/adaptive-learning.en.md',REPO/'references/adaptive-learning.en.md',REPO/'references/capability-learning.en.md',REPO/'scripts/adaptive_learning.py',REPO/'scripts/experience_transfer.py']}
(HERE/'source-fingerprint.json').write_text(json.dumps({'recorded_at':now(),'source_files':fingerprint,'python_executable':PY,'python_version':sys.version,'repo_path':str(REPO),'scope':'Current local candidate; not a claim of published v0.6.0.'},indent=2)+'\n')
notes=write('practice-findings.md',{'saved_at':now(),'actual_cli_calls':9,'unexpected_failures':0,'expected_stale_rejection_count':1},'''The eight-call lab completed with seven exit-0 calls and one expected stale start rejection (exit 2). The actual host code checked that output did not exist after start, then wrote and read back it. Status was revision 3, active, progress, pending null. A ninth actual helper call changed one required condition to null: candidate remained visible but was ineligible. These are controlled fixture results, not actual learner evidence.
The handout retains the first real trial's no-match lesson and explicitly separates query vocabulary from semantic understanding. Plan revised from generic stale-error example to an inspectable source-label condition variation. Independent reviewer may still find usability defects; actual human timing and learning are unknown.
The top-level first practice command was invoked through exec_command and its stdout/exit are in the task tool receipt; nested helper calls each have durable local receipts. No failed or incomplete attempts were deleted.''')
state=json.loads((HERE/'practice-action-state.json').read_text())
observe('build-practice',state,'Eight-call lab and unknown-condition variation actually executed; expected stale rejection retained; output and status match bounded teaching claims.','Retain runnable practice, add independent condition variation and keep instruction effectiveness separate.',['usable-lab'],[notes,HERE/'workshop.en.md',HERE/'practice.py',lab/'summary.json',HERE/'receipts/variation-unknown/stdout.txt',HERE/'source-fingerprint.json'])
q=[{'id':'independent-review','question':'Does an independent Agent confirm the handout is usable and its claims match the actual evidence?','importance':1.0,'blocking':True}]
st=plan('review-revise',9,q,'reflect','Obtain parent Agent review of the actual handout and variation, then repair specific findings.',[],[ref(HERE/'workshop.en.md'),ref(HERE/'practice.py')])
(HERE/'review-action-state.json').write_text(json.dumps(st,indent=2))
manifest={str(p.relative_to(HERE)):sha(p) for p in [HERE/'workshop.en.md',HERE/'practice.py',HERE/'source-fingerprint.json',lab/'summary.json']}
(HERE/'draft-manifest.json').write_text(json.dumps({'at':now(),'files':manifest},indent=2)+'\n')
