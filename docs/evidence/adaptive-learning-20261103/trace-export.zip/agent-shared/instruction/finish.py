from trial import *
import zipfile

approval=ROOT/'review-instruction/final-review.md'
assert approval.is_file()
assert sha(HERE/'workshop.reviewed.en.md') in approval.read_text()
st=json.loads((HERE/'review-action-state.json').read_text())
observe('review-revise',st,'Root independently inspected the complete handout, executed the unknown-condition variation, required one recovery wording correction, and read the corrected diff as PASS.','Executable fixture checks did not catch an overbroad instruction. Keep independent content review; limit replanning to cleared terminal outcomes.',['independent-review'],[ROOT/'review-instruction/review.md',ROOT/'review-instruction/receipt.json',approval,HERE/'revision-receipt.md',HERE/'workshop.reviewed.en.md'],reviewer='root')
st=plan('deliver-workshop',12,[],'deliver','Package the independently reviewed handout, runnable practice, source fingerprints, and bounded evidence for delivery.',[],[ref(approval),ref(HERE/'workshop.reviewed.en.md')])
public=HERE/'public'
public.mkdir(exist_ok=False)
(public/'workshop.en.md').write_bytes((HERE/'workshop.reviewed.en.md').read_bytes())
(public/'practice.py').write_bytes((HERE/'practice.py').read_bytes())
sources=json.loads((HERE/'source-fingerprint.json').read_text())
source_now={name:sha(REPO/name) for name in sources['source_files']}
public_sources={'recorded_at':sources['recorded_at'],'tested_source_files':sources['source_files'],'delivery_packaging_source_files':source_now,'scope':'Historical practice source fingerprints preserved. Concurrent source edits may differ at packaging; no claim that later sources ran the original practice.'}
(public/'source-fingerprint.json').write_text(json.dumps(public_sources,indent=2)+'\n')
(HERE/'source-at-delivery.json').write_text(json.dumps({'at':now(),'source_files':source_now},indent=2)+'\n')
evidence=f'''# Workshop evidence

Scope: a real Agent authored and revised an English contributor workshop. Its practice uses explicitly controlled fixtures. This is not a human-learning or measured retention trial.

- First actual shared-experience retrieval: zero candidates. Explicit label alignment then retrieved the software-validation hypothesis `feedback-invalidates-plan`.
- Actual practice: eight CLI calls, seven exit 0 and one expected stale-revision exit 2. The host separately wrote and read back an artifact. Final status: revision 3, active, progress, no pending action.
- Actual author variation and independent root variation: an unknown required condition retained the candidate and set probe eligibility false.
- Independent root review found one conceptual wording error despite executable practice passing: an unknown outcome must reconcile the same pending action; only a known terminal outcome permits fresh planning. Original draft retained; revised handout approved.
- The 15-minute agenda is proposed facilitation timing, not an observed learner duration. Whole-Agent native tokens and charges are unavailable, not zero. No human mastery, causal learning benefit, universal transfer, model changes, or PPC policy adoption is claimed.

This public summary is an explicitly sanitized derivative of local receipts. It omits local absolute paths and is not a byte-identical replay bundle. The commands in `practice.py` generate new complete local receipts when actually run. Historical local receipt and review hashes below retain provenance; those private files are not included here.

| Original local artifact | SHA-256 |
| --- | --- |
| lab-01/summary.json | {sha(HERE/'lab-01/summary.json')} |
| original handout | {sha(HERE/'workshop.en.md')} |
| reviewed handout | {sha(HERE/'workshop.reviewed.en.md')} |
| root independent receipt | {sha(ROOT/'review-instruction/receipt.json')} |
| root final review | {sha(approval)} |

`source-fingerprint.json` distinguishes sources observed for practice from sources present at packaging. A concurrent helper update does not rewrite the historical result.
'''
(public/'EVIDENCE.md').write_text(evidence)
license_path=REPO/'LICENSE'
if license_path.exists(): (public/'LICENSE').write_bytes(license_path.read_bytes())
manifest={p.name:sha(p) for p in public.iterdir() if p.is_file()}
(public/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=HERE/'contributor-workshop-0.6.0.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(public.iterdir()): z.write(p,p.name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest
package_receipt=write('package-receipt.md',{'at':now(),'archive':ref(archive),'public_manifest':ref(public/'MANIFEST.json'),'integrity':'all members read and matched manifest','reviewed_handout_sha256':sha(HERE/'workshop.reviewed.en.md')},'Actual zipfile creation and readback performed by finish.py; inspect the saved source. Packaging check is separate from original command execution and independent content review.')
acceptance=json.loads((HERE/'request-input.md').read_text().split('---',2)[1])['acceptance']
final=observe('deliver-workshop',st,'Packaged reviewed English handout, executable practice, source fingerprints, and sanitized evidence. Every archive member read back and matched manifest. Root independently approved the actual revised content.','Retain bounded reviewed artifact delivery; human learning and transferable strategy effectiveness remain unmeasured.',[],[archive,package_receipt,public/'MANIFEST.json',approval],outcome='delivered',reviewer='root',checks={a:True for a in acceptance})
call('add-derived-experience',[PY,'-B',REPO/'scripts/experience_transfer.py','add','--root',ROOT,'--experience',HERE/'derived-experience-input.md'])
call('read-derived-experience',[PY,'-B',REPO/'scripts/experience_transfer.py','status','--root',ROOT,'--id','instruction-vocabulary-role-boundaries'])
status=cli('final-status','status')
cold=json.loads((HERE/'cold-judgment.md').read_text().split('---',2)[1])
request=json.loads((ROOT/'learning-runs/instruction/request.md').read_text().split('---',2)[1])
(HERE/'task-timing.json').write_text(json.dumps({'intake_recorded_at':cold['saved_at'],'agent_message_received_at':None,'pre_intake_preparation_seconds':None,'run_initialized_at':request['created_at'],'delivered_at':final['last_observation'] if False else json.loads((HERE/'receipts/deliver-workshop-observe/receipt.json').read_text())['ended_at'],'task_artifact_work_ended_at':now(),'run_elapsed_seconds':status['elapsed_seconds_since_init'],'scope':'Whole-Agent time includes uncaptured preparation before intake; run elapsed is only since init. Delivered call end is an upper bound on exact delivery event time.','native_tokens':None,'native_usd':None},indent=2)+'\n')
write('context.md',{'updated_at':now(),'task_id':'instruction','state':status['state'],'latest_node':'instruction/latest-node.md'},'''Original goal: useful 15-minute English contributor workshop for adaptive helpers. Actual files: instruction/workshop.reviewed.en.md, instruction/practice.py, instruction/contributor-workshop-0.6.0.zip. Parent root independently reviewed and corrected one semantic sentence; actual reviewer approval is review-instruction/final-review.md. Never rewrite the original hash-bound handout.
Same physical root holds learning-runs/instruction and experience/mechanism/instruction-vocabulary-role-boundaries. Source was read-only. Controlled fixture practice does not imply human learning. Check hashes/current source before reuse; experience_transfer changed concurrently after practice, preserved in source-at-delivery.json. No future scheduler or PPC policy adopted.''')
write('latest-node.md',{'at':now(),'run':'instruction','revision':status['revision'],'state':status['state'],'next_condition':'An actual new contributor task or review need; no automatic wakeup registered.'},'''Read context.md, cold-judgment.md, transfer-mapping.md, practice-findings.md, revision-receipt.md, task-timing.json, and the current learning-run status before continuing. Retrieve the derived mechanism using the actual helper and inspect original and feedback snapshots.
Observed changes: zero-match query caused explicit vocabulary alignment; practice preserved stale start failure; reviewer correction constrained replan advice to known terminal outcomes. New derived mechanism remains a hypothesis. Next useful probe: a separate contributor performs a genuinely new task from the handout and an independent reviewer inspects output and explanation. No pending task should be repeated blindly. Original source/failure evidence preserved.''')
print(json.dumps({'state':status['state'],'revision':status['revision'],'actions':status['actions_started'],'elapsed':status['elapsed_seconds_since_init'],'archive':str(archive),'experience':'instruction-vocabulary-role-boundaries'},indent=2))
