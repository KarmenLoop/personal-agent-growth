---
{
  "id": "research-contract",
  "type": "learning-plan",
  "based_on_revision": 3,
  "unknowns": [
    {
      "id": "lab-contract",
      "question": "Which minimal actual helper actions can produce a useful runnable lesson and meaningful failure?",
      "importance": 1.0,
      "blocking": true
    }
  ],
  "actions": [
    {
      "id": "research-contract",
      "kind": "research",
      "question_ids": [
        "lab-contract"
      ],
      "description": "Inspect actual helper documentation and help before selecting the smallest lab.",
      "expected_information_gain": 0.8,
      "estimated_seconds": 180,
      "preconditions": []
    }
  ],
  "experience_refs": [
    {
      "path": "experience/mechanism/feedback-invalidates-plan/experience.md",
      "sha256": "5590f69fda18d385679693b4916c5613ab988027a3d670a3ed1bc855ab0a8fc9",
      "revision": 0,
      "head_sha256": "5590f69fda18d385679693b4916c5613ab988027a3d670a3ed1bc855ab0a8fc9"
    }
  ],
  "artifacts": [
    {
      "path": "instruction/transfer-mapping.md",
      "sha256": "65f8c0eda0328effe2e4709ad68a6ffe9e37371ac8bbeb945568a80d396bfb1a"
    }
  ]
}
---
Host chooses this bounded action because its result determines the next practical step. Estimates are not measured costs.
