---
{
  "id": "retrieve-source-observation",
  "type": "learning-observation",
  "start_id": "start-75bda431f9fe2e0773d12d35",
  "action_id": "retrieve-source",
  "outcome": "progress",
  "finding": "Initial structural query matched zero; explicit source-label alignment retrieved one eligible software-validation mechanism.",
  "hypothesis_change": "Adapt evidence-binding to lesson revision; reject equivalence between CLI success and learner competence.",
  "resolved_questions": [
    "transfer"
  ],
  "artifacts": [
    {
      "path": "instruction/receipts/retrieve-initial/receipt.json",
      "sha256": "722d906324b597557e55efc851c04e2002f4150037039a8868e6147680953850"
    },
    {
      "path": "instruction/receipts/retrieve-aligned/stdout.txt",
      "sha256": "d5bdf2190e4b410b1d2bc14088202505f8ada1bb943ef4fa5d7b00ffb9ae7193"
    },
    {
      "path": "instruction/transfer-mapping.md",
      "sha256": "65f8c0eda0328effe2e4709ad68a6ffe9e37371ac8bbeb945568a80d396bfb1a"
    }
  ],
  "executor": "/root/adaptive_instruction_trial",
  "reviewer": null,
  "cost": {
    "tokens": null,
    "usd": null
  },
  "acceptance_checks": {}
}
---
Actual commands, raw stdout/stderr, exit codes, wall clocks, and artifact hashes are in instruction/receipts. Unknown native token usage and USD are not zero.
