---
{
  "id": "review-revise",
  "type": "learning-plan",
  "based_on_revision": 9,
  "unknowns": [
    {
      "id": "independent-review",
      "question": "Does an independent Agent confirm the handout is usable and its claims match the actual evidence?",
      "importance": 1.0,
      "blocking": true
    }
  ],
  "actions": [
    {
      "id": "review-revise",
      "kind": "reflect",
      "question_ids": [
        "independent-review"
      ],
      "description": "Obtain parent Agent review of the actual handout and variation, then repair specific findings.",
      "expected_information_gain": 0.8,
      "estimated_seconds": 180,
      "preconditions": []
    }
  ],
  "experience_refs": [],
  "artifacts": [
    {
      "path": "instruction/workshop.en.md",
      "sha256": "fa33b7cf23f787b9cab38374efccb9db2f8930ce00686cebf8fc06e24f582a53"
    },
    {
      "path": "instruction/practice.py",
      "sha256": "57673f4c4bdab507c5477eabdbc09808b5435d207073984cff677e4c1fd26b4b"
    }
  ]
}
---
Host chooses this bounded action because its result determines the next practical step. Estimates are not measured costs.
