---
{
  "id": "instruction-query-aligned",
  "type": "transfer-query",
  "task_id": "instruction",
  "domain": "instructional-design",
  "problem_structure": [
    "changing-evidence",
    "stale-plan"
  ],
  "mechanisms": [
    "feedback-invalidates-plan",
    "evidence-binding"
  ],
  "facts": {
    "new-evidence-available": true,
    "decision-can-be-revised": true
  },
  "keywords": [
    "evidence",
    "review"
  ]
}
---
Explicit vocabulary alignment after zero matches: the lesson is revised after command receipts or reviewer feedback changes evidence. This is a claim-to-evidence relationship, not a claim of human retention.
