---
{
  "id": "deliver-workshop",
  "type": "learning-plan",
  "based_on_revision": 12,
  "unknowns": [],
  "actions": [
    {
      "id": "deliver-workshop",
      "kind": "deliver",
      "question_ids": [],
      "description": "Package the independently reviewed handout, runnable practice, source fingerprints, and bounded evidence for delivery.",
      "expected_information_gain": 0.8,
      "estimated_seconds": 180,
      "preconditions": []
    }
  ],
  "experience_refs": [],
  "artifacts": [
    {
      "path": "review-instruction/final-review.md",
      "sha256": "20322608f2a9d56d933cf8229f006747bb35301874e0c476427dd872a56ef78d"
    },
    {
      "path": "instruction/workshop.reviewed.en.md",
      "sha256": "d52fb8135036dc5d2353d07180720069b9e1a4bc128cab199b472e4074e5daf2"
    }
  ]
}
---
Host chooses this bounded action because its result determines the next practical step. Estimates are not measured costs.
