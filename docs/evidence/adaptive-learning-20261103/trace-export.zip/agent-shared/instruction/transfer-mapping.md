---
{
  "saved_at": "2026-11-03T14:33:42.697431+00:00",
  "source_id": "feedback-invalidates-plan",
  "source_domain": "software-validation",
  "target_domain": "instructional-design",
  "decision": "adapt-as-hypothesis"
}
---
Initial retrieval returned zero matches. Inspecting the existing source labels enabled an explicit second query; this is vocabulary alignment, not semantic discovery.
Correspondence: a software plan depends on evidence revision; a lesson's runnable commands and explanatory claims depend on inspected helper behavior and independent review. Both can retain a failed attempt and revise the next action.
Matched conditions: new evidence is available from actual command checks; a draft lesson can be revised before delivery.
Difference: software can check byte identities and revisions, but cannot establish comprehension, appropriate pace, or human retention. The old fixture evidence is not workshop effectiveness evidence.
Disconfirming observation: commands may execute correctly while a reviewer cannot perform the independent challenge or distinguish a recorder from an executor. A zero-match first query already disproves any assumption that structural retrieval automatically handles synonymous labels.
Adaptation: teach predict/run/inspect/revise around one bounded lab; require a separate independent review. Retain original lesson; do not activate a general learning policy. Helpful instructional transfer remains inconclusive until real learning measures exist.
