---
{
  "id": "build-practice",
  "type": "learning-plan",
  "based_on_revision": 6,
  "unknowns": [
    {
      "id": "usable-lab",
      "question": "Do the lesson commands execute with preserved expected failure and usable portable outputs?",
      "importance": 1.0,
      "blocking": true
    }
  ],
  "actions": [
    {
      "id": "build-practice",
      "kind": "experiment",
      "question_ids": [
        "usable-lab"
      ],
      "description": "Build and run the controlled practice; use actual output to revise the handout.",
      "expected_information_gain": 0.8,
      "estimated_seconds": 180,
      "preconditions": []
    }
  ],
  "experience_refs": [
    {
      "path": "experience/mechanism/feedback-invalidates-plan/experience.md",
      "sha256": "5590f69fda18d385679693b4916c5613ab988027a3d670a3ed1bc855ab0a8fc9",
      "revision": 0,
      "head_sha256": "5590f69fda18d385679693b4916c5613ab988027a3d670a3ed1bc855ab0a8fc9"
    }
  ],
  "artifacts": [
    {
      "path": "instruction/research-findings.md",
      "sha256": "5b2a795622cb04b2a37c5c67d2794f3cdd7777d05526641181f97a82a09d8686"
    }
  ]
}
---
Host chooses this bounded action because its result determines the next practical step. Estimates are not measured costs.
