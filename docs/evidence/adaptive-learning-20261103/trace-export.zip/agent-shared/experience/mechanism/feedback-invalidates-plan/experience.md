---
{
  "id": "feedback-invalidates-plan",
  "type": "mechanism-experience",
  "source_task_id": "controlled-integration",
  "domain": "software-validation",
  "problem_structure": [
    "changing-evidence",
    "stale-plan"
  ],
  "mechanisms": [
    "feedback-invalidates-plan",
    "evidence-binding"
  ],
  "required_conditions": {
    "new-evidence-available": true,
    "decision-can-be-revised": true
  },
  "exceptions": [
    "Controlled integration fixtures establish software behavior only; they do not prove human learning or whole-Agent improvement.",
    "A changed label alone does not establish new evidence."
  ],
  "intervention": "Recheck current evidence before carrying forward a previous plan; bind decisions to source identities.",
  "explanation": "The controlled integration returned a stale snapshot rejection after harmful feedback, then permitted a revised plan without losing history. Test cross-domain use before generalizing.",
  "validation": "hypothesis",
  "executor": "root",
  "reviewer": null,
  "artifacts": [
    {
      "path": "inputs/integration-results.json",
      "sha256": "d1bf85be4f829e859edd34ef0db61291014ae995e7b24d04bf03aa118f9d71cc"
    }
  ],
  "schema": 1,
  "created_at": "2026-11-03T14:29:19.640410+00:00"
}
---

Derived from actual controlled integration results. This is a hypothesis for other domains, not a prevalidated policy.
