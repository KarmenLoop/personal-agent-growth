# Shared Agent trial memory

This physical root is shared by the instructional-design Agent and later operations Agent. Inputs contain an actual controlled software-integration result, explicitly bounded in scope. Each Agent must read source artifacts and preserve its own inputs, commands, outputs, corrections and lessons as Markdown. No native token/cost receipt is available unless the host supplies one.
