---
{
  "schema": 1,
  "type": "adaptive-run",
  "id": "instruction",
  "created_at": "2026-11-03T14:32:43.408178+00:00",
  "request": {
    "id": "instruction-request",
    "type": "learning-request",
    "goal": "Create and verify a useful 15-minute contributor workshop for the adaptive learning helpers.",
    "domain": "instructional-design",
    "acceptance": [
      "The English handout contains a 15-minute agenda, runnable practice, and source attribution.",
      "Actual CLI receipts verify success and expected failure behavior in controlled fixtures.",
      "An independent Agent reviews the deliverable and limitations without claiming human learning."
    ],
    "budget_seconds": 1800,
    "max_actions": 8,
    "max_plans": 12,
    "allowed_actions": [
      "retrieve",
      "research",
      "experiment",
      "reflect",
      "deliver"
    ]
  }
}
---

User-authorized learning and artifact creation only. Repo read-only; owned instruction artifacts and one learning run. No external publication, model changes, or human-learning claims.
