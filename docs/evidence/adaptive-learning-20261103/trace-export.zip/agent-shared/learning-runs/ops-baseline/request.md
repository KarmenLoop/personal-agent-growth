---
{
  "schema": 1,
  "type": "adaptive-run",
  "id": "ops-baseline",
  "created_at": "2026-11-03T14:41:32.627073+00:00",
  "request": {
    "id": "ops-baseline",
    "type": "learning-request",
    "goal": "Produce and independently review an operator recovery runbook and executable drill using current helper behavior.",
    "domain": "operator recovery",
    "acceptance": [
      "executable recovery drill",
      "unique-start binding",
      "no duplicate file effect",
      "original unknown and rejection preserved",
      "usable operator decisions",
      "explicit evidence limits"
    ],
    "budget_seconds": 900,
    "max_actions": 6,
    "allowed_actions": [
      "experiment",
      "deliver"
    ],
    "max_plans": 12
  }
}
---

Real host Agent baseline arm; one exploratory sample; no native cost data.
