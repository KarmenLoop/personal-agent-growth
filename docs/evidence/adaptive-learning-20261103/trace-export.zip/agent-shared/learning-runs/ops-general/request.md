---
{
  "schema": 1,
  "type": "adaptive-run",
  "id": "ops-general",
  "created_at": "2026-11-03T14:43:00.799190+00:00",
  "request": {
    "id": "ops-general",
    "type": "learning-request",
    "goal": "Produce and independently review a usable operator recovery runbook and a portable nonrepeating controlled file-effect recovery drill",
    "domain": "operations",
    "acceptance": [
      "executable recovery drill",
      "unique-start binding",
      "no duplicate file effect",
      "original unknown and rejection preserved",
      "usable operator decisions and explicit evidence limits"
    ],
    "budget_seconds": 900,
    "max_actions": 6,
    "allowed_actions": [
      "retrieve",
      "experiment",
      "reflect",
      "deliver"
    ]
  }
}
---


