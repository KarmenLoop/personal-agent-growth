# Shared task and experience index

All four host Agent runs are delivered after independent parent review; their recorded unknowns and failures remain.

- instruction/context.md and latest-node.md: reviewed contributor workshop.
- operations-experiment/baseline/context.md: baseline recovery artifact.
- operations-experiment/general/context.md: same-root cross-domain transfer and repaired rejection attribution.
- operations-experiment/domain/context.md: operations-specific decision-table candidate.

The original instructional mechanism now has one append-only use observation: causal benefit inconclusive. Always read current experience status before a new plan; older snapshots cannot authorize new actions. New ops-general-rejection-cause-binding is a hypothesis, not a promoted default strategy. No new scheduler was registered.
