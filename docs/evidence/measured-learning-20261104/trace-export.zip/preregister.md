---
id: measured-transfer-20261104
type: experiment
status: active
created: 2026-11-04
updated: 2026-11-04
sources: []
---

# Question and scope

Do frozen, evidence-backed general or causal-transfer instructions improve useful unfamiliar tasks over released 0.6.1 instructions, measured by independently checked deliverables, complete trial wall time and native token usage?

The three arms are baseline, general preparation, and causal-transfer preparation. No model training, weight update, reinforcement learning or evaluator editing by a candidate is permitted. Monetary charges are measured only if a provider receipt supplies them; token consumption is a separate resource-cost measure. Account-wide quota changes do not measure a task's cost.

# Blindness and units

Candidate policy text and source-experience choices are frozen before the independent task author publishes target inputs. The author gets historical failure sources, not candidate policies. Executors get only their assigned workspace, inputs, instructions and allowed tools; the evaluator and reference answers stay outside those workspaces. This is procedural separation on one host, not an operating-system security boundary. Record actual read commands and any exposure.

The independent author prepares two primary tasks from at least two practical domains and two reserved tasks. Tasks must produce useful artifacts from genuine project inputs or clearly labeled controlled transformations of historical failures; do not present invented business data as real. The executor must not receive the intended diagnosis or a worked answer. Reserve tasks remain unreleased unless a repair invalidates primary holdout status.

Each primary task has three independent repetitions per arm: 18 initial trial invocations. Randomize arm order within task/repetition blocks with seed 20261104. Keep the visible model configuration, CLI, permissions, task input hashes, tool availability and per-trial deadline identical. Repeated checks inside one trial are not independent samples. Complete all initially valid arms before inspecting comparative outcomes. Infrastructure failures and timeouts stay in the accounting; any repair/retry receives a new attempt identity.

# Measurement and adoption

Capture preparation, host/model event stream, tool activity, checking/retry/review and delivery, including incomplete attempts. Preserve raw stdout/stderr, CLI exit, monotonic wall time, input/output identity, native input/cached/output tokens, available reasoning-token detail and source of every number. Nested time spans cannot be added as separate elapsed time; cached tokens are part of input tokens, not extra tokens. Keep inference time unknown when the host does not expose it.

Freeze task-specific quality criteria before executor dispatch. Check final artifacts independently and retain trace review. Passing test count alone is not task quality. Report per-task results, all repetitions, medians and failures. A candidate may qualify only with no regression in mandatory task quality, at least 10 percent improvement in the declared resource metric, and no more than 10 percent regression in median complete wall time. Unknown monetary fees cannot support a monetary-savings claim. Small samples support this portfolio only; do not claim universal improvement or statistically established causality.

A changed composition must run separately before activation. If no candidate qualifies, retain baseline, both proposals and all results. A demonstrated implementation defect may be repaired, preserving RED and GREEN receipts; a task seen during that repair becomes development evidence. Use the reserved task for a new holdout claim instead of relabeling a rerun unseen.

# Initial run limits

Initial CLI probe and task-author preparation are setup costs, kept separate from task arms and included in the overall development account. Start with a 240-second trial deadline, maximum 24 model command items, no external mutation, and no nested agents in executing trials. Stop launching new trials if observed aggregate native usage exceeds 1,500,000 input-plus-output tokens. Do not silently raise the limits. Only a necessary user-owned budget or permission decision warrants contacting the user.
