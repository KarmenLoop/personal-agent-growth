from pathlib import Path
import hashlib, json, shutil, sys
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parent; REPO=ROOT.parent/'开源发布/personal-agent-growth'
sys.path.insert(0,str(REPO/'scripts'))
import capability_ledger as store
import blind_trials

freeze=blind_trials.read_freeze(ROOT,'measured-transfer-01')
assert (ROOT/'runner-preflight/controller.stdout').is_file()
smoke=json.loads((ROOT/'agent-runs/controller-smoke/runner.json').read_text())
assert smoke['process_exit_code']==0 and smoke['grader_exit_code']==0 and smoke['inputs_and_strategy_unchanged']
sealed=json.loads((ROOT/'sealed/input-manifest.json').read_text())
for row in sealed['task_manifests']:
    if row['path'].startswith('primary_'):
        assert hashlib.sha256((ROOT/'sealed'/row['path']).read_bytes()).hexdigest()==row['sha256']
specs=ROOT/'released-specs';specs.mkdir()
domains={'primary_01':'evidence-publication-audit','primary_02':'scientific-data-qc'}
ref=lambda p:{'path':p.relative_to(ROOT).as_posix(),'sha256':store.sha(p.read_bytes())}
for name,domain in domains.items():
    folder=ROOT/'sealed'/name
    data={'id':name,'type':'blind-task','domain':domain,'role':'holdout','public_dir':f'sealed/{name}/public',
          'evaluator':ref(folder/'private/grader.py'),'provenance':ref(folder/'private/provenance.md')}
    file=specs/(name+'.md');file.write_bytes(store.encode(data,'Independently authored primary target released only after complete strategy freeze.'))
    blind_trials.release(ROOT,'measured-transfer-01',file)
schedule=blind_trials.schedule(ROOT,'measured-transfer-01')
(ROOT/'run-order.json').write_text(json.dumps(schedule,indent=2)+'\n')
prompts=ROOT/'trial-prompts';prompts.mkdir()
requests=ROOT/'trial-requests';requests.mkdir()
common='''You are a frozen execution leaf in a real task study. Use the assigned Skill at skill/SKILL.md, then read input/task.md and complete that task. Task-relative input paths refer to input/. Put every requested deliverable inside output/. The task-local Markdown learning root is learning/; use or reject relevant source experience based on actual task conditions. Preserve failures and uncertainty. Input and skill are read-only references; use scratch/ for local working files. Stay in this workspace, use no network or other agents, and do not look for siblings, evaluators or reference answers. Do not launch additional experiments. You have at most 240 seconds and 24 command items. Native usage and task grading are recorded by the host, not estimated by you. Finish the practical artifacts and keep your final user-facing explanation concise and in Chinese. Use the available Python with -B: PYTHON_PATH
'''.replace('PYTHON_PATH',sys.executable)
for run in schedule['runs']:
    prompt=prompts/(run['id']+'.txt');prompt.write_text(common)
    data={'id':run['id'],'type':'agent-trial-request','task_id':run['task_id'],'arm':run['arm'],
          'replicate':run['replicate'],'attempt':1,'public_dir':run['public_dir'],
          'strategy_dir':'strategies/'+run['arm'],'prompt':ref(prompt),
          'evaluator':ref(ROOT/'sealed'/run['task_id']/'private/grader.py'),
          'model_config':schedule['model_config'],'deadline_seconds':240,'max_commands':24,
          'codex_binary':shutil.which('codex')}
    (requests/(run['id']+'.md')).write_bytes(store.encode(data,'Actual held-out Agent invocation. Inputs and evaluator are independently frozen.'))
(ROOT/'primary-release-receipt.json').write_text(json.dumps({'released_at':datetime.now(timezone.utc).isoformat(),'strategy_freeze_sha256':schedule['frozen_sha256'],'targets':list(domains),'trials':len(schedule['runs']),'comparison_results_seen':False},indent=2)+'\n')
print(json.dumps({'status':'PRIMARY_RELEASED','trials':len(schedule['runs']),'domains':list(domains.values())}))
