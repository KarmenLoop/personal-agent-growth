from pathlib import Path
import hashlib,json,subprocess,sys,time
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parent;REPO=ROOT.parent/'开源发布/personal-agent-growth'
sys.path.insert(0,str(REPO/'scripts'));import capability_ledger as store;import blind_trials
schedule=json.loads((ROOT/'run-order.json').read_text())
names=['run_agent_trial.py','task_costs.py','blind_trials.py','causal_models.py','experience_transfer.py','capability_ledger.py']
hashes=lambda:{name:hashlib.sha256((REPO/'scripts'/name).read_bytes()).hexdigest() for name in names}
initial=hashes(); progress=[];known_tokens=0;total_start=time.monotonic()
study=ROOT/'study';study.mkdir(exist_ok=False)
(study/'started.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'harness':initial,'native_token_ceiling':3000000,'trials':len(schedule['runs'])},indent=2)+'\n')
for index,item in enumerate(schedule['runs']):
    assert hashes()==initial,'Trial harness changed during frozen study'
    assert blind_trials.schedule(ROOT,'measured-transfer-01')==schedule
    if known_tokens>3000000:raise RuntimeError('Predeclared native-use ceiling reached')
    request=ROOT/'trial-requests'/(item['id']+'.md')
    cmd=[sys.executable,'-B',str(REPO/'scripts/run_agent_trial.py'),'--root',str(ROOT),'--request',str(request)]
    start=time.monotonic()
    with (study/(item['id']+'.stdout')).open('wb') as out,(study/(item['id']+'.stderr')).open('wb') as err:
        result=subprocess.run(cmd,stdout=out,stderr=err)
    row={'id':item['id'],'controller_command':cmd,'controller_exit':result.returncode,'controller_window_seconds':time.monotonic()-start}
    if result.returncode:progress.append(row);(study/'progress.json').write_text(json.dumps(progress,indent=2)+'\n');raise RuntimeError('Controller failure retained: '+item['id'])
    runner=json.loads((ROOT/'agent-runs'/item['id']/'runner.json').read_text())
    if not runner['inputs_and_strategy_unchanged']:raise RuntimeError('Input/strategy violation: '+item['id'])
    if runner['cost_record'] is None:raise RuntimeError('Native cost record missing: '+item['id'])
    cost,_,_=store.read_md(Path(runner['cost_record']['path']))
    tokens=cost['usage']['total_tokens']
    if tokens is None:raise RuntimeError('No native usage returned; preserve attempt before further launches')
    known_tokens+=tokens
    row.update({'native_tokens':tokens,'usage_coverage':cost['usage']['coverage'],'cost_record_sha256':runner['cost_record']['sha256']})
    progress.append(row);(study/'progress.json').write_text(json.dumps(progress,indent=2)+'\n')
    print(json.dumps({'completed':index+1,'planned':len(schedule['runs']),'status':'recorded; comparative outcomes not inspected'}),flush=True)
assert hashes()==initial
(study/'complete.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'trials':len(progress),'known_native_tokens':known_tokens,'elapsed_seconds':time.monotonic()-total_start,'harness_before':initial,'harness_after':hashes(),'all_initial_trials_recorded':True},indent=2)+'\n')
print(json.dumps({'status':'ALL_INITIAL_TRIALS_RECORDED','trials':len(progress),'known_native_tokens':known_tokens}),flush=True)
