from pathlib import Path
import hashlib, json, shutil, sys, zipfile
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'开源发布/personal-agent-growth'
sys.path.insert(0,str(REPO/'scripts'))
import capability_ledger as store
import experience_transfer as transfer
import blind_trials

archive=ROOT.parent/'证据判断实测-20261103-01/final-build/personal-agent-growth-0.6.1.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='b06be2552206a3ccc5baadbd7d66dcd6a9ba855ab660c8096d825f659357f852'
frozen=json.loads((ROOT/'policy-freeze.json').read_text())
for name,digest in frozen['policies'].items(): assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
source_base=ROOT.parent/'证据判断实测-20261103-01/candidate'
overlay=['SKILL.md','SKILL.en.md','scripts/experience_transfer.py','scripts/causal_models.py',
         'scripts/task_costs.py','scripts/blind_trials.py','scripts/run_agent_trial.py',
         'references/measured-learning.md','references/measured-learning.en.md']
records={}
for arm in ('baseline','general','domain'):
    target=ROOT/'strategies'/arm; target.mkdir(parents=True,exist_ok=False)
    with zipfile.ZipFile(archive) as z:
        for entry in z.infolist():
            name=Path(entry.filename)
            assert name.parts[0]=='personal-agent-growth' and '..' not in name.parts
            dest=target.joinpath(*name.parts[1:]);dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(z.read(entry))
    if arm!='baseline':
        for name in overlay:
            dest=target/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REPO/name,dest)
        policy=(ROOT/'policies'/f'{arm}.md').read_text()
        for name in ('SKILL.md','SKILL.en.md'):
            p=target/name;s=p.read_text();marker='<!-- Copyright'
            s=s.replace(marker,'\n'+policy+'\n'+marker,1);p.write_text(s)
    memory=target/'memory';memory.mkdir();(memory/'evidence').mkdir()
    refs=[]
    for name in ('response-4.md','receipt-4.json'):
        shutil.copyfile(source_base/name,memory/'evidence'/name)
        refs.append({'path':'evidence/'+name,'sha256':store.sha((memory/'evidence'/name).read_bytes())})
    source={'id':'context-support','type':'mechanism-experience','source_task_id':'invoice-judgment-20261103',
            'domain':'invoice-debugging','problem_structure':['evidence-bound-claim','multiple-entry-paths'],
            'mechanisms':['context-dependent-support'],
            'required_conditions':{'evidence-bound-to-a-specific-context':True},
            'exceptions':['A change in context does not automatically refute independently supported claims.',
                          'Structural similarity alone does not prove a common cause or an effective intervention.'],
            'intervention':'Bind each observation and conclusion to the actual input, version and execution path; test the changed condition before extending or withdrawing the claim.',
            'explanation':'In the actual source task a new entry path demonstrated a cache defect while the original direct-call calculation defect remained valid. The source artifacts show the distinct inputs and actual results.',
            'validation':'supported','executor':'agent/judgment-candidate-20261103','reviewer':'coordinator/independent-source-review',
            'artifacts':refs}
    input_file=memory/'source-input.md'; input_file.write_bytes(store.encode(source,'Source lesson from an actual completed Agent task. It is not a diagnosis for the held-out task.'))
    transfer.add(memory,input_file)
    if arm=='domain':
        model={**source,'id':'context-support-model','validation':'hypothesis','reviewer':None,
               'executor':'coordinator/source-modeler',
               'causal_model':{'variables':{'scope':'context','observation':'evidence','conclusion':'decision'},
                               'relations':[{'from':'scope','to':'observation','relation':'conditions'},
                                            {'from':'observation','to':'conclusion','relation':'supports'}],
                               'predictions':[{'intervention':'Change a condition on which the observation depends',
                                               'expected':'Check whether support for the dependent conclusion still applies',
                                               'falsifier':'The conclusion has independent current support under the changed condition'}]}}
        file=memory/'source-model.md';file.write_bytes(store.encode(model,'Proposed causal abstraction of the same actual source lesson. Target transfer remains unverified.'))
        transfer.add(memory,file)
    records[arm]=blind_trials.inventory(ROOT,'strategies/'+arm)
model={'model':'gpt-6.1-sol','reasoning_effort':'low','transport':'openai-http','training':False,
       'cli_version':'codex-cli 0.165.0-alpha.1.2','backend_weight_identity':'not independently attested',
       'automatic_unrelated_context':False,'nested_agents':False}
plan={'id':'measured-transfer-01','type':'blind-plan','arms':{a:'strategies/'+a for a in records},
      'model_config':model,'repetitions':3,'seed':20261104,'deadline_seconds':240,'metric':'native_tokens'}
file=ROOT/'blind-plan.md';file.write_bytes(store.encode(plan,'Two independently authored primary tasks, three repetitions per arm. Quality and complete-time guardrails are predeclared in preregister.md.'))
result=blind_trials.freeze(ROOT,file)
(ROOT/'candidate-freeze-receipt.json').write_text(json.dumps({'frozen_at':datetime.now(timezone.utc).isoformat(),'policy_freeze':frozen,'strategies':records,'blind_freeze':result,'source_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps({'status':'FROZEN','arms':list(records),'freeze_sha256':result['sha256'],'target_content_seen':False}))
