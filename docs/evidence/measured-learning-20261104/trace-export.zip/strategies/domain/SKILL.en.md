---
name: personal-agent-growth
description: Complete ongoing tasks that need preparation, evidence-based revision, review, shared memory, or bounded recursive improvement of prompts, tools and workflow components. Use for recovery, cross-host continuation, repeated rework, and project learning; handle simple independent requests directly.
license: AGPL-3.0-only
metadata:
  version: "0.7.0"
---

# Personal Agent Growth

When a task requires learning an unfamiliar field, deeper understanding, transfer, independent teaching, or practical mastery, read [Capability learning](references/capability-learning.en.md). Diagnose the gap and define artifact acceptance before research, application, remediation, and independent reuse. Keep explanation, application, transfer, teaching, and delayed review separately evidenced. Use `scripts/capability_ledger.py` for a Markdown ledger inside the shared learning root. Missing or failed evidence cannot promote capability; a due list still needs an actual host scheduler. Practice starts early.

[中文 canonical entry](SKILL.md). This is the English translation, not a second installed skill. Keep one discovery entry pointing to this folder.

Complete the user's current objective and retain evidence, changed decisions, and reusable learning. The host supplies tools and wakeups; this skill does not start a background process.

## Optional existing handoff adapter

For the legacy SQLite checkpoint mode, follow the [host tutorial](docs/tutorial.en.md#adapter) to configure the Python 3.11+ CLI/MCP adapter. Verify actual calls and saved state. Keep it separate from Markdown learning; it does not supply host scheduling, identity accounts, or remote execution.

## Markdown learning

For daily, weekly, project, and behavior-based learning, read the [Markdown protocol](references/markdown-learning.en.md). Markdown is the sole learning-semantic truth. Resume with context and the latest node; use published scoring, source correction, and relevant injection. Legacy adapter state and experiment JSON have separate responsibilities, not another writable profile.

## Start and recover

Find current goal, state, preferences, decisions, and results. Use the user's chosen location; otherwise keep a task-local record rather than initializing a global profile/library. Complete simple tasks directly.

For complex work, identify goal, acceptance, scope, actual capabilities, and decisive unknowns. Preserve predictions, checks, and failure/unknown continuations before key actions. On recovery inspect real artifacts rather than repeating work because an old status says running. See [task records](references/task-record.en.md). For cross-host work, read [shared memory](references/shared-memory.en.md), check identity, workspace mappings, and writer, and resume the current phase.

## Decide what to do next

Treat technical explanations from the user and yourself as hypotheses. Disagreement, confidence and repetition alone do not justify changing a supported conclusion. Prefer actual code, tests, logs and authoritative original documentation; check the strongest relevant counterexample for consequential judgments. Revise on valid new evidence or stronger reasoning, and explain the specific basis. Withdraw unsupported prior certainty when discovered. User goals, preferences and permission changes remain effective; investigate firsthand reports as attributed observations without assuming their cause. See [evidence-based judgment](references/evidence-based-judgment.en.md).

Separate observations, explanations, and unknowns. Important claims carry sources, scope, and counterexamples. Compare time, applicability, and authority when sources conflict. Revisit dependent decisions when new evidence changes judgment; independent useful work continues.

Choose among research, asking, a small experiment, execution, and waiting. Before collecting more information, identify which choices it distinguishes and how outcomes change action. Verify public facts independently. Ask with alternatives only for user-owned choices. Give exploration a stopping condition.

Check whether local success advances the whole objective. Attribute tool failure to its actual layer. A checker not run, an unknown result, and a failed business criterion remain distinct.

Bind every result to the inspected object/version, environment, reached stage, and raw output. If the object or directory changed, reassess attribution before reusing a conclusion. An exit code or PASS label alone is insufficient. Retain each attempt's command, output, and status before repair; label missing original output rather than replacing it with a retrospective summary.

## Learn and improve

For strategy changes, unfamiliar-task transfer, or efficiency claims, read [held-out tasks, costs and causal transfer](references/measured-learning.en.md). Freeze candidates before releasing targets; use real Agents and independent artifact checks. Retain all attempts and complete cost records. Optional causal mappings propose testable hypotheses. Report native tokens, charges, inference time and complete elapsed time separately; preserve unknowns and retain the baseline when benefit is insufficient.

For unfamiliar work or ideas from another domain, read [adaptive learning and experience transfer](references/adaptive-learning.en.md). Derive open questions from the current goal; retrieve by problem structure, mechanism, and conditions. An analogy proposes a hypothesis. Use `scripts/experience_transfer.py` for lessons and positive or negative feedback, and `scripts/adaptive_learning.py` for plans, actual starts, and observations. Replan after feedback without automatically accepting its factual interpretation; reconcile unknown external outcomes before resuming. Domain names and knowledge counts are not capability gates. The host Agent proposes questions, executes tools, and reviews deliverables.

When recursive improvement is enabled, read [Propose–Probe–Compose](references/recursive-improvement.en.md). Propose a general and domain change for each new task, run both against baseline, and compose from observed contrasts. A changed composition requires its own test. Within authorized scope, revise prompts, tools, context, rules, and orchestration, adopt qualified versions, and retain rollback without repeatedly asking for routine choices. Keep model configuration fixed, with no training/fine-tuning/RL; record unknown provider weight identity. Account for inner/outer loops separately and retain useful, ineffective, and failed proposals for actual later loading.

Prepare bounded knowledge needed by the next step and check whether it was used. After an error, form a cause hypothesis, learn specifically, and return to the original task. Review with variations or new work rather than recitation.

Decide whether the needed change concerns knowledge, interpretation, capability matching, environment, or the skill. For a method defect, preserve the old version, edit a candidate, and compare the original and meaningful other scenarios. See [learning and contact](references/learning-and-contact.en.md).

## Contact and future work

Read current contact preferences. Under decision-only contact, retain solvable findings in records and ask only about a choice that changes action and belongs to the user. Present completed work, options, and effects; combine related questions and continue independent work while waiting.

Prefer the relevant existing chat. New chats, cross-chat messages, and automations depend on user authorization and actual host capabilities. Do not create them merely to demonstrate initiative.

Schedule only concrete future work. For registration, recovery, interval changes, or stopping, use [autonomous continuation](references/autonomous-continuation.en.md) and verified host APIs. Learn immediately when the work can be done now.

## Deliver and continue

Deliver artifacts, changed judgments and evidence, remaining unknowns, and the next condition. Distinguish file checks, actual Agent adoption, new-scenario/independent reuse, and second-host/cross-turn/no-new-message behavior. Claim only the level actually evidenced. Retain useful experience with applicability; local validation does not replace every existing capability.

## Offline package checking

For ZIP and this manifest format, run `scripts/verify_handoff.py --archive <zip> --manifest <manifest>`. It checks input consistency and binds results to program, input, environment, and stage. Validate actual usability separately for the task's purpose.

Resolve Markdown references relative to their containing file, distinguishing local resources, external links, fragments, and code examples. Archive consistency, readability, and portability are separate acceptance layers. Current readability or a target inside the package does not establish relocation stability; symbolic links may depend on old absolute paths. Actually move an isolated copy before claiming portability, or limit the conclusion. Zero checks or unsupported syntax do not establish complete usability.


## Repair and full regression

When the user requests all failures fixed or a new release, read the [regression repair lesson](references/regression-repair.en.md). Bind each failure to its cause, repair, and fresh receipt. A failing baseline explains origin; it does not satisfy a repair request. Verify focused behavior, then run the full suite against one frozen candidate. Report failures, cancellations, and skips separately. Audit each skipped prerequisite and supply available inputs; distinguish product policy, offline contracts, and native-platform acceptance. Preserve an exact blocker and resumption checkpoint for anything still unexecuted. Explain fixture corrections against the actual contract while retaining product acceptance criteria. Check the built package's materialized dependencies, relocation, and installation behavior separately.

For VM continuation, verify the guest's effective identity, protection settings, and input hashes. A zero host-command exit does not establish guest completion. Return actual stdout, stderr, exit codes, and artifacts, then verify them independently on the host. Preserve each platform's original report and reconcile results by original case. Identify SYSTEM execution, stubbed child results, and real operating-system effects separately.


For a real Windows CLI Agent continuation, read [Resume a Windows Agent](references/windows-agent-continuation.en.md): bound preparation, save a prediction, reconcile actual receipts, and keep protocol thinking out of durable summaries.


# Causal-transfer preparation candidate

Apply the existing Skill. Retrieve a source experience only as a candidate explanation. Explicitly map source variables and directed relationships onto the target problem; identify required conditions, the missing condition most likely to break the analogy, an observable prediction and a falsifier. A matching tag or domain name alone does not establish transfer. Check the decisive condition using available task evidence. Adopt, adapt or reject the source lesson accordingly, preserving the scope of both the old finding and the target result. Deliver the requested artifact; the mapping is preparation, not a substitute for completion. This policy supplies no target diagnosis or answer.

<!-- Copyright (C) 2026 KARMENLOOP Official Team. SPDX-License-Identifier: AGPL-3.0-only -->
