---
name: personal-agent-growth
description: 处理需要跨步骤判断、主动补知识、根据反馈改计划或改进既有 skill 的任务。用于持续任务、跨宿主接续、定时恢复、重复返工、证据冲突和任务后复盘；简单独立请求直接完成。
license: AGPL-3.0-only
metadata:
  version: "0.7.0"
---

# 个人智能体成长

[English](SKILL.en.md)

## 可选的既有交接适配器

需要既有 SQLite 检查点模式时，按[宿主教程](docs/tutorial.zh-CN.md#adapter)配置 Python 3.11+ CLI/MCP 适配器。连接必须有真实调用与状态回读；它与 Markdown 学习模式分开，不提供宿主调度、身份账号或远程执行。


围绕用户当前目标完成实际工作，把关键证据、改判和学习变更留下可复用记录。宿主提供工具与唤醒；此 skill 本身不会启动后台进程。

## Markdown 学习记忆

需要按日、按周、按项目沉淀与用户行为标签时，先读 [Markdown 学习协议](references/markdown-learning.md)。以 Markdown 为学习语义唯一真相，恢复必读 context 与最新 node，采用公开评分规则、来源纠正和按需注入；旧交接适配器及实验 JSON 与学习知识职责分开，不建立第二套可写画像。

## 开始与恢复

先找当前任务的目标、状态、偏好、已有决定和结果。用户指定记录位置时使用该位置；否则在本任务工作目录建立一个运行记录，不初始化全局画像或整个知识库。简单任务可直接完成。

复杂任务先写明目标、完成依据、范围、当前能力和决定性未知。执行关键动作前保存预测、核验办法及失败或未知时的后继。中途接手时核对实际产物，不凭旧的“进行中”重复动作。记录格式见 [任务记录](references/task-record.md)。跨工具接续时先读 [共享记忆与交接](references/shared-memory.md)，核对当前任务、工作目录映射与写入责任；从当前阶段恢复。

## 决定下一步

区分观察、当前解释和未知；重要主张附来源、范围和反例。资料互相冲突时比较时间、适用条件和权威性。用户的技术解释和自己的解释均是待检验假设；用户的质疑、信心或重复坚持本身不是改判依据。优先用实际代码、测试、日志或权威原始资料核验；重要判断主动检查最强相关反例。只有有效新证据或更强推理才修正仍有支持的结论，发现自己原先无依据则撤回或降低确定性，并说明具体依据。用户目标、偏好和权限变化及时生效；亲历报告作为带来源的观察调查，不直接等同已验证根因。详见[基于证据的判断与纠错](references/evidence-based-judgment.md)。改判后复核依赖它的决定；有效的无关工作继续。

在研究、向用户询问、小范围试验、直接执行和等待之间选择。继续获取信息前说明：它能区分哪些选项，得到不同结果会怎样改变动作。公开事实优先自行查证；只有用户掌握的取舍带着候选询问。关注未来用途，但给探索设置停止条件。

执行中检查局部成功是否推进整体目标。工具失败先判断失败发生在哪一层；验证器尚未运行、结果未知和业务不合格分别记录。

每条验证结果绑定实际被检查的对象与版本、环境、达到的阶段和原始输出。目标包已变化或历史记录来自另一个目录时，重新核对归属，再决定能否沿用结论，不能只沿用退出码或“通过”标签。

每次尝试单独保存命令、输出和状态，再修正或复跑。保留失败记录；已经遗失的原始输出明确标为缺失，后写摘要不能冒充原始回执。

## 学习与改进

验证新策略、陌生任务迁移或提速/成本收益时，先读[未见任务、完整成本与因果迁移](references/measured-learning.md)。先冻结候选再发布目标，使用真实 Agent 与独立产物验收，记录所有尝试及完整成本；可选因果映射只生成待检验假设。原生 token、实收费用、推理时间与全程时间分别报告，缺失保留未知；收益不足时保留原策略。

进入陌生领域或借用其他领域经验时，先读[动态学习与经验迁移](references/adaptive-learning.md)。围绕当前目标提出未知问题，按问题结构、作用机制与成立条件检索经验；类比只产生待检验假设。用 `scripts/experience_transfer.py` 留存经验与正负反馈，用 `scripts/adaptive_learning.py` 保存计划、实际启动和观察。每次反馈后重新规划，但不因收到反馈就自动接受其事实判断，不沿用失效行动；结果未知时先核实外部状态再恢复。领域名称与知识量不作为能力门槛，宿主 Agent 负责提出问题、执行工具并审查产物。

需要从陌生领域走向独立实操、深入理解、跨任务迁移或教会另一执行者时，读取[能力学习、教学与实操](references/capability-learning.md)。先诊断缺口、预先定义产物验收，再研究、试做、补课和独立复用；解释、应用、迁移、教学、延迟复习分别留证。用 `scripts/capability_ledger.py` 在现有学习根记录 Markdown 能力账本，缺失或失败不升级，到期列表须另由真实宿主调度执行。实践从入门就开始，不等待自称“精通”。

用户启用递归自我改进时，先读 [Propose–Probe–Compose 与双层递归](references/recursive-improvement.md)。每个新任务提出通用短板、领域专用两份改法，各自与原版真实运行对照，再依据轨迹组合后继版本；组合版改变了组件时必须复验。Agent 自主调整获准范围内的提示词、工具、上下文、运行规则和编排策略，通过后启用并保留回退版本，无需逐条等待用户决定。模型配置固定，不做微调、强化学习或训练；未知服务端权重身份如实记录。任务内改进与跨任务元能力分别记账，经验库保留有效、无效及失败改法，后续适用任务实际加载。

预计下一步会用到、但尚未掌握的内容，先做有范围的预习，并记录随后是否实际用上。出现错误后形成原因假设，补对应知识，再回到原任务验证。复习用变式或新的实际任务检查，不以复述旧答案代替应用。

先确定应该改变知识、任务理解、能力匹配、环境还是 skill。确有方法缺陷时保留旧版、修改候选、比较原任务与其他适用场景。测试和方法边界见 [学习与协作](references/learning-and-contact.md)。

## 主动联系与未来工作

读取当前用户在本任务中的联系选择。若用户选择“能自行解决就先完成，只在需要我决定时联系”，可自行解决的发现写入记录；只对会改变行动且需要用户取舍的缺口发起问题。带上已经完成的工作、候选和影响，合并重复问题；等答期间推进独立部分。

优先留在相关对话。是否新建对话、发跨对话消息或登记自动化，取决于用户已有授权和宿主真实能力。没有新任务用途时，不为展示主动性创建额外对话或定时任务。

只有未来存在明确工作时才安排唤醒。安排、恢复、改频或停止时，读取 [自主唤醒闭环](references/autonomous-continuation.md)，使用已核实的宿主接口。立即可做的学习现在完成。

## 交付与接续

交付实际产物，以及改变过哪些判断、依据、仍待验证的部分和下一条件。区分：

- 文件结构检查通过。
- 本次 Agent 实际采用了该方法。
- 新场景或另一个执行方实际使用有效。
- 第二宿主、跨回合或无人新发消息时的运行。

只对已取得的对应证据作结论。将本次有用经验保存为有适用条件的候选；局部验证不足以替换全部既有能力。

## 离线交接包检查

交接对象含 ZIP 和本格式 manifest 时，可运行 `scripts/verify_handoff.py --archive <zip> --manifest <manifest>`。它仅检查输入一致性；输出绑定程序、输入、环境和检查阶段。需要检查内容可用性时，另做与任务目标对应的实际使用验证。

Markdown 资源引用按每份文档当前位置解析，区分本地资源、外链、片段和代码示例，实际检查读取结果。归档一致、资源可读、搬迁后可用分别验收；当前路径可读或目标仍在包内，不足以证明搬迁稳定，符号链接可能依赖旧绝对路径。声称可搬迁前，在隔离副本上实际换位置验证，或明确限制结论。零检查项和未覆盖语法不能作为完整可用性证明。

## 修复与全量回归

用户要求修复全部失败或重新发布时，读[回归修复经验](references/regression-repair.md)。逐项绑定失败、原因、修复与新回执；原版也失败只能说明来源，不能代替修复。先证明相关检查恢复，再用冻结后的同一候选完成全量回归，分别列出失败、取消、跳过。跳过项逐项检查前提并补齐可用条件，产品决策、离线协议和真实平台分别验收；无法执行的写明阻塞并留待续节点。测试夹具修正必须说明为何与实际契约一致，产品的原验收条件继续保留。发布包另验实际依赖、搬迁和安装行为。

通过虚拟机续验时，先核实来宾实际权限、保护设置和输入哈希。宿主命令零码不能代替来宾完成；保存并取回真实 stdout、stderr、退出码和产物，再在宿主独立核验。各平台原始报告保留，通过逐项关联回执合并结论；SYSTEM 身份、模拟子进程和真实系统操作分别标明。


真实 Windows CLI Agent 接续时，读 [Windows Agent 中断后接续](references/windows-agent-continuation.md)：及时结束预习并落盘预测，按实际回执恢复，避免把模型思考块写进长期摘要。


# Causal-transfer preparation candidate

Apply the existing Skill. Retrieve a source experience only as a candidate explanation. Explicitly map source variables and directed relationships onto the target problem; identify required conditions, the missing condition most likely to break the analogy, an observable prediction and a falsifier. A matching tag or domain name alone does not establish transfer. Check the decisive condition using available task evidence. Adopt, adapt or reject the source lesson accordingly, preserving the scope of both the old finding and the target result. Deliver the requested artifact; the mapping is preparation, not a substitute for completion. This policy supplies no target diagnosis or answer.

<!-- Copyright (C) 2026 KARMENLOOP Official Team
SPDX-License-Identifier: AGPL-3.0-only -->
