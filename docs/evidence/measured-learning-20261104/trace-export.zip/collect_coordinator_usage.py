"""Capture this request's native usage metadata, not conversation/reasoning text."""
from pathlib import Path
import hashlib,json,os

ROOT=Path(__file__).resolve().parent
source=Path('<HOME>/.codex/sessions/2026/10/20/rollout-2026-10-20T21-54-00-01a15997-27e8-7c80-841f-ff2a7ad1ace1.jsonl')
size=source.stat().st_size;offset=max(0,size-16*1024*1024)
with source.open('rb') as stream:stream.seek(offset);raw=stream.read()
if offset:raw=raw.split(b'\n',1)[1]
boundary=None;selected={};latest_counter=None;turn_ids=set();other_threads=set()
for line in raw.splitlines():
    try:item=json.loads(line)
    except ValueError:continue
    payload=item.get('payload',{})
    if item.get('type')=='response_item' and payload.get('role')=='user':
        text=' '.join(block.get('text','') for block in payload.get('content',[]) if isinstance(block,dict))
        if '就先把真实任务盲测' in text and '以上需要优化' in text:
            boundary=item.get('timestamp');selected={};latest_counter=None;turn_ids=set();other_threads=set()
    if not boundary or item.get('type')!='token_usage_record':continue
    if payload.get('thread_id')!=os.environ.get('CODEX_THREAD_ID'):
        other_threads.add(payload.get('thread_id'));continue
    usage=payload.get('usage');response_id=payload.get('response_id')
    if not isinstance(usage,dict) or not response_id:continue
    if response_id in selected:assert selected[response_id]['usage']==usage,'Conflicting native response usage'
    selected[response_id]={'timestamp':item.get('timestamp'),'ordinal':item.get('ordinal'),
                           'response_id':response_id,'turn_id':payload.get('turn_id'),
                           'root_turn_id':payload.get('root_turn_id'),'usage':usage}
    turn_ids.add(payload.get('turn_id'));latest_counter=payload.get('turn_token_usage')
totals={key:sum(row['usage'].get(key,0) for row in selected.values()) for key in ('input_tokens','cached_input_tokens','cache_write_input_tokens','output_tokens','reasoning_output_tokens','total_tokens')}
assert totals['total_tokens']==totals['input_tokens']+totals['output_tokens']
matched=bool(selected) and len(turn_ids)==1 and latest_counter is not None and all(totals[k]==latest_counter.get(k) for k in totals)
result={'scope':'Coordinator native usage for the current user request, right-censored at this snapshot; excludes later publication/answer tokens and other agents unless separately reported. No chat text or private reasoning exported.',
        'source_path':str(source),'source_bytes_at_read':size,'tail_offset':offset,'tail_sha256':hashlib.sha256(raw).hexdigest(),
        'request_timestamp':boundary,'thread_id':os.environ.get('CODEX_THREAD_ID'),'turn_ids':sorted(turn_ids),
        'native_responses':list(selected.values()),'known_native_usage':totals,'matches_native_turn_counter':matched,
        'other_thread_count_in_this_log':len(other_threads),'billed_usd':None,
        'inference_seconds':None,'not_a_per_arm_allocation':True}
(ROOT/'coordinator-native-usage.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'current_request_found':boundary is not None,'native_response_records':len(selected),'complete_through_snapshot':matched,'other_threads':len(other_threads)}))
