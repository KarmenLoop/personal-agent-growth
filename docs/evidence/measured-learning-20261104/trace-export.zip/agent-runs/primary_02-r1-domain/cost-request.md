---
{
  "id": "primary_02-r1-domain",
  "type": "task-cost-request",
  "task_id": "primary_02",
  "arm": "domain",
  "replicate": 1,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_02-r1-domain/events.jsonl",
    "sha256": "62aee5beea4f486ea96272af9bdd3ae5e87fc1b929f6297b99f5b594ce2f8bbc"
  },
  "timeline": {
    "path": "agent-runs/primary_02-r1-domain/timeline.jsonl",
    "sha256": "fc681111688f3ec9a3504c2a62cf4756b320f446bc3fc8f89988dea0860ee480"
  },
  "measurement": {
    "path": "agent-runs/primary_02-r1-domain/measurement.json",
    "sha256": "29706c761a2b5ff06e7cc655c33dafe015e15204d060e6015c923af4f9f36f5a"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
