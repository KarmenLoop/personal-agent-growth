---
{
  "id": "primary_02-r3-baseline",
  "type": "task-cost-request",
  "task_id": "primary_02",
  "arm": "baseline",
  "replicate": 3,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_02-r3-baseline/events.jsonl",
    "sha256": "45584f35a55e35c15a560abbd4e82b6cf74d9efdaf264e1116a0e27e25cbe706"
  },
  "timeline": {
    "path": "agent-runs/primary_02-r3-baseline/timeline.jsonl",
    "sha256": "3f95e7eaedcea3cfe345c1a33a5c965de578def8313a65b35ab0eb9c4424efd9"
  },
  "measurement": {
    "path": "agent-runs/primary_02-r3-baseline/measurement.json",
    "sha256": "30c21f4a2aa70330a12702543da06fcb80f1be364f00db16fb22f0945d919d42"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
