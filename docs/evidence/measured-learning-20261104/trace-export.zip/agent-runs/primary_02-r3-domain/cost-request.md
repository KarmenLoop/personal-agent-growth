---
{
  "id": "primary_02-r3-domain",
  "type": "task-cost-request",
  "task_id": "primary_02",
  "arm": "domain",
  "replicate": 3,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_02-r3-domain/events.jsonl",
    "sha256": "c7a46acc6a2b746a1f6158c693a5c666c7dd043d2a7c93d718b8b3e4510181e2"
  },
  "timeline": {
    "path": "agent-runs/primary_02-r3-domain/timeline.jsonl",
    "sha256": "a24ec6ef1f50b7fe8c125f5a5f33be4f85f869e09b591a4d6b0e3dcb623be573"
  },
  "measurement": {
    "path": "agent-runs/primary_02-r3-domain/measurement.json",
    "sha256": "d0f74d6a7058657ffd227c837290802f9249b8c50b1ee71bff4e032249e961d4"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
