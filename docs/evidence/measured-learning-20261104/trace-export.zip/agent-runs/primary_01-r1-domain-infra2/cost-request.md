---
{
  "id": "primary_01-r1-domain-infra2",
  "type": "task-cost-request",
  "task_id": "primary_01",
  "arm": "domain",
  "replicate": 1,
  "attempt": 2,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_01-r1-domain-infra2/events.jsonl",
    "sha256": "a8920d349310dd3e9ee3501abfd2cce625f33c13a899a5517d04332b4e06cbd9"
  },
  "timeline": {
    "path": "agent-runs/primary_01-r1-domain-infra2/timeline.jsonl",
    "sha256": "4c573375a533a8555789b18d0b2997580520224c534548350cdf020b047588c4"
  },
  "measurement": {
    "path": "agent-runs/primary_01-r1-domain-infra2/measurement.json",
    "sha256": "ee0ef1c05013ce0c7778dece85dba472f41c1c7fdc0189bb72b04ab1b6910d08"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
