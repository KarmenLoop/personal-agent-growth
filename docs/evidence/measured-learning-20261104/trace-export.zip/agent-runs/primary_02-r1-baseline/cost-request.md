---
{
  "id": "primary_02-r1-baseline",
  "type": "task-cost-request",
  "task_id": "primary_02",
  "arm": "baseline",
  "replicate": 1,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_02-r1-baseline/events.jsonl",
    "sha256": "883342a4bd30185a3fa451f2aa18519146f319509cf92a2246386bb5f6aad45f"
  },
  "timeline": {
    "path": "agent-runs/primary_02-r1-baseline/timeline.jsonl",
    "sha256": "3655200d76aa995e0693fd914ff00a5caca6aa7231822440cc454f58dbb1016f"
  },
  "measurement": {
    "path": "agent-runs/primary_02-r1-baseline/measurement.json",
    "sha256": "d8ef8e10015e5433c602767f4224fa265c45cbe2f553af59d65b9263c3239cb4"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
