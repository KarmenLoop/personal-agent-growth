---
{
  "id": "primary_01-r3-domain",
  "type": "task-cost-request",
  "task_id": "primary_01",
  "arm": "domain",
  "replicate": 3,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_01-r3-domain/events.jsonl",
    "sha256": "75afd48c1a0fdc6215b1faa6f33569fc421e6015b8f31cd21fc20e05b25fa554"
  },
  "timeline": {
    "path": "agent-runs/primary_01-r3-domain/timeline.jsonl",
    "sha256": "fbd3402a660e8038c7ae3795a5f7e240ccddfb758036b3e996bb3aa00c33479b"
  },
  "measurement": {
    "path": "agent-runs/primary_01-r3-domain/measurement.json",
    "sha256": "5cde9ce8b5568b64ddac3c8d7e761354efd028ccf85024e841230963a0ffc158"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
