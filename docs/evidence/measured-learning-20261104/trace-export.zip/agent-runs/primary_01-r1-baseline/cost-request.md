---
{
  "id": "primary_01-r1-baseline",
  "type": "task-cost-request",
  "task_id": "primary_01",
  "arm": "baseline",
  "replicate": 1,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_01-r1-baseline/events.jsonl",
    "sha256": "3d8f4b5482ce68f87ac29184899905c8d869f59902e8e27c37bee01517d89050"
  },
  "timeline": {
    "path": "agent-runs/primary_01-r1-baseline/timeline.jsonl",
    "sha256": "269676aae8483e008a7fb9cfe9f2b4dfbb35959e52b1aa45eecbdf459841cb11"
  },
  "measurement": {
    "path": "agent-runs/primary_01-r1-baseline/measurement.json",
    "sha256": "7ad670b1833016ce1e60e01956234d6d26a6397b83095fbbeb026cc29500966e"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
