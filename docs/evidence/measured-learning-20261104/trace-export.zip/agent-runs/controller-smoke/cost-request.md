---
{
  "id": "controller-smoke",
  "type": "task-cost-request",
  "task_id": "controller-smoke",
  "arm": "baseline",
  "replicate": 1,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/controller-smoke/events.jsonl",
    "sha256": "f74234bb63f027bac00e2b9b2dc07ebbdbbc5b808a2da8bd3737f42dbb3b13dc"
  },
  "timeline": {
    "path": "agent-runs/controller-smoke/timeline.jsonl",
    "sha256": "5b026fedd037a824bef1f6898a14e7cc0d96d8b76d2e17bb3c7a005ba09dc4be"
  },
  "measurement": {
    "path": "agent-runs/controller-smoke/measurement.json",
    "sha256": "0fc9125bbaef89ae90138de0fc2027ad00bd997fac3d5d828504024feb132a75"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
