---
{
  "id": "primary_01-r2-general",
  "type": "task-cost-request",
  "task_id": "primary_01",
  "arm": "general",
  "replicate": 2,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_01-r2-general/events.jsonl",
    "sha256": "c240a8fae25570bf92d36beda45285be08491a39de3b6512f747235e85eaeabd"
  },
  "timeline": {
    "path": "agent-runs/primary_01-r2-general/timeline.jsonl",
    "sha256": "d898325923d8e9f5eb451081514410b62fd7a435518c3727a7caebfa217f76cd"
  },
  "measurement": {
    "path": "agent-runs/primary_01-r2-general/measurement.json",
    "sha256": "17fdb78a214eaf730907fdda5b2fa0d62af5ecaceeb0da6cdd41ea9decfa1dce"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
