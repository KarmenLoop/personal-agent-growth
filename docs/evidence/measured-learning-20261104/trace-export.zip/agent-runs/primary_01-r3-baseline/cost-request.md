---
{
  "id": "primary_01-r3-baseline",
  "type": "task-cost-request",
  "task_id": "primary_01",
  "arm": "baseline",
  "replicate": 3,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_01-r3-baseline/events.jsonl",
    "sha256": "4fd67ec7ee0b63e00ad8f3c84c5c80007881d6863e70a7bd3977ead746690eba"
  },
  "timeline": {
    "path": "agent-runs/primary_01-r3-baseline/timeline.jsonl",
    "sha256": "7fb52725b9e40ffa5c2aad24ba8ee0348be2703fb25d30b00f8fe15ed1125712"
  },
  "measurement": {
    "path": "agent-runs/primary_01-r3-baseline/measurement.json",
    "sha256": "98abb5a2cd06783ca7191fa5a4495636e1718391405e317aba34d9808c98b5b0"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
