---
{
  "id": "primary_01-r1-baseline-infra2",
  "type": "task-cost-request",
  "task_id": "primary_01",
  "arm": "baseline",
  "replicate": 1,
  "attempt": 2,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_01-r1-baseline-infra2/events.jsonl",
    "sha256": "6dc04bc04f4af2dd7d09f3d437b7ec2d1ca88ebcde498d80411e7f4b62b8c6d5"
  },
  "timeline": {
    "path": "agent-runs/primary_01-r1-baseline-infra2/timeline.jsonl",
    "sha256": "4b18caa6f2e8e11daa87d5d3e973284d5117db35dec215a5b51e4908d0f0ce2b"
  },
  "measurement": {
    "path": "agent-runs/primary_01-r1-baseline-infra2/measurement.json",
    "sha256": "3b5cc764ea23d0df9f0986fcb402955171c5e924f4fcb41942ecd340a9bcf3a2"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
