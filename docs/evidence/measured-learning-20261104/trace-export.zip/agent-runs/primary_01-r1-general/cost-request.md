---
{
  "id": "primary_01-r1-general",
  "type": "task-cost-request",
  "task_id": "primary_01",
  "arm": "general",
  "replicate": 1,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_01-r1-general/events.jsonl",
    "sha256": "b87e4641864b2398d1823bf28affa1d770ce056830850a1f751509228c38f7de"
  },
  "timeline": {
    "path": "agent-runs/primary_01-r1-general/timeline.jsonl",
    "sha256": "219686e82893f8b0df5f67b3aa83742d21cbb3bd085798e86023655382eead13"
  },
  "measurement": {
    "path": "agent-runs/primary_01-r1-general/measurement.json",
    "sha256": "304674b30b73cda539d7c844cdbd70769ea0747772f2d569ec6263d65f71a424"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
