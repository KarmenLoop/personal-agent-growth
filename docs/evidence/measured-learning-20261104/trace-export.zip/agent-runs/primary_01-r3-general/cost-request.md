---
{
  "id": "primary_01-r3-general",
  "type": "task-cost-request",
  "task_id": "primary_01",
  "arm": "general",
  "replicate": 3,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_01-r3-general/events.jsonl",
    "sha256": "fff5095595e20bb84da9b842723d3082fc73c757f42d111b076dec2d3df5f48d"
  },
  "timeline": {
    "path": "agent-runs/primary_01-r3-general/timeline.jsonl",
    "sha256": "05386f97cec764816591ae3070a429baadc8d5195fe446c6cbbcdef7d68988c6"
  },
  "measurement": {
    "path": "agent-runs/primary_01-r3-general/measurement.json",
    "sha256": "2283911dbf957178cb7f3236904472689097538aee5ac94cbeb0516510750d41"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
