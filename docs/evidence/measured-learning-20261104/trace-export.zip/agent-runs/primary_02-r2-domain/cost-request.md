---
{
  "id": "primary_02-r2-domain",
  "type": "task-cost-request",
  "task_id": "primary_02",
  "arm": "domain",
  "replicate": 2,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_02-r2-domain/events.jsonl",
    "sha256": "58b388c4fd2d5d0074485d2fb5a15c955f99d26e5424d08082010e3d63ee78ef"
  },
  "timeline": {
    "path": "agent-runs/primary_02-r2-domain/timeline.jsonl",
    "sha256": "ac2d5d23ad2884300dbada58d6bfcb4c11ff26bd72608d7fdd8ae0e1d6c2fdf4"
  },
  "measurement": {
    "path": "agent-runs/primary_02-r2-domain/measurement.json",
    "sha256": "743970a16903147b1f50a3a5ea0698f62d96bf061d78597714b4e3ca9b78ab64"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
