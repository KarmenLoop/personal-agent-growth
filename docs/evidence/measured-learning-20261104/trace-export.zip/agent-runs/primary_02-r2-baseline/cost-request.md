---
{
  "id": "primary_02-r2-baseline",
  "type": "task-cost-request",
  "task_id": "primary_02",
  "arm": "baseline",
  "replicate": 2,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_02-r2-baseline/events.jsonl",
    "sha256": "bb97fce33c504e9a84d0c89630210045318a6e4e6a4ad1bb74386f120011dbe3"
  },
  "timeline": {
    "path": "agent-runs/primary_02-r2-baseline/timeline.jsonl",
    "sha256": "d49e44506adf9df65dd7fe5153a8a8b3d49667b9dd1e2dd1d36628f3e5ed6e2e"
  },
  "measurement": {
    "path": "agent-runs/primary_02-r2-baseline/measurement.json",
    "sha256": "85306e142c4c08ae46858de7cabc53319aed5866d98aba48340cb1cda593e7a1"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
