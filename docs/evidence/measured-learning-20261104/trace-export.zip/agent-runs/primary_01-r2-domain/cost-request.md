---
{
  "id": "primary_01-r2-domain",
  "type": "task-cost-request",
  "task_id": "primary_01",
  "arm": "domain",
  "replicate": 2,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_01-r2-domain/events.jsonl",
    "sha256": "6a0a4ba877bf71704728e9efcac4ea2c6091ed873cee5e2760200b6470fe5fd3"
  },
  "timeline": {
    "path": "agent-runs/primary_01-r2-domain/timeline.jsonl",
    "sha256": "af56c3e3e5d881374ce39f3994dda052dc7f4d503e0702f41a551504a1fef798"
  },
  "measurement": {
    "path": "agent-runs/primary_01-r2-domain/measurement.json",
    "sha256": "4be69e2ab790cb6e0f5c21fe2e97e3b22be7cea2a6aa0560f3a9c774610315be"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
