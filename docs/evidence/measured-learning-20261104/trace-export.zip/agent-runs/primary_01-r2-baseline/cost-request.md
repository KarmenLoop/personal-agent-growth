---
{
  "id": "primary_01-r2-baseline",
  "type": "task-cost-request",
  "task_id": "primary_01",
  "arm": "baseline",
  "replicate": 2,
  "attempt": 1,
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "events": {
    "path": "agent-runs/primary_01-r2-baseline/events.jsonl",
    "sha256": "588b7abf3ea22d3081bdb0f3cb1cfe44bbb1018ecb2c28c5fec15041c8463740"
  },
  "timeline": {
    "path": "agent-runs/primary_01-r2-baseline/timeline.jsonl",
    "sha256": "e2e96006d48af8ba1089b04d5a45d074a6f504c01bb6d236399e6f3cdffe9b67"
  },
  "measurement": {
    "path": "agent-runs/primary_01-r2-baseline/measurement.json",
    "sha256": "f5634b7580ccc69f9dfd5ce93229f0a3a8d4d7a017cbd1f1766dd96746169cf7"
  }
}
---

Actual host invocation. Billing and model-inference time may be unavailable.
