from pathlib import Path
import csv,hashlib,json,statistics,sys
from datetime import datetime

ROOT=Path(__file__).resolve().parent;REPO=ROOT.parent/'开源发布/personal-agent-growth'
sys.path.insert(0,str(REPO/'scripts'));import capability_ledger as store;import task_costs;import blind_trials
assert (ROOT/'study/complete.json').exists(),'Do not inspect comparative outcomes before all planned attempts finish'
schedule=json.loads((ROOT/'run-order.json').read_text());account=json.loads((ROOT/'study/operational-progress.json').read_text())
assert blind_trials.schedule(ROOT,'measured-transfer-01')==schedule
all_rows=[]
for item in account:
    folder=ROOT/'agent-runs'/item['id'];runner=json.loads((folder/'runner.json').read_text())
    request,_,_=store.read_md(ROOT/'trial-requests'/(item['id']+'.md'))
    assert runner['request_sha256']==store.sha((ROOT/'trial-requests'/(item['id']+'.md')).read_bytes())
    assert request['model_config']==schedule['model_config']
    assert runner['source_strategy']==blind_trials.inventory(ROOT,'strategies/'+item['arm'])
    assert runner['source_inputs']==blind_trials.inventory(ROOT,request['public_dir'])
    cost_file=Path(runner['cost_record']['path']);assert store.sha(cost_file.read_bytes())==runner['cost_record']['sha256']
    cost,_,_=store.read_md(cost_file)
    assert cost['usage']==task_costs.native_usage(task_costs.parse_jsonl((folder/'events.jsonl').read_bytes()))
    grade=json.loads((folder/'grader.stdout').read_text())
    assert type(grade['quality_pass']) is bool and grade==json.loads((folder/'grade.json').read_text())
    mandatory=grade['mandatory'];ids=[r['id'] for r in mandatory]
    assert len(ids)==len(set(ids)) and mandatory and all(type(r['pass']) is bool for r in mandatory)
    assert grade['quality_pass']==all(r['pass'] for r in mandatory)
    assert (runner['grader_exit_code']==0)==grade['quality_pass']
    assert cost['model_config']==schedule['model_config']
    row={**item,'native_session_ids':cost['usage']['session_ids'],'artifact_quality_pass':grade['quality_pass'],
         'mandatory_checks':mandatory,'execution_completed':runner['process_exit_code']==0 and runner['stop_reason'] is None,
         'input_integrity':runner['inputs_and_strategy_unchanged'],
         'complete_task_seconds':cost['timing']['complete_task_seconds'],'agent_process_seconds':cost['timing']['agent_process_seconds'],
         'tool_union_seconds':cost['timing']['observed_command_union_seconds'],
         'input_tokens':cost['usage']['input_tokens'],'cached_input_tokens':cost['usage']['cached_input_tokens'],
         'output_tokens':cost['usage']['output_tokens'],'billed_usd':None,
         'cost_record':str(cost_file.relative_to(ROOT)),'grade_sha256':store.sha((folder/'grade.json').read_bytes()),
         'started_at':json.loads((folder/'measurement.json').read_text())['started_at'],
         'finished_at':json.loads((folder/'measurement.json').read_text())['finished_at']}
    all_rows.append(row)

by_original={r['id']:r for r in all_rows if r['id']==r['original_slot']}
contaminated={(r['task_id'],r['replicate']) for r in all_rows if r['id']==r['original_slot'] and r['infrastructure_contaminated']}
controlled=[];unresolved=[]
for block in sorted({(r['task_id'],r['replicate']) for r in schedule['runs']}):
    expected=[r for r in schedule['runs'] if (r['task_id'],r['replicate'])==block]
    suffix='-infra2' if block in contaminated else ''
    selected=[next((v for v in all_rows if v['id']==r['id']+suffix),None) for r in expected]
    if any(v is None or v['infrastructure_contaminated'] for v in selected):
        unresolved.append({'task_id':block[0],'replicate':block[1],'reason':'No uncontaminated full replacement block'})
        continue
    controlled.extend(selected)

groups=[];comparisons=[]
for task in sorted({r['task_id'] for r in schedule['runs']}):
    task_groups={}
    for arm in ('baseline','general','domain'):
        rows=[r for r in controlled if r['task_id']==task and r['arm']==arm]
        meter_complete=len(rows)==3 and all(r['native_tokens'] is not None and r['usage_coverage']=='complete_reported_turns' for r in rows)
        finished=sum(r['execution_completed'] and r['artifact_quality_pass'] and r['input_integrity'] for r in rows)
        row={'task_id':task,'arm':arm,'trials':len(rows),'accepted_artifacts':finished,
             'all_quality_pass':len(rows)==3 and finished==3,'usage_complete':meter_complete,
             'native_token_samples':[r['native_tokens'] for r in rows],
             'complete_seconds_samples':[r['complete_task_seconds'] for r in rows],
             'median_native_tokens':statistics.median(r['native_tokens'] for r in rows) if meter_complete else None,
             'median_complete_seconds':statistics.median(r['complete_task_seconds'] for r in rows) if len(rows)==3 else None,
             'known_tokens_per_accepted_artifact':sum(r['native_tokens'] for r in rows)/finished if meter_complete and finished else None,
             'billed_usd':None,'trial_ids':[r['id'] for r in rows]}
        groups.append(row);task_groups[arm]=row
    baseline=task_groups['baseline']
    for arm in ('general','domain'):
        candidate=task_groups[arm]
        gain=(baseline['median_native_tokens']-candidate['median_native_tokens'])/baseline['median_native_tokens'] if baseline['median_native_tokens'] and candidate['median_native_tokens'] is not None else None
        time_change=candidate['median_complete_seconds']/baseline['median_complete_seconds']-1 if baseline['median_complete_seconds'] and candidate['median_complete_seconds'] is not None else None
        reasons=[]
        if not candidate['all_quality_pass']:reasons.append('Mandatory delivery quality not met in every repetition')
        if gain is None:reasons.append('Incomplete comparable native usage')
        elif gain<.1:reasons.append('Native token median gain below predeclared 10 percent')
        if time_change is None:reasons.append('Incomplete complete-task timing')
        elif time_change>.1:reasons.append('Complete-task median exceeds 10 percent regression guard')
        comparisons.append({'task_id':task,'arm':arm,'relative_native_token_gain':gain,'relative_time_change':time_change,
                            'qualifies_on_this_task':not reasons,'reasons':reasons,'scope':'Observed task-specific criteria only; small sample, no general or monetary benefit established'})

first=min(datetime.fromisoformat(r['started_at']) for r in all_rows);last=max(datetime.fromisoformat(r['finished_at']) for r in all_rows)
summary={'scope':'Actual real-Agent task artifacts and native resource observations; original operational failures retained. No model training or universal mastery claim.',
         'model_config':schedule['model_config'],'actual_invocations':len(all_rows),'controlled_trials':len(controlled),
         'task_units':len({r['task_id'] for r in schedule['runs']}),'replications_per_arm_per_task':3,
         'infrastructure_contaminated_original_blocks':[list(v) for v in sorted(contaminated)],'unresolved_blocks':unresolved,
         'groups':groups,'comparisons':comparisons,
         'operational_account':{'known_native_tokens':sum(r['native_tokens'] or 0 for r in all_rows),
                               'unmetered_invocations':sum(r['native_tokens'] is None for r in all_rows),
                               'active_trial_seconds_sum':sum(r['complete_task_seconds'] for r in all_rows),
                               'first_dispatch_through_last_delivery_seconds':(last-first).total_seconds(),
                               'billed_usd':None,'billing_status':'Unavailable; no financial savings claim'},
         'global_strategy_activated':False,
         'attribution_limit':'Baseline and general arms can read the legacy source lesson; domain adds a causal representation and mapping procedure. Differences concern the whole frozen package, not the isolated effect of one memory field.',
         'trials':all_rows}
(ROOT/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
with (ROOT/'task-results.csv').open('w',newline='') as f:
    fields=['task_id','arm','trials','accepted_artifacts','median_native_tokens','median_complete_seconds','usage_complete','billed_usd']
    writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows({k:r[k] for k in fields} for r in groups)
print(json.dumps({'actual_invocations':len(all_rows),'controlled_trials':len(controlled),'groups':groups,'comparisons':comparisons},ensure_ascii=False))
