---
{
  "id": "measured-transfer-01",
  "type": "blind-plan",
  "arms": {
    "baseline": "strategies/baseline",
    "general": "strategies/general",
    "domain": "strategies/domain"
  },
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "repetitions": 3,
  "seed": 20261104,
  "deadline_seconds": 240,
  "metric": "native_tokens"
}
---

Two independently authored primary tasks, three repetitions per arm. Quality and complete-time guardrails are predeclared in preregister.md.
