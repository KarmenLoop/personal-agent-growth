---
{
  "id": "controller-smoke",
  "type": "agent-trial-request",
  "task_id": "controller-smoke",
  "arm": "baseline",
  "replicate": 1,
  "attempt": 1,
  "public_dir": "runner-preflight/public",
  "strategy_dir": "strategies/baseline",
  "prompt": {
    "path": "runner-preflight/prompt.txt",
    "sha256": "d74e5e5119642d434232e0c02958953cad17096a20281c57047af9ed64a57252"
  },
  "evaluator": {
    "path": "runner-preflight/private/grader.py",
    "sha256": "31bba93c98850592dc0116c480b3cf199cc953f84ef96e8cee6817c9947b8d96"
  },
  "model_config": {
    "model": "gpt-6.1-sol",
    "reasoning_effort": "low",
    "transport": "openai-http",
    "training": false,
    "cli_version": "codex-cli 0.165.0-alpha.1.2",
    "backend_weight_identity": "not independently attested",
    "automatic_unrelated_context": false,
    "nested_agents": false
  },
  "deadline_seconds": 240,
  "max_commands": 24,
  "codex_binary": "/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex"
}
---

Actual real-Agent controller smoke, kept separate from held-out tasks.
