---
{
  "id": "primary_02",
  "type": "blind-task",
  "domain": "scientific-data-qc",
  "role": "holdout",
  "public_dir": "sealed/primary_02/public",
  "evaluator": {
    "path": "sealed/primary_02/private/grader.py",
    "sha256": "5b8ddaf9cce5df4c22618525498a83813453c68b944cb58be4a2e218e7f72674"
  },
  "provenance": {
    "path": "sealed/primary_02/private/provenance.md",
    "sha256": "2a78c2b2c8cb90cc9431d2341c1343d8355f870ca6b68b2fa3065b0e333f3a08"
  }
}
---

Independently authored primary target released only after complete strategy freeze.
