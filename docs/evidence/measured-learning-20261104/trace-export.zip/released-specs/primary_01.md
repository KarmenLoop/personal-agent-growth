---
{
  "id": "primary_01",
  "type": "blind-task",
  "domain": "evidence-publication-audit",
  "role": "holdout",
  "public_dir": "sealed/primary_01/public",
  "evaluator": {
    "path": "sealed/primary_01/private/grader.py",
    "sha256": "af426e9f2a6fe8cf79ad01053880f06662dfdb4f56da9dcb8f43ec17b20ec109"
  },
  "provenance": {
    "path": "sealed/primary_01/private/provenance.md",
    "sha256": "988a0c3f5912e1f048b32311f4056de151a9e200e7a675a202e3153e1914b9d5"
  }
}
---

Independently authored primary target released only after complete strategy freeze.
