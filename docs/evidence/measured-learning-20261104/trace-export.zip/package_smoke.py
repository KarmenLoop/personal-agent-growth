from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,zipfile

T=Path(__file__).resolve().parent;P=T.parent/'开源发布/personal-agent-growth'
W=T/'package-smoke';W.mkdir(exist_ok=False)
commands=[]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,args):
    started=time.time();start=time.monotonic()
    env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
    p=subprocess.run(args,cwd=P,capture_output=True,env=env)
    (W/(label+'.stdout')).write_bytes(p.stdout);(W/(label+'.stderr')).write_bytes(p.stderr)
    commands.append({'label':label,'argv':args,'exit_code':p.returncode,'started_epoch':started,
        'elapsed_seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),
        'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
    (W/'commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
    assert p.returncode==0,(label,p.stderr.decode(errors='replace')[-1000:])
    return p.stdout
run('core-build',[sys.executable,'-B','tools/build_release.py','--output',str(W/'core')])
run('bundle-build',[sys.executable,'-B','tools/build_delivery.py','--output',str(W/'bundle')])
verified=json.loads(run('core-verify',[sys.executable,'-B','scripts/verify_handoff.py','--archive',str(W/'core/personal-agent-growth-0.7.0.zip'),'--manifest',str(W/'core/manifest.json')]))
assert len(verified['checks'])==173
with zipfile.ZipFile(W/'bundle/personal-agent-growth-delivery-0.7.0-bundle.1.zip') as z:z.extractall(W/'extracted')
bundle=next((W/'extracted').iterdir())
run('delivery-verify',[sys.executable,'-B',str(bundle/'tools/check_delivery.py'),str(bundle)])
initial=W/'安装 初始目录';moved=W/'搬迁后 共享记忆'
run('install',[sys.executable,'-B',str(bundle/'tools/local_install.py'),'install','--root',str(initial)])
shutil.copytree(P/'docs/examples/measured-learning',initial/'learning')
before_memory=h(initial/'learning/experience/mechanism/domain-preparation-20261104/experience.md')
shutil.move(initial,moved)
assert not initial.exists() and moved.exists()
scripts=moved/'skills/personal-agent-growth/scripts';learning=moved/'learning'
run('runner-import',[sys.executable,'-B',str(scripts/'run_agent_trial.py'),'--help'])
run('causal-import',[sys.executable,'-B',str(scripts/'experience_transfer.py'),'--help'])
retrieval=json.loads(run('experience-retrieve',[sys.executable,'-B',str(scripts/'experience_transfer.py'),'retrieve','--root',str(learning),'--query',str(learning/'requests/query.md')]))
assert len(retrieval['candidates'])==2
def md(path,item,body):
    f=learning/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_text('---\n'+json.dumps(item,ensure_ascii=False,indent=2)+'\n---\n\n'+body+'\n');return f
for arm in ('baseline','candidate'):
    f=learning/'demo-strategies'/arm/'SKILL.md';f.parent.mkdir(parents=True);f.write_text('# Explicit controlled package fixture; no Agent is started.\n')
plan=md('demo-plan.md',{'id':'relocated-protocol','type':'blind-plan','arms':{'baseline':'demo-strategies/baseline','candidate':'demo-strategies/candidate'},
    'model_config':{'model':'controlled-no-agent','training':False},'repetitions':3,'seed':14,'deadline_seconds':60,'metric':'native_tokens'},'Controlled package persistence check, not a trial.')
run('freeze',[sys.executable,'-B',str(scripts/'blind_trials.py'),'freeze','--root',str(learning),'--file',str(plan)])
pub=learning/'demo-input';pub.mkdir();(pub/'task.md').write_text('# Controlled interface fixture; no Agent execution.\n')
grader=learning/'demo-private/grader.py';grader.parent.mkdir();grader.write_text('raise SystemExit("Not invoked by this package smoke")\n')
provenance=learning/'demo-private/provenance.md';provenance.write_text('# Controlled fixture, not actual task evidence.\n')
def ref(path):return {'path':path.relative_to(learning).as_posix(),'sha256':h(path)}
task=md('demo-task.md',{'id':'relocated-target','type':'blind-task','domain':'controlled-package','role':'development',
    'public_dir':'demo-input','evaluator':ref(grader),'provenance':ref(provenance)},'This only checks installed helper contracts.')
run('release',[sys.executable,'-B',str(scripts/'blind_trials.py'),'release','--root',str(learning),'--id','relocated-protocol','--file',str(task)])
schedule=json.loads(run('schedule',[sys.executable,'-B',str(scripts/'blind_trials.py'),'schedule','--root',str(learning),'--id','relocated-protocol']))
assert len(schedule['runs'])==6
actual=T/'agent-runs/primary_01-r2-domain'; dest=learning/'native-replay';dest.mkdir()
for name in ['events.jsonl','timeline.jsonl','measurement.json']:(dest/name).write_bytes((actual/name).read_bytes())
spec={'id':'installed-native-replay','type':'task-cost-request','task_id':'primary_01','arm':'domain','replicate':2,'attempt':1,
    'model_config':json.loads((T/'run-order.json').read_text())['model_config'],
    'events':ref(dest/'events.jsonl'),'timeline':ref(dest/'timeline.jsonl'),'measurement':ref(dest/'measurement.json')}
req=md('native-replay/request.md',spec,'Replay of actual existing native evidence only. Not another Agent invocation and not added to study resource counts.')
cost=json.loads(run('cost-replay',[sys.executable,'-B',str(scripts/'task_costs.py'),'record','--root',str(learning),'--file',str(req)]))
assert cost['record']['usage']['total_tokens']==210042
run('uninstall',[sys.executable,'-B',str(moved/'distribution/tools/local_install.py'),'uninstall','--root',str(moved)])
after_memory=h(learning/'experience/mechanism/domain-preparation-20261104/experience.md')
assert after_memory==before_memory and not (moved/'skills/personal-agent-growth').exists()
result={'status':'PASS','version':'0.7.0','core_files':84,'core_checks':len(verified['checks']),
    'relocation':{'from':str(initial),'to':str(moved),'old_path_absent':not initial.exists()},
    'memory_sha256_before':before_memory,'memory_sha256_after':after_memory,'commands':commands,
    'source_manifest_sha256':h(W/'core/manifest.json'),'scope':'Actual local build/install/relocation/helper execution/removal. Native replay and controlled protocol fixtures are labeled and are not new Agent evidence.'}
(T/'package-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','commands':len(commands),'core_files':84,'core_checks':len(verified['checks']),'memory_retained':True}))
