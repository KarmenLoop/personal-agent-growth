---
id: measured-transfer-setup-amendment
type: experiment-amendment
status: active
created: 2026-11-04
updated: 2026-11-04
sources: [preregister.md, host-probe/events.jsonl, host-probe-compact/events.jsonl, host-probe-http-custom/events.jsonl]
---

# Pre-target setup amendment

This amendment is made before target content is released to the strategy author and before any primary trial. The original policy text and original registration are preserved.

Native Codex CLI probes returned real tool execution and input/cached/output token usage. The default transport retried WebSocket connections before falling back to HTTP. A built-in provider override was rejected; a documented per-invocation custom OpenAI provider with requires_openai_auth=true and supports_websockets=false worked without those reconnects. Existing authentication and global configuration were not copied or edited. All experiment arms use the same proven invocation configuration.

Controlled runs disable unrelated automatic skills instructions, bundled skill loading, plugins, apps, automatic memories and nested agents. They explicitly read their assigned complete Skill and task-local Markdown learning root. This is a shared experiment environment, not a capability difference credited to causal transfer. Setup probes are not target trials or proof of general speed improvement.

The native-use ceiling is fixed at 3,000,000 input-plus-output tokens for the initial controlled trial study, adjusted from the provisional 1,500,000 based only on measured CLI context overhead and 18 planned independent invocations. No comparative target results were available when setting this budget. No monetary fee is inferred from that ceiling. Each Agent invocation has 240 seconds and 24 command items; independent grading has a separate 30-second limit. Complete task time includes input assembly, actual Agent process and independent artifact grading. Study setup, source preparation, coordinator review, measurement normalization and publication remain separately visible.

No favorable-result stopping or repeat-until-win rule is introduced. Original input, candidate, model and quality constraints remain in force.
