---
{
  "id": "primary_01",
  "type": "released-blind-task",
  "released_at": "2026-11-03T17:45:29.326414+00:00",
  "frozen_sha256": "59e2cb814a4abd311c7f4d254ffee487548e57bb4aa05a75529540ff4a3913a3",
  "task_sha256": "a9fc6750ae6521f60ed68d9e313aeb1903cd32903e5da7ccafc7760e2ca861c8",
  "task": {
    "id": "primary_01",
    "type": "blind-task",
    "domain": "evidence-publication-audit",
    "role": "holdout",
    "public_dir": "sealed/primary_01/public",
    "evaluator": {
      "path": "sealed/primary_01/private/grader.py",
      "sha256": "af426e9f2a6fe8cf79ad01053880f06662dfdb4f56da9dcb8f43ec17b20ec109"
    },
    "provenance": {
      "path": "sealed/primary_01/private/provenance.md",
      "sha256": "988a0c3f5912e1f048b32311f4056de151a9e200e7a675a202e3153e1914b9d5"
    }
  },
  "public_inventory": {
    "raw/bundles/handoff-a/comparator-red.stderr": "70b24596cccce050c94ce9338f0159235585122f85e25df88ae02c629ecea2ae",
    "raw/bundles/handoff-a/final-tests.stderr": "fce44eea8a1322b604cbad38cc3a0ea2f9fd7c3ae964a4b95d89556b21aacf43",
    "raw/bundles/handoff-a/learner--release-source-manifest-v2.json": "9633363ab42130ed45b2b9b9042be1667dc40dd8bcd538e2ef2e58b755aec8ee",
    "raw/bundles/handoff-a/ledger-green.stderr": "4b05aabecba71912ffa9e715e44986da30ac502f26431fd93c04ad0760257e6a",
    "raw/bundles/handoff-a/ledger-red.stderr": "0a5ddacbab8f8c25078437f7ba085900de2d8d4dc25980f3f4539916f2e2a81a",
    "raw/bundles/handoff-a/teacher--summary.txt": "c83f9d644299f44f0571d0d227d9c2f5941ebcf8daa3e63aee4d9ba5837f2845",
    "raw/bundles/handoff-b/comparator-red.stderr": "70b24596cccce050c94ce9338f0159235585122f85e25df88ae02c629ecea2ae",
    "raw/bundles/handoff-b/final-tests.stderr": "d4a03401234ee9a70026284e17f3ca0c1a96533e97db8e1ae8a3ad7ff4ab0416",
    "raw/bundles/handoff-b/learner--release-source-manifest-v2.json": "9633363ab42130ed45b2b9b9042be1667dc40dd8bcd538e2ef2e58b755aec8ee",
    "raw/bundles/handoff-b/ledger-green.stderr": "4b05aabecba71912ffa9e715e44986da30ac502f26431fd93c04ad0760257e6a",
    "raw/bundles/handoff-b/ledger-red.stderr": "0a5ddacbab8f8c25078437f7ba085900de2d8d4dc25980f3f4539916f2e2a81a",
    "raw/bundles/handoff-b/teacher--summary.txt": "c83f9d644299f44f0571d0d227d9c2f5941ebcf8daa3e63aee4d9ba5837f2845",
    "raw/bundles/handoff-c/comparator-red.stderr": "70b24596cccce050c94ce9338f0159235585122f85e25df88ae02c629ecea2ae",
    "raw/bundles/handoff-c/final-tests.stderr": "fce44eea8a1322b604cbad38cc3a0ea2f9fd7c3ae964a4b95d89556b21aacf43",
    "raw/bundles/handoff-c/learner--release-source-manifest-v2.json": "9633363ab42130ed45b2b9b9042be1667dc40dd8bcd538e2ef2e58b755aec8ee",
    "raw/bundles/handoff-c/ledger-red.stderr": "0a5ddacbab8f8c25078437f7ba085900de2d8d4dc25980f3f4539916f2e2a81a",
    "raw/bundles/handoff-c/local-note.txt": "c4494873ec3db0aeb23aaea96d487ecc3d3ef243951bfbaa61e7973959d25e83",
    "raw/bundles/handoff-c/teacher--summary.txt": "c83f9d644299f44f0571d0d227d9c2f5941ebcf8daa3e63aee4d9ba5837f2845",
    "raw/publication-record.json": "644ecf2278f82df102e2c44c6e1fb7deada5d0fb2f06aad0bbf3aece18926088",
    "task.md": "6a14e86f8de006ffce6d7cfb40e75fa998bfa793d8c49d654490dfc9d66441c4"
  },
  "novelty_status": "Host-declared; no hidden-answer or prior-exposure certification"
}
---

Independently authored primary target released only after complete strategy freeze.
