---
{
  "id": "primary_02",
  "type": "released-blind-task",
  "released_at": "2026-11-03T17:45:29.412734+00:00",
  "frozen_sha256": "59e2cb814a4abd311c7f4d254ffee487548e57bb4aa05a75529540ff4a3913a3",
  "task_sha256": "0bd554cbb9ece36d73329d806effbf5faa0a18eeee170ed4735b766f40ef8541",
  "task": {
    "id": "primary_02",
    "type": "blind-task",
    "domain": "scientific-data-qc",
    "role": "holdout",
    "public_dir": "sealed/primary_02/public",
    "evaluator": {
      "path": "sealed/primary_02/private/grader.py",
      "sha256": "5b8ddaf9cce5df4c22618525498a83813453c68b944cb58be4a2e218e7f72674"
    },
    "provenance": {
      "path": "sealed/primary_02/private/provenance.md",
      "sha256": "2a78c2b2c8cb90cc9431d2341c1343d8355f870ca6b68b2fa3065b0e333f3a08"
    }
  },
  "public_inventory": {
    "raw/measurements.csv": "e0ebaca9ed25476caef5c64bda18eaf2c6336ad19eee82e2fc5e6de7075230ec",
    "raw/settings.json": "629af634e593fc50d3391c81a676d4da9bcceff3563040fe3468c9e0035b90c7",
    "task.md": "4c0b7b13bfe5791f1dfa02b88707b54e86ed7424702cdafb47905c89a1f4c0e1"
  },
  "novelty_status": "Host-declared; no hidden-answer or prior-exposure certification"
}
---

Independently authored primary target released only after complete strategy freeze.
