---
id: measured-transfer-infrastructure-handling
type: experiment-amendment
status: active
created: 2026-11-04
updated: 2026-11-04
sources: [preregister.md, protocol-amendment.md, study/started.json]
---

# Infrastructure handling before comparative outcome inspection

The second initial invocation emitted the native message “Selected model is at capacity” and a roughly 329-second backend retry delay, exceeding the predeclared 240-second invocation deadline. The controller stopped its owned invocation and recorded complete elapsed time, a negative process exit and unavailable token usage. No task quality or comparative performance results were inspected to make this decision. The model, candidate policies, executable snapshots, inputs, private evaluator, deadlines and 3M observed-native-token ceiling remain unchanged.

Retain every initial scheduled invocation, including infrastructure failure, in the operational account. Finish the remaining initially scheduled invocations without opening comparative grades. Identify infrastructure-contaminated blocks only from native provider capacity/connection-error events combined with missing completion/usage. A normal task failure, wrong artifact or an otherwise unexplained task deadline is not an infrastructure exclusion.

After initial attempts, permit one complete replacement of each of at most two contaminated task/repetition blocks, with all three arms in fresh workspaces and the same frozen configuration. Preserve original and replacement identities. This yields controlled comparison only for fully metered, uncontaminated replacement blocks; operational cost still includes the failed calls and intervening waiting. Missing usage remains unknown, so no claim of a fully known total operational token cost or financial savings can be made from it.

This rule is registered before comparative outcome inspection, is not a repeat-until-win rule, and permits no targeted policy fix or evaluator change. If infrastructure persists, report the affected comparison as inconclusive rather than replacing additional blocks. The strategy author has only inspected transport/status metadata, not target answers or grades; no task-specific method was trained on this event.
