# Read-only prepublication review · 0.7.0

No remaining material finding in the reviewed snapshot. One material chronology overstatement was reported and repaired by the owner in both acceptance reports.

## Repaired finding

Both reports initially said that complete executable snapshots froze before independent target authoring. The saved receipts distinguish:

- policy-text freeze: 2026-11-03 17:15:17 UTC;
- primary public-input manifests: 17:25:37;
- primary evaluator manifests: 17:28:44;
- complete candidate/strategy/source/executable freeze: 17:41:48;
- target release: 17:45:29.

The current English and Chinese line 9 now state this sequence and explicitly avoid claiming that complete executable snapshots preceded target authoring. That repair resolves the finding; the ordering itself does not establish contamination or invalidate the comparison. Timestamped local receipts are procedural evidence, not authentication or a security boundary.

## Bounded checks

- Recomputed 21 actual invocations and the 18 unique controlled trials. The entire original three-arm primary_01/repetition-1 block is excluded from the controlled medians, while all original costs remain in the operational total.
- Recomputed all six group medians and all four resource/time comparisons. No policy passes the prespecified 10% native-token benefit rule. Every controlled artifact passed its original grading receipt.
- Matched all 21 original cost-record hashes, bound native event/timeline/measurement bytes, grade hashes, usage totals and reported artifact hashes. Known native input+output total is 2,772,032; one invocation has unavailable usage. Active trial windows sum to 1,909.7995434975019 seconds and first dispatch through final delivery spans 2,262.740697 seconds. Billing and model-inference time remain null. Cache/reasoning subsets are not added twice.
- Verified all 1,236 public-export manifest entries against the archived public bytes. The original analysis hash and public derivative hash are separately identified. The portable library uses the exact public derivative and correctly binds both proposal records and all four chained observations. Seven saved helper stdout identities match their operation receipts.
- Checked all 14 package-command stdout/stderr hashes. The initial wrong cost-CLI invocation remains exit 2 with the corrected invocation separately retained; the 14-command count does not imply 14 first-attempt successes. The relocated memory's actual bytes match the before/after hash, and the old installation path is absent.
- The saved raw regression receipt says 171 tests and OK; source-before/source-after identities match. Tutorial-document hashes still match their saved validation receipts. No tests or tutorials were rerun during this review.
- Both acceptance reports distinguish task/answer procedural separation from OS read isolation, whole-package observations from source-memory causality, and native tokens/clock windows from financial charges/model inference. The portable feedback labels concern named whole-package resource results; future Agent adoption is explicitly unverified.

## Scope and cutoff

Read only the requested reports, analysis/trace/package receipts, relevant original primary-run records/artifacts, public export identities, and portable measured-learning docs/library. No new model calls, code/doc/evaluator edits, credentials/global chats, or sealed reserve inputs/graders. Only this review directory was written.

The acceptance overhead table was reviewed as its saved right-censored snapshot. This later review is not included in that older native-metadata cutoff; the owner plans one final native-metadata refresh after this review ends, with no new comparative runs. Release/network/CI operations were not performed or certified by this review.

Evidence: evidence.json; exact read-only check program: checks.py; command and status: command.txt and run.json; stdout.txt/stderr.txt retain the check result. The check completed with no consistency errors. Hashes establish content identity, not provider/actor authenticity or semantic causality.
