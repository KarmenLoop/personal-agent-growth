#!/usr/bin/env python3
"""Read-only claim checks. Writes only this review's receipts. No model invocation."""
from collections import Counter
from datetime import datetime
import csv
import hashlib
import io
import json
from pathlib import Path
import statistics
import zipfile

REPO=Path('<REPOSITORY>')
TASK=Path('<TASK>')
BASE=REPO/'docs/evidence/measured-learning-20261104'
LIB=REPO/'docs/examples/measured-learning'
OUT=Path(__file__).resolve().parent
errors=[]
def sha(raw): return hashlib.sha256(raw).hexdigest()
def data(path): return json.loads(path.read_text())
def md(path):
    lines=path.read_text().splitlines()
    return json.loads('\n'.join(lines[1:lines.index('---',1)]))
def check(condition, message):
    if not condition: errors.append(message)
def safe_task_path(name):
    p=TASK/name
    check(p.resolve().is_relative_to(TASK),'path escapes task: '+name)
    if any('reserve' in part.lower() for part in Path(name).parts):
        raise ValueError('Reserve content is outside review scope: '+name)
    return p

analysis=data(TASK/'analysis.json'); trace=data(TASK/'trace-review.json'); package=data(TASK/'package-result.json')
trials=analysis['trials']; byid={x['id']:x for x in trials}
controlled=[tid for group in analysis['groups'] for tid in group['trial_ids']]
check(len(trials)==len(byid)==21,'actual invocation count')
check(len(controlled)==len(set(controlled))==18,'controlled trial count')
excluded=sorted(set(byid)-set(controlled))
check(excluded==['primary_01-r1-baseline','primary_01-r1-domain','primary_01-r1-general'],'whole replacement block exclusions')
recomputed=[]
for group in analysis['groups']:
    rows=[byid[tid] for tid in group['trial_ids']]
    token_median=statistics.median(x['native_tokens'] for x in rows)
    seconds_median=statistics.median(x['complete_task_seconds'] for x in rows)
    check(token_median==group['median_native_tokens'],'token median '+group['task_id']+'/'+group['arm'])
    check(seconds_median==group['median_complete_seconds'],'time median '+group['task_id']+'/'+group['arm'])
    check(all(x['artifact_quality_pass'] for x in rows),'controlled quality '+group['task_id']+'/'+group['arm'])
    check(len(rows)==3 and all(x['usage_coverage']=='complete_reported_turns' for x in rows),'complete usage '+group['task_id']+'/'+group['arm'])
    recomputed.append({'task':group['task_id'],'arm':group['arm'],'native_tokens':token_median,'complete_seconds':seconds_median})
for comparison in analysis['comparisons']:
    baseline=next(g for g in analysis['groups'] if g['task_id']==comparison['task_id'] and g['arm']=='baseline')
    candidate=next(g for g in analysis['groups'] if g['task_id']==comparison['task_id'] and g['arm']==comparison['arm'])
    gain=1-candidate['median_native_tokens']/baseline['median_native_tokens']
    time=candidate['median_complete_seconds']/baseline['median_complete_seconds']-1
    check(abs(gain-comparison['relative_native_token_gain'])<1e-12,'comparison native gain')
    check(abs(time-comparison['relative_time_change'])<1e-12,'comparison time change')
    check(comparison['qualifies_on_this_task']==(gain>=.1 and time<=.1 and candidate['all_quality_pass']),'benefit gate')
check(not analysis['global_strategy_activated'],'unexpected activation')
known=sum(x['native_tokens'] or 0 for x in trials)
active=sum(x['complete_task_seconds'] for x in trials)
span=(max(datetime.fromisoformat(x['finished_at']) for x in trials)-min(datetime.fromisoformat(x['started_at']) for x in trials)).total_seconds()
check(known==2772032==analysis['operational_account']['known_native_tokens'],'operational native total')
check(active==analysis['operational_account']['active_trial_seconds_sum'],'active trial time sum')
check(span==analysis['operational_account']['first_dispatch_through_last_delivery_seconds'],'dispatch-to-delivery span')
check(all(x['billed_usd'] is None for x in trials),'billed amount invented')
record_checks=[]
for row in trials:
    tid=row['id']; cost_path=safe_task_path(row['cost_record']); raw=cost_path.read_bytes(); cost=md(cost_path)
    check(sha(raw)==row['cost_record_sha256'],'original cost hash '+tid)
    check(cost['usage']['total_tokens']==row['native_tokens'],'cost usage '+tid)
    check(cost['timing']['model_inference_seconds'] is None,'inference time estimated '+tid)
    check(cost['usage']['billed_usd'] is None,'billing estimated '+tid)
    check(cost['timing']['complete_task_seconds']==row['complete_task_seconds'],'cost time '+tid)
    for ref in cost['sources']:
        check(sha(safe_task_path(ref['path']).read_bytes())==ref['sha256'],'native source hash '+ref['path'])
    run=safe_task_path('agent-runs/'+tid); grade_raw=(run/'grade.json').read_bytes(); grade=json.loads(grade_raw)
    check(sha(grade_raw)==row['grade_sha256'],'grade hash '+tid)
    check(grade['quality_pass']==row['artifact_quality_pass'],'quality receipt '+tid)
    events=[json.loads(line) for line in (run/'events.jsonl').read_text().splitlines()]
    usages=[event['usage'] for event in events if event.get('type')=='turn.completed']
    native_total=sum(u['input_tokens']+u['output_tokens'] for u in usages) if usages else None
    check(native_total==row['native_tokens'],'native events total '+tid)
    trace_row=next(x for x in trace['trials'] if x['id']==tid)
    for name,ref in trace_row['output_artifacts'].items():
        artifact=safe_task_path('agent-work/'+tid+'/output/'+name).read_bytes()
        check(sha(artifact)==ref['sha256'] and len(artifact)==ref['bytes'],'output artifact '+tid+'/'+name)
    record_checks.append({'id':tid,'native_turns':len(usages),'total_tokens':native_total,'quality_pass':grade['quality_pass']})

manifest=data(BASE/'export-manifest.json'); archive=data(BASE/'archive.json')
check(sha((BASE/'trace-export.zip').read_bytes())==archive['sha256'],'public archive hash')
entries=manifest['files']; dup=[p for p,n in Counter(x['path'] for x in entries).items() if n>1]
if any('reserve' in part.lower() for entry in entries for part in Path(entry['path']).parts):
    raise ValueError('Reserve content is outside review scope; export hashing stopped')
verified=0
with zipfile.ZipFile(BASE/'trace-export.zip') as z:
    for entry in entries:
        public=z.read(entry['path'])
        check(sha(public)==entry['public_sha256'] and len(public)==entry['public_bytes'],'public export bytes '+entry['path'])
        verified+=1
analysis_entry=next(x for x in entries if x['path']=='analysis.json')
check(sha((TASK/'analysis.json').read_bytes())==analysis_entry['original_sha256'],'original analysis identity')
check(sha((BASE/'analysis.json').read_bytes())==analysis_entry['public_sha256'],'public analysis identity')
check((LIB/'evidence/analysis.json').read_bytes()==(BASE/'analysis.json').read_bytes(),'portable analysis derivative differs')
check((BASE/'trace-review.json').read_bytes()==(TASK/'trace-review.json').read_bytes(),'public trace review differs')

journals=[]
for folder in sorted((LIB/'experience/mechanism').iterdir()):
    exp_path=folder/'experience.md'; exp=md(exp_path); prev=sha(exp_path.read_bytes())
    for ref in exp['artifacts']:
        check(sha((LIB/ref['path']).read_bytes())==ref['sha256'],'portable experience evidence '+ref['path'])
    outcomes=[]
    for index,p in enumerate(sorted((folder/'observations').glob('*.md')),1):
        obs=md(p)
        check(obs['sequence']==index and obs['previous_sha256']==prev,'portable journal chain '+str(p.relative_to(LIB)))
        check(obs['experience_sha256']==sha(exp_path.read_bytes()),'portable experience binding')
        for ref in obs['artifacts']:
            check(sha((LIB/ref['path']).read_bytes())==ref['sha256'],'portable observation evidence '+ref['path'])
        outcomes.append(obs['outcome']); prev=sha(p.read_bytes())
    journals.append({'id':exp['id'],'outcomes':outcomes,'validation':exp['validation']})
operations=data(LIB/'operations.json')['commands']
for op in operations:
    check(sha((LIB/'evidence'/('operation-'+str(op['operation'])+'.stdout')).read_bytes())==op['stdout_sha256'],'portable operation '+str(op['operation']))
check(len(operations)==7 and all(x['exit_code']==0 for x in operations),'portable operations receipt')
for cmd in package['commands']:
    for kind in ['stdout','stderr']:
        p=TASK/'package-smoke'/(cmd['label']+'.'+kind)
        check(sha(p.read_bytes())==cmd[kind+'_sha256'],'package command '+cmd['label']+' '+kind)
check(len(package['commands'])==14,'package command count')
check([(x['label'],x['exit_code']) for x in package['commands'] if x['exit_code']] == [('cost-replay',2)],'package failures changed')
check(package['memory_sha256_before']==package['memory_sha256_after'],'relocated memory identity')
relocated=TASK/'package-smoke/搬迁后 共享记忆/learning/experience/mechanism/domain-preparation-20261104/experience.md'
check(sha(relocated.read_bytes())==package['memory_sha256_after'],'preserved memory actual bytes')
check(not Path(package['relocation']['from']).exists(),'old installation still exists')
check(data(TASK/'study/started.json')['harness']==data(TASK/'study/complete.json')['harness_before']==data(TASK/'study/complete.json')['harness_after'],'study executable freeze drift')
validation=data(BASE/'guides--documentation-final-validation.json')
for language in validation['languages']:
    lang=language['language']; path=REPO/('docs/measured-learning.'+lang+'.md')
    check(sha(path.read_bytes())==language['document_sha256'],'tutorial validated bytes changed '+lang)
regression=data(BASE/'regression--public-tests.json')
check(regression['source_before']==regression['source_after'],'regression source drift')
regression_tail=(BASE/'regression--public-tests.stderr').read_text().splitlines()[-5:]
check('Ran 171 tests in 14.385s' in regression_tail and regression_tail[-1]=='OK','regression raw receipt')

chronology={'policy_freeze':data(TASK/'policy-freeze.json')['frozen_at'],
            'primary_input_freezes':{tid:data(TASK/'sealed'/tid/'input-manifest.json')['frozen_at_utc'] for tid in ['primary_01','primary_02']},
            'primary_evaluator_freezes':{tid:data(TASK/'sealed'/tid/'evaluator-manifest.json')['frozen_at_utc'] for tid in ['primary_01','primary_02']},
            'full_candidate_freeze':data(TASK/'candidate-freeze-receipt.json')['frozen_at'],
            'primary_release':data(TASK/'primary-release-receipt.json')['released_at']}
report={'scope':'Read-only original/public study and portable feedback claim checks. No model invocation, credentials, global chats, or sealed reserve inputs/graders.',
        'errors':errors,'actual_invocations':len(trials),'controlled_trials':len(controlled),'excluded_original_block':excluded,
        'known_native_tokens':known,'unknown_usage_invocations':sum(x['native_tokens'] is None for x in trials),
        'active_trial_seconds':active,'dispatch_through_delivery_seconds':span,'recomputed_groups':recomputed,'native_record_checks':record_checks,
        'public_export_entries_verified':verified,'duplicate_identical_export_paths':dup,'analysis_original_public':analysis_entry,
        'portable_journals':journals,'portable_operations':len(operations),'package_commands':len(package['commands']),
        'retained_package_invocation_error':package['corrected_invocation_error'],'regression_raw_tail':regression_tail,
        'chronology':chronology,'acceptance_line_9_at_review':{lang:(REPO/('docs/release-0.7.0-acceptance.'+lang+'.md')).read_text().splitlines()[8] for lang in ['en','zh-CN']},
        'reviewed_file_hashes':{str(p.relative_to(REPO)):sha(p.read_bytes()) for p in [REPO/'docs/release-0.7.0-acceptance.en.md',REPO/'docs/release-0.7.0-acceptance.zh-CN.md',BASE/'analysis.json',BASE/'trace-review.json',BASE/'package.json',LIB/'evidence/analysis.json']}}
(OUT/'evidence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'errors':errors,'invocations':len(trials),'controlled':len(controlled),'native_tokens':known,
                  'public_entries_verified':verified,'chronology':chronology,'evidence':str(OUT/'evidence.json')},ensure_ascii=False,indent=2))
