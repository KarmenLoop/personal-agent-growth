#!/usr/bin/env python3
"""Bounded controlled fixtures; no provider call, authentication, or causal proof."""
import errno
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

REPO = Path('<REPOSITORY>')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO / 'scripts'))
import capability_ledger as store
import task_costs as costs
import causal_models as causal
import experience_transfer as transfer

OUTPUT = {'scope': 'Controlled parser/transfer fixtures only; no native Agent/provider run',
          'source_hashes': {name: hashlib.sha256((REPO/'scripts'/name).read_bytes()).hexdigest()
                            for name in ('task_costs.py', 'causal_models.py', 'experience_transfer.py', 'capability_ledger.py')}}

def save_md(path, data):
    path.write_bytes(store.encode(data, 'Controlled fixture, not actual Agent/provider or real-world evidence.'))
    return path

def cost_fixture(name):
    root = HERE / name
    root.mkdir()
    events = [{'type': 'thread.started', 'thread_id': 'controlled-thread'}, {'type': 'turn.started'},
              {'type': 'item.started', 'item': {'id': 'cmd-1', 'type': 'command_execution'}},
              {'type': 'item.completed', 'item': {'id': 'cmd-1', 'type': 'command_execution', 'exit_code': 0}},
              {'type': 'turn.completed', 'usage': {'input_tokens': 100, 'cached_input_tokens': 70, 'output_tokens': 30}}]
    timeline = [{'event_index': i, 'offset_seconds': offset} for i, offset in enumerate([0, .5, 2, 4, 7])]
    measurement = {'elapsed_seconds': 10, 'agent_start_offset': 1, 'agent_elapsed_seconds': 7,
                   'exit_code': 0, 'phase_spans': []}
    refs = {}
    for key, data in [('events', events), ('timeline', timeline), ('measurement', measurement)]:
        raw = (json.dumps(data) if key == 'measurement' else ''.join(json.dumps(row)+'\n' for row in data)).encode()
        suffix = '.json' if key == 'measurement' else '.jsonl'
        (root/(key+suffix)).write_bytes(raw)
        refs[key] = {'path': key+suffix, 'sha256': store.sha(raw)}
    request = {'id': 'trial-01', 'type': 'task-cost-request', 'task_id': 'task-a', 'arm': 'baseline',
               'replicate': 1, 'attempt': 1, 'model_config': {'model': 'controlled-fixture', 'training': False,
                                                           'temperature': 0.7}, **refs}
    return root, save_md(root/'request.md', request)

def caught(call):
    try:
        value = call()
        return {'returned': value}
    except Exception as error:
        return {'exception': type(error).__name__, 'message': str(error)}

# Real serialization failure through a JSON exponent overflow; no I/O fault injection.
root, request = cost_fixture('encode-failure')
valid_request = request.read_bytes()
request.write_bytes(valid_request.replace(b'"temperature": 0.7', b'"temperature": 1e999'))
first = caught(lambda: costs.record(root, request))
target = root/'trial-costs/trial-01.md'
request.write_bytes(valid_request)
OUTPUT['late_encode_failure'] = {'first': first, 'target_exists_after_failure': target.exists(),
                                 'target_bytes_after_failure': target.stat().st_size,
                                 'retry_with_corrected_valid_request': caught(lambda: costs.record(root, request))}

# Simulated partial disk write to a valid request, proving final-name publication is non-atomic.
root, request = cost_fixture('write-failure')
target = root/'trial-costs/trial-01.md'
original_open = Path.open
class FailingWriter:
    def __init__(self, inner): self.inner = inner
    def __enter__(self): self.inner.__enter__(); return self
    def __exit__(self, *args): return self.inner.__exit__(*args)
    def write(self, raw):
        self.inner.write(raw[:31]); self.inner.flush()
        raise OSError(errno.ENOSPC, 'CONTROLLED simulated disk-full after 31 bytes')
def fail_final_open(path, *args, **kwargs):
    stream = original_open(path, *args, **kwargs)
    return FailingWriter(stream) if path == target and args and args[0] == 'xb' else stream
with patch.object(Path, 'open', fail_final_open):
    first = caught(lambda: costs.record(root, request))
OUTPUT['partial_write_failure'] = {'fault_injected': True, 'first': first,
                                   'target_bytes_after_failure': target.stat().st_size,
                                   'retry_with_same_valid_request': caught(lambda: costs.record(root, request))}

# Explicit invalid mapping is checked for graph-backed experiences, but skipped for legacy.
root = HERE/'legacy-mapping'; root.mkdir()
(root/'artifact.txt').write_text('Controlled source artifact; no semantic validation.')
experience = {'id': 'legacy', 'type': 'mechanism-experience', 'source_task_id': 'source-task',
              'domain': 'source', 'problem_structure': ['dependency'], 'mechanisms': ['support-check'],
              'required_conditions': {'observed': True}, 'exceptions': ['Limited controlled fixture.'],
              'intervention': 'Recheck the dependency.', 'explanation': 'Candidate hypothesis only.',
              'validation': 'hypothesis', 'executor': 'fixture/author', 'reviewer': None,
              'artifacts': [{'path': 'artifact.txt', 'sha256': store.sha((root/'artifact.txt').read_bytes())}]}
transfer.add(root, save_md(root/'experience.md', experience))
def graph(a, b):
    return {'variables': {a: 'context', b: 'outcome'},
            'relations': [{'from': a, 'to': b, 'relation': 'conditions'}],
            'predictions': [{'intervention': 'Change context', 'expected': 'Decision changes',
                             'falsifier': 'Decision remains independent'}]}
target_graph = graph('tstate', 'tdecision')
bad_mapping = {'variables': {'state': 'missing-target', 'decision': 'tdecision'},
               'rationale': 'Controlled analogy', 'prediction': 'Decision changes',
               'falsifier': 'Decision remains independent'}
query = {'id': 'query-one', 'type': 'transfer-query', 'task_id': 'target-task', 'domain': 'target',
         'problem_structure': ['dependency'], 'mechanisms': ['support-check'],
         'facts': {'observed': True}, 'keywords': [], 'causal_context': target_graph,
         'causal_mappings': {'legacy': bad_mapping}}
result = transfer.retrieve(root, save_md(root/'query.md', query))
candidate = result['candidates'][0]
OUTPUT['explicit_invalid_mapping_on_legacy'] = {
    'query_check': caught(lambda: transfer.query_check(query)), 'errors': result['errors'],
    'matched_count': result['matched_count'], 'eligible_for_probe': candidate['eligible_for_probe'],
    'causal_match': candidate['causal_match'],
    'same_mapping_with_source_graph': causal.match(graph('state', 'decision'), target_graph, bad_mapping)}
print(json.dumps(OUTPUT, ensure_ascii=False, indent=2, allow_nan=False))
