# Bounded measurement and causal mapping review

Only the assigned scripts, their focused tests, and capability_ledger utilities were read. No sealed content, policies, target tests, repository edits, broad tests, provider calls, or native Agent runs were used. All fixtures below are controlled parser/integration inputs; hashes record content identity, not authenticity. Structural graph compatibility is not causation.

## P2: A failed publication permanently occupies the final cost-record ID

Location: scripts/task_costs.py:209-212.

The final Markdown name is opened with `xb` before `store.encode(...)` or the write succeeds. A serialization error or interrupted write therefore leaves an empty or partial final file. Every later retry of the same valid identity then fails with FileExistsError. It is also possible for a reader to observe the partial final record. The existing `store.publish` utility already serializes to an exclusive temporary file and atomically publishes the final name.

Actual reproduction `late_encode_failure` in output.json: a JSON exponent `1e999` inside the model declaration passes request decoding/checking, then encode raises ValueError. The final Markdown remains present with 0 bytes. Correcting the model declaration and retrying gives FileExistsError. `partial_write_failure` injects ENOSPC after 31 bytes of an otherwise valid write; the partial final likewise blocks the unchanged valid retry. The second case is explicitly fault injection, not an observed disk incident.

Suggested fix: encode and validate fully before creating the final path, then use atomic/exclusive publication. Validate model configuration numeric values before publication as appropriate.

## P2: An explicit invalid causal mapping is ignored for legacy experiences

Locations: scripts/causal_models.py:65-67,47-60; scripts/experience_transfer.py:279-280,304-305.

When source is None, match returns legacy_labels before inspecting an explicitly supplied mapping. mappings_check also never checks that mapping destinations are in its target graph. A query with a valid target graph and an explicit mapping to nonexistent `missing-target` is therefore accepted for a legacy source. Retrieval reports eligible_for_probe=true with compatible=null and no issues. The identical mapping with a graph-backed source is correctly rejected as target_variable_missing.

Actual reproduction `explicit_invalid_mapping_on_legacy` in output.json records both outcomes. Ordinary legacy queries without explicit mappings should remain compatible; the failure concerns silently ignoring a supplied mapping whose target endpoint is provably invalid. At minimum, validate known target destinations in mappings_check; an explicit mapping with no source model should be visibly uncheckable and blocked rather than treated as ordinary legacy retrieval.

## Evidence

- reproduce.py: exact controlled fixture program (run once in this directory because it intentionally preserves exclusive failed outputs; copy it into a fresh review directory to repeat against another source version).
- command.txt and run.json: exact executed Python command and exit status (0).
- output.json: observed results plus source-file hashes.
- stderr.txt: empty.
- encode-failure/request-overflow.md: preserved request carrying the exponent-overflow input.
- encode-failure/trial-costs/trial-01.md: preserved empty failed publication.
- write-failure/trial-costs/trial-01.md: preserved 31-byte partial publication.
- legacy-mapping/: controlled experience, query, artifact and stored experience.

No additional material bugs were confirmed in the reviewed cache/reasoning token summation, unknown/partial usage handling, finite/ordered timing checks, interval union, ordinary legacy compatibility, or graph-backed mapping role/direction gates. This review does not validate live native event schema, native Agent execution, actual cost, actor authenticity, or transfer usefulness.
