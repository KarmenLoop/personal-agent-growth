---
id: measured-transfer-conditional-source-ablation
type: experiment-plan
status: conditional
created: 2026-11-04
updated: 2026-11-04
sources: [preregister.md, blind-plan.md, policies/domain.md]
---

# Prospective attribution check

Registered before the coordinator opens comparative task grades or aggregate performance results. This concerns future ablation data, not a new interpretation of collected primary data.

The initial three arms compare frozen intervention packages. Baseline/general can read the same genuine legacy lesson; domain adds an explicit causal representation and procedure. That comparison alone cannot identify the isolated contribution of source experience.

If the domain package meets all predeclared task quality, native-token gain and complete-time guardrails on at least one primary task, run a bounded explanatory source ablation before crediting source experience or activating a global strategy. Keep the domain instructions, code, host, model configuration, tools, task and deadlines identical; vary only whether the task-local source-memory files are supplied. Use fresh Agent contexts, three repetitions and seeded randomized full/without-memory pairs on each qualifying task. At most 12 extra invocations across two tasks, within the same 3M observed leaf-token ceiling.

Preserve all failed and unmetered attempts. These are repeated target tasks under a frozen method, not a claim of newly created target novelty. Report source-present/source-absent quality, complete time and native resources separately. A source-present arm must retain mandatory quality and show a predeclared 10 percent native-token median gain without over 10 percent median complete-time regression before claiming a resource benefit from experience on that task. If the source-absent arm performs equally or better, do not credit source memory for the initial package difference.

If the domain package qualifies on no task, report that no demonstrated net benefit was found and do not launch attribution calls solely to obtain a favorable result. No task-specific repair, proposed-answer insertion or evaluator change is permitted in this ablation.
