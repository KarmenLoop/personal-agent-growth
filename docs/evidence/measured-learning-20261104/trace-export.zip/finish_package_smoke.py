from pathlib import Path
import json,subprocess,sys,time,hashlib

T=Path(__file__).resolve().parent;P=T.parent/'开源发布/personal-agent-growth';W=T/'package-smoke'
commands=json.loads((W/'commands.json').read_text());moved=W/'搬迁后 共享记忆';learning=moved/'learning'
scripts=moved/'skills/personal-agent-growth/scripts'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before=h(learning/'experience/mechanism/domain-preparation-20261104/experience.md')
def run(label,args):
    start=time.monotonic();epoch=time.time();p=subprocess.run(args,cwd=P,capture_output=True)
    (W/(label+'.stdout')).write_bytes(p.stdout);(W/(label+'.stderr')).write_bytes(p.stderr)
    commands.append({'label':label,'argv':args,'exit_code':p.returncode,'started_epoch':epoch,'elapsed_seconds':time.monotonic()-start,
        'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
    (W/'commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
    assert p.returncode==0,(label,p.stderr)
    return json.loads(p.stdout)
cost=run('cost-replay-corrected',[sys.executable,'-B',str(scripts/'task_costs.py'),'--root',str(learning),'--request',str(learning/'native-replay/request.md')])
assert cost['record']['usage']['total_tokens']==210042
run('uninstall',[sys.executable,'-B',str(moved/'distribution/tools/local_install.py'),'uninstall','--root',str(moved)])
assert h(learning/'experience/mechanism/domain-preparation-20261104/experience.md')==before
assert not (moved/'skills/personal-agent-growth').exists()
result={'status':'PASS','version':'0.7.0','core_files':84,'core_checks':173,
    'relocation':{'from':str(W/'安装 初始目录'),'to':str(moved),'old_path_absent':not (W/'安装 初始目录').exists()},
    'memory_sha256_before':before,'memory_sha256_after':before,'commands':commands,
    'corrected_invocation_error':'The coordinator initially passed record/--file to a CLI requiring --request. Original exit-2 stderr retained; corrected invocation succeeded. No product code or acceptance condition changed.',
    'source_manifest_sha256':h(W/'core/manifest.json'),
    'scope':'Actual local build/install/relocation/helper execution/removal. Native replay and controlled protocol fixtures are labeled and are not new Agent evidence.'}
(T/'package-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','commands':len(commands),'preserved_invocation_failures':1,'core_checks':173,'memory_retained':True}))
