from pathlib import Path
import hashlib,json,subprocess,sys,time
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parent;REPO=ROOT.parent/'开源发布/personal-agent-growth'
sys.path.insert(0,str(REPO/'scripts'));import capability_ledger as store;import blind_trials
schedule=json.loads((ROOT/'run-order.json').read_text())
initial=json.loads((ROOT/'study/started.json').read_text())['harness']
hashes=lambda:{name:hashlib.sha256((REPO/'scripts'/name).read_bytes()).hexdigest() for name in initial}
STUDY=ROOT/'study';account=[];known_tokens=0

def inspect(item,identifier):
    folder=ROOT/'agent-runs'/identifier
    runner=json.loads((folder/'runner.json').read_text())
    assert runner['inputs_and_strategy_unchanged'],'Input integrity failure'
    assert runner['cost_record'] is not None,'Cost normalization failure, not a zero-cost invocation'
    cost,_,_=store.read_md(Path(runner['cost_record']['path']))
    errors=[]
    for line in (folder/'events.jsonl').read_text().splitlines():
        e=json.loads(line)
        if e.get('type')=='error':errors.append(e.get('message',''))
    provider_signal=any(any(word in e.lower() for word in ('at capacity','request timed out','stream disconnected','connection failed')) for e in errors)
    infrastructure=provider_signal and (cost['usage']['total_tokens'] is None or cost['usage']['coverage']!='complete_reported_turns')
    return {'id':identifier,'original_slot':item['id'],'task_id':item['task_id'],'replicate':item['replicate'],'arm':item['arm'],
            'native_tokens':cost['usage']['total_tokens'],'usage_coverage':cost['usage']['coverage'],
            'infrastructure_contaminated':infrastructure,'cost_record_sha256':runner['cost_record']['sha256'],
            'controller_exit':0,'process_exit':runner['process_exit_code'],'stop_reason':runner['stop_reason']}

def execute(item,identifier,request):
    global known_tokens
    assert hashes()==initial,'Frozen harness changed'
    assert blind_trials.schedule(ROOT,'measured-transfer-01')==schedule
    if known_tokens>3000000:raise RuntimeError('Observed native-use ceiling reached')
    folder=ROOT/'agent-runs'/identifier
    if not (folder/'runner.json').exists():
        assert not folder.exists(),'Partial controller state needs explicit reconciliation'
        cmd=[sys.executable,'-B',str(REPO/'scripts/run_agent_trial.py'),'--root',str(ROOT),'--request',str(request)]
        with (STUDY/(identifier+'.stdout')).open('wb') as out,(STUDY/(identifier+'.stderr')).open('wb') as err:
            result=subprocess.run(cmd,stdout=out,stderr=err)
        if result.returncode:raise RuntimeError('Controller failed: '+identifier)
    row=inspect(item,identifier)
    known_tokens+=row['native_tokens'] or 0
    account.append(row);(STUDY/'operational-progress.json').write_text(json.dumps(account,indent=2)+'\n')
    return row

for index,item in enumerate(schedule['runs']):
    execute(item,item['id'],ROOT/'trial-requests'/(item['id']+'.md'))
    print(json.dumps({'initial_slots_recorded':index+1,'planned':len(schedule['runs']),'comparison_outcomes':'not inspected'}),flush=True)

bad=sorted({(r['task_id'],r['replicate']) for r in account if r['infrastructure_contaminated']})
replacements=[]
for task_id,repeat in bad[:2]:
    block=[item for item in schedule['runs'] if item['task_id']==task_id and item['replicate']==repeat]
    for item in block:
        identifier=item['id']+'-infra2'
        source=ROOT/'trial-requests'/(item['id']+'.md');spec,body,_=store.read_md(source)
        spec['id']=identifier;spec['attempt']=2
        request=ROOT/'trial-requests'/(identifier+'.md')
        if not request.exists():request.write_bytes(store.encode(spec,body+'\nWhole-block infrastructure replacement; original attempt remains in operational accounting.'))
        replacements.append(execute(item,identifier,request))
        print(json.dumps({'infrastructure_replacement_recorded':identifier,'comparison_outcomes':'not inspected'}),flush=True)

assert hashes()==initial
(STUDY/'complete.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'initial_slots':len(schedule['runs']),
    'actual_invocations':len(account),'known_native_tokens':known_tokens,'unmetered_invocations':sum(r['native_tokens'] is None for r in account),
    'infrastructure_blocks':bad,'replacement_invocations':len(replacements),'harness_before':initial,'harness_after':hashes(),
    'all_initial_trials_recorded':True,'all_grades_unopened_by_controller':True},indent=2)+'\n')
print(json.dumps({'status':'ALL_ATTEMPTS_RECORDED','actual_invocations':len(account),'known_native_tokens':known_tokens}),flush=True)
