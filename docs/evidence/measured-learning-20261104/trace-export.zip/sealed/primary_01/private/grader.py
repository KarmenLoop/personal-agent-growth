#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import Grade, digest, integer, keyed, load_json, read_csv

g=Grade('primary_01','historical_inputs_with_controlled_integrity_variants',['audit.csv','result.json','report.md'])
try:
    record=load_json(g.public/'raw/publication-record.json')
    required=['bundle','path','status','observed_bytes','observed_sha256','declared_public_sha256','original_sha256','publication_relation']
    expected={}
    for bundle in record['bundles']:
        folder=g.public/'raw/bundles'/bundle
        declared={e['path']:e for e in record['files']}
        present={p.relative_to(folder).as_posix():p for p in folder.rglob('*') if p.is_file()}
        for path in sorted(set(declared)|set(present)):
            e=declared.get(path);p=present.get(path)
            if e is None:
                row={'bundle':bundle,'path':path,'status':'unlisted','observed_bytes':p.stat().st_size,'observed_sha256':digest(p),'declared_public_sha256':'','original_sha256':'','publication_relation':'unknown'}
            else:
                relation='unchanged' if e['original_sha256']==e['public_sha256'] else ('redacted_derivative' if e['path_redacted'] else 'undocumented_difference')
                row={'bundle':bundle,'path':path,'status':'missing' if p is None else ('verified' if digest(p)==e['public_sha256'] else 'mismatch'),'observed_bytes':p.stat().st_size if p is not None else '', 'observed_sha256':digest(p) if p is not None else '', 'declared_public_sha256':e['public_sha256'],'original_sha256':e['original_sha256'],'publication_relation':relation}
            expected[(bundle,path)]=row
    actual=keyed(read_csv(g.output/'audit.csv',required),['bundle','path'])
    identity=set(actual)==set(expected)
    g.check('inventory_coverage',identity,'Exactly the declared/present file union is inventoried with unique identities.')
    correct=identity
    for k,e in expected.items():
        a=actual.get(k,{})
        for field in required:
            want=e[field];got=a.get(field)
            correct=correct and (integer(got,want) if field=='observed_bytes' and want!='' else got==want)
    g.check('byte_identity_and_attribution',correct,'Actual bytes, declared public identity, source provenance, transformation relation, and statuses are correct.')
    values=list(expected.values())
    summary={'declared_files':sum(v['status']!='unlisted' for v in values),'verified_files':sum(v['status']=='verified' for v in values),'mismatched_files':sum(v['status']=='mismatch' for v in values),'missing_files':sum(v['status']=='missing' for v in values),'unlisted_files':sum(v['status']=='unlisted' for v in values),'verified_redacted_derivatives':sum(v['status']=='verified' and v['publication_relation']=='redacted_derivative' for v in values),'handoff_ready':all(v['status']=='verified' for v in values)}
    actual_summary=(g.result or {}).get('summary',{})
    summary_ok=isinstance(actual_summary,dict) and set(summary).issubset(actual_summary)
    if summary_ok:
        summary_ok=all((type(actual_summary[k]) is bool and actual_summary[k]==v) if isinstance(v,bool) else type(actual_summary[k]) is int and actual_summary[k]==v for k,v in summary.items())
    g.check('handoff_summary',summary_ok,'Counts and readiness reflect artifact integrity, including verified redacted derivatives.')
except (OSError,ValueError,KeyError,TypeError,AttributeError) as e:
    g.check('domain_artifacts_readable',False,str(e))
g.finish()
