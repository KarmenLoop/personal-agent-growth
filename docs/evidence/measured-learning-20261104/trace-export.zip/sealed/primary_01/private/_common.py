import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

MAX_BYTES=2000000

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def unique_object(pairs):
    out={}
    for k,v in pairs:
        if k in out: raise ValueError('duplicate JSON key: '+k)
        out[k]=v
    return out

def load_json(p):
    if p.stat().st_size>MAX_BYTES: raise ValueError('artifact too large')
    return json.loads(p.read_text(encoding='utf-8'),object_pairs_hook=unique_object,parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON constant')))

def read_csv(p,required):
    if p.stat().st_size>MAX_BYTES: raise ValueError('artifact too large')
    with p.open(encoding='utf-8-sig',newline='') as f:
        rd=csv.DictReader(f)
        if rd.fieldnames is None or len(rd.fieldnames)!=len(set(rd.fieldnames)) or not set(required).issubset(rd.fieldnames):
            raise ValueError('missing or duplicate CSV columns')
        rows=list(rd)
    if any(None in r for r in rows): raise ValueError('CSV row has extra fields')
    return rows

def keyed(rows,fields):
    out={}
    for r in rows:
        k=tuple(r[f] for f in fields)
        if k in out: raise ValueError('duplicate artifact identity: '+repr(k))
        out[k]=r
    return out

def numeric(value,expected,tol=0.00000051):
    if isinstance(value,bool) or value is None: return False
    try: f=float(value)
    except (TypeError,ValueError,OverflowError): return False
    return math.isfinite(f) and abs(f-float(expected))<=tol

def integer(value,expected):
    if isinstance(value,bool): return False
    if isinstance(value,int): return value==expected
    if isinstance(value,str):
        return value.strip().lstrip('-').isdigit() and int(value)==expected
    return False

class Grade:
    def __init__(self,task_id,kind,artifacts):
        ap=argparse.ArgumentParser(description='Grade actual delivered artifacts using frozen independent expectations.')
        ap.add_argument('--output',required=True,type=Path)
        ap.add_argument('--public',type=Path)
        ap.add_argument('--report',type=Path)
        self.args=ap.parse_args()
        self.task_id=task_id
        self.home=Path(__file__).resolve().parents[1]
        self.public=(self.args.public or self.home/'public').resolve()
        self.output=self.args.output
        self.checks=[];self.diagnostics={};self.result=None
        root_ok=self.output.is_dir() and not self.output.is_symlink()
        self.check('output_directory',root_ok,'Output directory exists and is not a symlink.')
        okay=root_ok
        problems=[]
        for name in artifacts:
            p=self.output/name
            present=p.is_file() and not p.is_symlink() and 0<p.stat().st_size<=MAX_BYTES
            if not present:problems.append(name)
            okay=okay and present
        self.check('required_artifacts',okay,'Missing, empty, oversized, or non-ordinary files: '+repr(problems))
        try:
            self.result=load_json(self.output/'result.json')
            if not isinstance(self.result,dict):raise ValueError('result must be an object')
            parsed=True
        except (OSError,ValueError,TypeError) as e:
            self.diagnostics['result_error']=str(e);parsed=False
        self.check('result_json',parsed,'Strict JSON object, with no duplicate keys or nonfinite constants.')
        try:
            manifest=load_json(self.home/'input-manifest.json')
            expected={x['path']:x['sha256'] for x in manifest['files']}
            actual={k:digest(self.public/k) for k in expected if (self.public/k).is_file() and not (self.public/k).is_symlink()}
            current_raw={p.relative_to(self.public).as_posix() for p in (self.public/'raw').rglob('*') if p.is_file() or p.is_symlink()}
            input_ok=actual==expected and current_raw=={k for k in expected if k.startswith('raw/')}
            raw_expected={k:v for k,v in expected.items() if k.startswith('raw/')}
        except (OSError,ValueError,KeyError,TypeError) as e:
            self.diagnostics['input_error']=str(e);input_ok=False;raw_expected={}
        self.check('frozen_inputs',input_ok,'Frozen public inputs and the complete raw file set are unchanged.')
        self.check('input_fingerprints',parsed and self.result.get('source_sha256')==raw_expected,'Result identifies every actual raw input by SHA-256.')
        identity=parsed and type(self.result.get('schema')) is int and self.result.get('schema')==1 and self.result.get('task_id')==task_id
        self.check('task_identity',identity,'Schema and task ID match this frozen target.')
        self.check('data_provenance',parsed and self.result.get('data_kind')==kind,'Historical versus derived-fixture scope is attributed correctly.')
        try:
            prose=(self.output/'report.md').read_text(encoding='utf-8')
            self.diagnostics['report_characters']=len(prose)
            self.diagnostics['report_has_substantive_text']=len(prose.strip())>=80
        except (OSError,UnicodeError):self.diagnostics['report_has_substantive_text']=False
    def check(self,name,passed,detail):
        self.checks.append({'id':name,'pass':bool(passed),'detail':detail})
    def finish(self):
        report={'schema':1,'task_id':self.task_id,'evaluator_kind':'independent_final_artifact_check','quality_pass':all(c['pass'] for c in self.checks),'mandatory':self.checks,'optional_diagnostics':self.diagnostics,'scope':'Artifact correctness and frozen-input integrity only; real Agent execution and resource budgets require separate host receipts.'}
        s=json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
        if self.args.report:
            self.args.report.parent.mkdir(parents=True,exist_ok=True)
            self.args.report.write_text(s,encoding='utf-8')
        sys.stdout.write(s)
        raise SystemExit(0 if report['quality_pass'] else 1)
