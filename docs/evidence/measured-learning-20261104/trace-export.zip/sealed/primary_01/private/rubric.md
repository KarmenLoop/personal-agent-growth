# Independent artifact rubric

Mandatory common gates: required final files are ordinary files; strict result JSON is readable; frozen public inputs remain unchanged; raw-file SHA map is exact; task identity and data-kind attribution are correct.

Mandatory domain gates: the CSV contains the full declared/present union with unique bundle/path identities; observed byte counts and hashes reflect actual delivered files; statuses use public hashes; source hashes and declared transformation relation remain accurate; the summary is an exact rollup and readiness follows actual integrity.

Optional diagnostics: report readability and number of redacted derivatives. No grade depends on repeating task wording, the executor's test count, or assertions in a candidate policy. A report cannot override incorrect audit rows.

Independence: this evaluator reads final CSV/JSON, source declarations, and frozen raw bytes; it does not execute candidate helpers. The reference is an author-controlled output, not a solving-Agent result. Relevant negative controls cover confusing public and original hashes, overlooking a missing file, and masking a damaged delivered file.
