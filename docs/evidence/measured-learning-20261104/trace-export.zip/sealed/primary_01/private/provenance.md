# Provenance and task independence

This is a newly authored forward audit over historical inputs, with controlled new transport variants. It is not an unseen discovery of the already published historical release, and it is not an Agent replay.

The exact genuine source paths, byte lengths, and current SHA-256 values are in `sources.json`. The selected six exports are copied byte-for-byte into handoff-a. handoff-b copies the same files, then appends the exact UTF-8 bytes `\ncontrolled-transport-appendix\n` to final-tests.stderr. handoff-c omits ledger-green.stderr and adds a clearly labeled local-note.txt. Public declarations are the selected historical export metadata and bundle identifiers. All transformations are author-created; none is represented as an actual historical defect.

Historical basis: the capability-learning evidence records separate original/publication hashes for redacted derivatives. Its ledger failure receipts preserve artifact-integrity rejection. The new context is the sanitized publication handoff: an immutable-source lesson must be applied to the correct delivered-byte identity, while an analogy requiring a derivative to equal its unredacted original is invalid. The executor prompt supplies the operational contract but does not identify affected targets or a worked result.

No sibling policy, policy-freeze, candidate code, or candidate instructions were read. The grader and controlled reference were authored independently of the parent candidate.
