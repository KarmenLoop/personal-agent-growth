# Provenance and independence

The exact historical source paths and SHA-256 values are in sources.json. The 2026-11-03 evidence-judgment assessment records a real campaign-metric repair from an unweighted cohort-rate average to an overall visitor rate. The cross-domain historical evidence retains rejection of a valid abbreviated decimal and an inappropriate exact floating-point assertion.

This task is a new domain/context variant, not a historical replay. All stations, dates, readings, revisions, calibrations, and QC labels are author-created and explicitly labeled as a derived fixture, not observations. No measured scientific claim is made. It transforms the past requirement to identify the correct unit of aggregation into a station-index workflow, while retaining the need to accept valid finite decimals. The tempting invalid analogy is to carry population/exposure weighting from an overall visitor rate into an equal-station index, or to pool all replicates across stations. Different replicate counts make that analogy consequential. Revision rejection and incomplete coverage are new held-out conditions.

No source task's worked answer or intended diagnosis is included in public data. No sibling policy, policy-freeze, candidate code, or candidate instructions were inspected. This author did not run a solving Agent.
