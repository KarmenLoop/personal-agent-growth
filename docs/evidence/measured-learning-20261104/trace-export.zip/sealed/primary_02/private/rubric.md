# Independent artifact rubric

Common gates are identical to the other held-out tasks. Domain gates inspect row-level calibration and disposition, revision selection, every configured station-day, accepted counts, equal-station weighting, and incomplete-date nulls. The six-decimal tolerance is at most 0.00000051; nonfinite values and booleans do not count as numbers. CSV row order is immaterial, identities must be unique.

The optional prose diagnostic does not replace numerical/data checks. No candidate policy assertions or candidate-specified tests affect acceptance. The evaluator uses fractions from source decimal strings; the reference contains separately hand-derived values. Negative controls include a pooled-replicate index, revival of an older accepted revision, and publishing an index from incomplete coverage.
