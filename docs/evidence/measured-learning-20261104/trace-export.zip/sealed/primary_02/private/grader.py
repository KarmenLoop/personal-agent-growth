#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from fractions import Fraction
from _common import Grade, integer, keyed, load_json, numeric, read_csv

g=Grade('primary_02','derived_fixture_not_actual_measurements',['audit.csv','station-days.csv','result.json','report.md'])
try:
    raw=read_csv(g.public/'raw/measurements.csv',['row_id','date','station','replicate','revision','reading_c','bias_c','quality'])
    settings=load_json(g.public/'raw/settings.json')
    latest={}
    for r in raw:
        k=(r['date'],r['station'],r['replicate'])
        latest[k]=max(latest.get(k,-1),int(r['revision']))
    expected_audit={};station_values={}
    for r in raw:
        k=(r['date'],r['station'],r['replicate'])
        if int(r['revision'])<latest[k]:status='superseded'
        elif r['quality']!='ok':status='rejected_quality'
        elif any(r[f] in ('','NA') for f in ('reading_c','bias_c')):status='missing_value'
        else:status='accepted'
        value=Fraction(r['reading_c'])-Fraction(r['bias_c']) if status=='accepted' else None
        expected_audit[(r['row_id'],)]=(status,value)
        if value is not None:station_values.setdefault((r['date'],r['station']),[]).append(value)
    audit=keyed(read_csv(g.output/'audit.csv',['row_id','disposition','calibrated_c']),['row_id'])
    okay=set(audit)==set(expected_audit)
    for k,(status,value) in expected_audit.items():
        a=audit.get(k,{})
        okay=okay and a.get('disposition')==status and (a.get('calibrated_c')=='' if value is None else numeric(a.get('calibrated_c'),value))
    g.check('row_qc_and_calibration',okay,'Every source row is attributed to its true revision/QC disposition and calibrated only when accepted.')
    station_expected={}
    for date in settings['dates']:
        for station in settings['stations']:
            vs=station_values.get((date,station),[])
            station_expected[(date,station)]=(len(vs),sum(vs,Fraction(0))/len(vs) if vs else None)
    stations=keyed(read_csv(g.output/'station-days.csv',['date','station','accepted_replicates','mean_c']),['date','station'])
    okay=set(stations)==set(station_expected)
    for k,(count,mean) in station_expected.items():
        a=stations.get(k,{})
        okay=okay and integer(a.get('accepted_replicates'),count) and (a.get('mean_c')=='' if mean is None else numeric(a.get('mean_c'),mean))
    g.check('station_day_import',okay,'Configured station/date coverage, accepted replicate counts, and means are correct.')
    summary=(g.result or {}).get('summary',{})
    days=keyed(summary.get('days',[]),['date'])
    okay=set(days)=={(d,) for d in settings['dates']}
    for date in settings['dates']:
        means=[station_expected[(date,s)][1] for s in settings['stations']]
        present=sum(v is not None for v in means);complete=present==len(means)
        expected=sum(means,Fraction(0))/len(means) if complete else None
        d=days.get((date,),{})
        okay=okay and type(d.get('expected_stations')) is int and d.get('expected_stations')==len(means) and type(d.get('present_stations')) is int and d.get('present_stations')==present and type(d.get('complete')) is bool and d.get('complete')==complete and 'index_c' in d and (d['index_c'] is None if expected is None else isinstance(d['index_c'],(int,float)) and numeric(d['index_c'],expected))
    okay=okay and type(summary.get('source_rows')) is int and summary.get('source_rows')==len(raw) and type(summary.get('accepted_rows')) is int and summary.get('accepted_rows')==sum(status=='accepted' for status,_ in expected_audit.values())
    g.check('equal_station_index_and_coverage',okay,'Daily indices use equal station weight and remain null on incomplete station coverage.')
except (OSError,ValueError,KeyError,TypeError,AttributeError,ZeroDivisionError) as e:
    g.check('domain_artifacts_readable',False,str(e))
g.finish()
