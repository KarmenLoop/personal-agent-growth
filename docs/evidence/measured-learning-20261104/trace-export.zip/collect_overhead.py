from pathlib import Path
import datetime,hashlib,json,os,sys

ROOT=Path(__file__).resolve().parent;REPO=ROOT.parent/'开源发布/personal-agent-growth'
sys.path.insert(0,str(REPO/'scripts'));import capability_ledger as store;import task_costs
parent_id='01a15997-27e8-7c80-841f-ff2a7ad1ace1'
cutoff=datetime.datetime.fromisoformat('2026-11-03T17:09:09.274+00:00').timestamp()
out=ROOT/'overhead';out.mkdir(exist_ok=True)
records=[]
for day in ('03','04'):
    folder=Path('<HOME>/.codex/sessions/2026/11')/day
    if not folder.exists():continue
    for path in folder.glob('*.jsonl'):
        if path.stat().st_birthtime<cutoff:continue
        with path.open('rb') as stream:first=json.loads(stream.readline())
        meta=first.get('payload',{})
        if meta.get('parent_thread_id')!=parent_id:continue
        if meta.get('agent_path') not in ('/root/heldout_author','/root/measurement_review','/root/measured_guides'):continue
        selected={};latest=None
        with path.open('rb') as stream:
            for line in stream:
                try:item=json.loads(line)
                except ValueError:continue
                if item.get('type')!='token_usage_record':continue
                payload=item.get('payload',{})
                if payload.get('thread_id')!=meta['id']:continue
                key=payload.get('response_id');usage=payload.get('usage')
                if not key or not isinstance(usage,dict):continue
                selected[key]={'timestamp':item.get('timestamp'),'ordinal':item.get('ordinal'),'response_id':key,
                               'thread_id':payload.get('thread_id'),'turn_id':payload.get('turn_id'),'usage':usage}
                latest=payload.get('thread_token_usage')
        totals={key:sum(row['usage'].get(key,0) for row in selected.values()) for key in ('input_tokens','cached_input_tokens','cache_write_input_tokens','output_tokens','reasoning_output_tokens','total_tokens')}
        assert totals['total_tokens']==totals['input_tokens']+totals['output_tokens']
        complete=bool(selected) and latest is not None and all(totals[k]==latest.get(k) for k in totals)
        target=out/(meta['agent_path'].split('/')[-1]+'-native-usage.json')
        result={'agent_path':meta['agent_path'],'thread_id':meta['id'],'source_path':str(path),
                'source_bytes_at_snapshot':path.stat().st_size,'native_responses':list(selected.values()),
                'known_native_usage':totals,'matches_native_thread_counter':complete,
                'billed_usd':None,'scope':'Independent author/reviewer/guide Agent overhead, not charged to a candidate arm. Native metadata only; no chat text or private reasoning.'}
        target.write_text(json.dumps(result,indent=2)+'\n');records.append(result)
parent=json.loads((ROOT/'coordinator-native-usage.json').read_text()) if (ROOT/'coordinator-native-usage.json').exists() else None
probes=[]
for folder in ('host-probe','host-probe-compact','host-probe-http','host-probe-http-custom','agent-runs/controller-smoke'):
    path=ROOT/folder/'events.jsonl';data=path.read_bytes()
    usage=task_costs.native_usage(task_costs.parse_jsonl(data))
    probes.append({'id':folder,'events_path':str(path.relative_to(ROOT)),'events_sha256':hashlib.sha256(data).hexdigest(),
        'native_usage':usage,'scope':'Setup invocation, outside controlled study. An empty pre-configuration rejection is not an actual Agent success.'})
summary={'type':'study-overhead','id':'measured-transfer-overhead','recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'independent_agents':[{'agent_path':r['agent_path'],'thread_id':r['thread_id'],'known_native_usage':r['known_native_usage'],'complete_through_snapshot':r['matches_native_thread_counter']} for r in records],
         'coordinator':None if parent is None else {'known_native_usage':parent['known_native_usage'],'complete_through_snapshot':parent['matches_native_turn_counter']},
         'setup_cli_invocations':probes,'known_setup_native_tokens':sum(p['native_usage']['total_tokens'] or 0 for p in probes),
         'billed_usd':None,'scope':'Development/coordination overhead is separate from randomized leaf costs. Coordinator measurement is right-censored; setup elapsed phases without original clocks remain unknown.'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(ROOT/'study-overhead.md').write_bytes(store.encode(summary,'Actual host-provided usage metadata. Cached/reasoning token details are subsets, not added again. These are resource counts, not charges. No per-arm allocation or speed claim.'))
print(json.dumps({'independent_agent_records':len(records),'all_child_counters_match':all(r['matches_native_thread_counter'] for r in records),'coordinator_snapshot_available':parent is not None}))
