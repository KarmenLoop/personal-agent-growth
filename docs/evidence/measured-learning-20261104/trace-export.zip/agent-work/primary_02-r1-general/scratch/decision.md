# 执行前决定
目标：按 input/task.md 生成逐行审计、配置日期/站点全网格及等站点权重指数。
最小决定性问题：拒绝的最新修订是否遮蔽旧有效值？任务明确要求是；输入 b7/b8 是关键核对对象。
预测：18 个源行、12 个 accepted；b1/b7 superseded，b4/b8 rejected_quality，b3/c3 missing_value；第三天只有两个站点有值，指数 null。
核验：对实际输入逐行处理，校对上述判定、9 个站点日、手算每日均值与输入哈希。失败保留回执，不用旧版本回填。
经验：读取 learning/source-input.md、learning/experience/mechanism/context-support/experience.md 及两个 evidence 文件。采用“将结论绑定输入/环境”的通用原则；发票缓存与计算故障不适用于本任务，不迁移根因或旧测试结果。不做额外实验。
