import csv, hashlib, json, sys
from pathlib import Path
from decimal import Decimal, localcontext, ROUND_HALF_EVEN
from fractions import Fraction
from collections import Counter

root = Path.cwd()
raw = root / 'input/raw'
out = root / 'output'
def hashes():
    return {str(p.relative_to(root / 'input')): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(raw.rglob('*')) if p.is_file()}
before = hashes()
task_hash = hashlib.sha256((root/'input/task.md').read_bytes()).hexdigest()
settings = json.loads((raw/'settings.json').read_text())
with (raw/'measurements.csv').open(newline='') as f:
    rows = list(csv.DictReader(f))
def key(r):
    return r['date'], r['station'], r['replicate']
latest = {}
for r in rows:
    latest[key(r)] = max(latest.get(key(r), -1), int(r['revision']))
def fmt(x):
    with localcontext() as ctx:
        ctx.prec = 60
        return format((Decimal(x.numerator)/Decimal(x.denominator)).quantize(
            Decimal('.000001'), rounding=ROUND_HALF_EVEN), '.6f')
def numeric(s):
    return Fraction(Decimal(s))
accepted = {}
audit = []
for r in rows:
    value = None
    if int(r['revision']) != latest[key(r)]:
        disposition = 'superseded'
    elif r['quality'] != 'ok':
        disposition = 'rejected_quality'
    elif r['reading_c'] in ('', 'NA') or r['bias_c'] in ('', 'NA'):
        disposition = 'missing_value'
    else:
        disposition = 'accepted'
        value = numeric(r['reading_c']) - numeric(r['bias_c'])
        accepted.setdefault((r['date'], r['station']), []).append(value)
    # Calibrated inputs here terminate exactly; retain their exact decimal value.
    calibrated = '' if value is None else str(Decimal(value.numerator)/Decimal(value.denominator))
    audit.append({'row_id': r['row_id'], 'disposition': disposition, 'calibrated_c': calibrated})
station_days = []
days = []
for date in settings['dates']:
    means = []
    for station in settings['stations']:
        values = accepted.get((date, station), [])
        mean = sum(values, Fraction())/len(values) if values else None
        if mean is not None:
            means.append(mean)
        station_days.append({'date': date, 'station': station,
                             'accepted_replicates': len(values),
                             'mean_c': '' if mean is None else fmt(mean)})
    complete = len(means) == len(settings['stations'])
    index = sum(means, Fraction())/len(means) if complete else None
    days.append({'date': date, 'expected_stations': len(settings['stations']),
                 'present_stations': len(means), 'complete': complete,
                 'index_c': None if index is None else float(fmt(index))})
for filename, fields, data in [
    ('audit.csv', ['row_id','disposition','calibrated_c'], audit),
    ('station-days.csv', ['date','station','accepted_replicates','mean_c'], station_days)]:
    with (out/filename).open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(data)
result = {'schema': 1, 'task_id': 'primary_02',
          'data_kind': 'derived_fixture_not_actual_measurements',
          'source_sha256': before,
          'summary': {'source_rows': len(rows),
                      'accepted_rows': sum(r['disposition']=='accepted' for r in audit),
                      'days': days}}
(out/'result.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
(out/'report.md').write_text('''# 站点指数交接

本结果为离线派生测试夹具（derived_fixture_not_actual_measurements），不是实际环境观测。单位沿用配置：摄氏度异常值。

- `audit.csv`：18 条源记录逐行追踪，12 条接受、2 条被新修订取代、2 条质量拒绝、2 条缺值。仅接受行提供校准值。
- `station-days.csv`：3 天 × 3 个配置站点，共 9 行；包含有效重复数及站点日均值，缺值留空。
- `result.json`：严格 JSON，包含来源 SHA-256、记录数、完整性及等站点权重日指数。

| 日期 | 有值站点/配置站点 | 日指数 |
|---|---|---|
| 2026-01-01 | 3/3 | 0.133333 |
| 2026-01-02 | 3/3 | 0.233333 |
| 2026-01-03 | 2/3 | null |

先按日期/站点/重复编号选最高修订，再判质量和缺值；读取值减偏差后先求站点均值，再对站点等权平均。使用精确有理数计算，均值与指数仅在最终输出时舍入至六位小数（半偶舍入）。JSON 数值不保留末尾零。

1 月 2 日 Cedar 的 b8 为最新修订且遭拒绝，b7 不回填；该站仍有 b6，因此当天完整。1 月 3 日 Cedar 的 c3 读取值缺失，站点均值空白，日指数为 null；没有插补。要补全该日，需要有效的 Cedar 输入后重新导入。当前数据处理无其他未决项，结论仅适用于所附哈希对应的测试输入。
''')
# Contract checks against the current actual fixture, including independent hand calculations.
assert len(audit) == 18 and len(station_days) == 9
assert Counter(r['disposition'] for r in audit) == {
    'accepted': 12, 'superseded': 2, 'rejected_quality': 2, 'missing_value': 2}
assert {r['row_id']: r['disposition'] for r in audit if r['row_id'] in ('b7','b8')} == {
    'b7': 'superseded', 'b8': 'rejected_quality'}
assert [d['index_c'] for d in days] == [0.133333, 0.233333, None]
assert [d['present_stations'] for d in days] == [3,3,2]
assert [r['mean_c'] for r in station_days] == [
    '0.150000','0.200000','0.050000','0.300000','0.300000','0.100000',
    '0.200000','0.300000','']
assert hashes() == before
assert hashlib.sha256((root/'input/task.md').read_bytes()).hexdigest() == task_hash
loaded = json.loads((out/'result.json').read_text(), parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))
assert loaded == result
print(json.dumps({'status':'passed','stage':'actual fixture contract and source immutability checks',
                  'python':sys.version,'source_sha256':before,'dispositions':dict(Counter(r['disposition'] for r in audit)),
                  'station_day_rows':len(station_days),'days':days}, indent=2))
