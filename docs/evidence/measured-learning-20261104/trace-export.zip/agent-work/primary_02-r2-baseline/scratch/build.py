import csv, json, hashlib, io, sys
from pathlib import Path
from fractions import Fraction
from decimal import Decimal, localcontext, ROUND_HALF_UP
from collections import Counter

root = Path('.')
raw = root / 'input/raw'
out = root / 'output'
files = sorted(p for p in raw.rglob('*') if p.is_file())
hashes = {p.relative_to(root/'input').as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
settings = json.loads((raw/'settings.json').read_text())
rows = list(csv.DictReader(io.StringIO((raw/'measurements.csv').read_text())))
assert settings['data_kind'] == 'derived_fixture_not_actual_measurements'
def identity(r): return (r['date'], r['station'], r['replicate'])
latest = {}
for r in rows:
    key = identity(r)
    latest[key] = max(latest.get(key, -1), int(r['revision']))
assert len({r['row_id'] for r in rows}) == len(rows)
assert all(sum(identity(x)==k and int(x['revision'])==v for x in rows)==1 for k,v in latest.items())

def rounded(x):
    with localcontext() as ctx:
        ctx.prec = 80
        return (Decimal(x.numerator)/Decimal(x.denominator)).quantize(Decimal('0.000001'), rounding=ROUND_HALF_UP)
def number(x): return float(rounded(x))
def exact_text(x):
    with localcontext() as ctx:
        ctx.prec = 80
        return format(Decimal(x.numerator)/Decimal(x.denominator), 'f')

audit=[]
accepted={}
groups={(d,s):[] for d in settings['dates'] for s in settings['stations']}
for r in rows:
    assert (r['date'], r['station']) in groups
    value = None
    if int(r['revision']) < latest[identity(r)]:
        status = 'superseded'
    elif r['quality'] != 'ok':
        status = 'rejected_quality'
    elif any(r[c] in ('', 'NA') for c in ('reading_c','bias_c')):
        status = 'missing_value'
    else:
        status = 'accepted'
        value = Fraction(Decimal(r['reading_c'])) - Fraction(Decimal(r['bias_c']))
        groups[r['date'],r['station']].append(value)
        accepted[r['row_id']] = value
    audit.append({'row_id':r['row_id'], 'disposition':status, 'calibrated_c': '' if value is None else exact_text(value)})
with (out/'audit.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['row_id','disposition','calibrated_c']); w.writeheader(); w.writerows(audit)
means={k:sum(v,Fraction())/len(v) if v else None for k,v in groups.items()}
station_days=[{'date':d,'station':s,'accepted_replicates':len(groups[d,s]), 'mean_c':'' if means[d,s] is None else format(rounded(means[d,s]),'f')} for d,s in groups]
with (out/'station-days.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['date','station','accepted_replicates','mean_c']); w.writeheader(); w.writerows(station_days)
days=[]
for d in settings['dates']:
    values=[means[d,s] for s in settings['stations'] if means[d,s] is not None]
    complete=len(values)==len(settings['stations'])
    days.append(dict(date=d,expected_stations=len(settings['stations']),present_stations=len(values),complete=complete,index_c=number(sum(values,Fraction())/len(values)) if complete else None))
result={'schema':1,'task_id':'primary_02','data_kind':settings['data_kind'],'source_sha256':hashes,'summary':{'source_rows':len(rows),'accepted_rows':len(accepted),'days':days}}
(out/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
(out/'report.md').write_text('''# 站点指数交接

本批为明确标注的派生分析夹具，不是真实环境观测；单位为摄氏度距平。

- `audit.csv`：18 个来源行的完整处置记录；12 行接受。先判最高修订，再判质量及缺值，仅接受行给出校准值。
- `station-days.csv`：3 日 × 3 个配置站点，共 9 行。日均值保留六位小数，缺值留空。
- `result.json`：严格 JSON，附所有原始文件 SHA-256、行数及每日完整性；指数按未舍入的站点日均值等权计算，最后四舍五入至六位。

| 日期 | 有值站点/应有站点 | 指数 |
|---|---|---|
| 2026-01-01 | 3/3 | 0.133333 |
| 2026-01-02 | 3/3 | 0.233333 |
| 2026-01-03 | 2/3 | null |

2026-01-03 的 Cedar 唯一当前行 c3 缺少 reading，故本站均值为空、当日指数为 null；需要新的有效来源记录才能补全，未做插补。b1 和 b7 已被后续修订取代；b8 被拒绝，因此 b7 不回退参与计算。2026-01-02 Cedar 仅 b6 有效，其均值为 0.100000。

核验覆盖本次输入的逐行分类、站点日覆盖、汇总值、严格 JSON 及输入哈希；没有将既有经验的发票缺陷结论当作本站点任务证据。未发现其他未解决的数据处理项；未验证外部导入系统。
''')
# Actual task checks; no synthetic trials.
assert Counter(r['disposition'] for r in audit)=={'accepted':12,'superseded':2,'missing_value':2,'rejected_quality':2}
assert [d['index_c'] for d in days]==[0.133333,0.233333,None]
assert [len(groups[d,s]) for d,s in groups]==[2,3,2,1,1,1,1,1,0]
assert accepted['a6']==Fraction(-1,10) and accepted['b2']==Fraction(3,10)
assert means['2026-01-02','Cedar']==Fraction(1,10)
assert len(station_days)==9 and len(audit)==18
assert all((r['calibrated_c']!='')==(r['disposition']=='accepted') for r in audit)
assert json.loads((out/'result.json').read_text())==result
assert hashes=={p.relative_to(root/'input').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
verification={'stage':'generated artifacts and task assertions completed','status':'passed','source_sha256':hashes,'artifact_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file()},'source_rows':len(rows),'accepted_rows':len(accepted),'dispositions':dict(Counter(r['disposition'] for r in audit)),'python':sys.version,'source_experience_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('learning/source-input.md'),Path('learning/experience/mechanism/context-support/experience.md'),Path('learning/evidence/receipt-4.json'),Path('learning/evidence/response-4.md')]}}
Path('scratch/verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps({'status':'passed','summary':result['summary'],'dispositions':verification['dispositions']},indent=2))
