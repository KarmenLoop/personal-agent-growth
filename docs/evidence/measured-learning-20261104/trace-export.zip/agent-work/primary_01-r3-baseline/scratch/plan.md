# primary_01 执行前记录
目标：核验 input/raw/bundles 三个目录的所有声明与实际文件，生成完整 CSV、严格 JSON 和简短报告。
完成依据：每个声明组合一行、额外文件另列；公开字节按 public_sha256 核验；原始哈希仅保留溯源；所有 raw 文件入 source_sha256；源文件前后不变。
预测：公开脱敏衍生文件可能与 original_sha256 不同，这不构成传输错误；实际是否符合 public_sha256 尚未知。
核验办法：逐个读取实际字节，计算 SHA-256；集合差发现缺失和额外文件；输出后核对行数、计数与源文件哈希。
失败后继：如读取或生成失败，保留命令回执并明确未达到阶段；不把未知写成通过。
经验：读取 learning/source-input.md、learning/experience/mechanism/context-support/experience.md、learning/evidence/response-4.md。采用 context-support 的证据归属原则，映射为 bundle/path/实际字节绑定；不迁移发票缓存诊断。其 receipt-4.json 未提供，源经验完整回执不可复核。不同 transport variant 不推翻其他目录独立哈希结果，也不能推断历史官方发布损坏。
范围：离线历史输入审计，不运行源材料命令，不验证历史测试或实时发布，不开展额外实验。
