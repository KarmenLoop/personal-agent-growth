from pathlib import Path
import hashlib, json, csv, collections, sys
root=Path.cwd(); inp=root/'input'; raw=inp/'raw'; out=root/'output'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def sources(): return {p.relative_to(inp).as_posix():sha(p) for p in sorted(raw.rglob('*')) if p.is_file()}
before=sources(); task_before=sha(inp/'task.md')
record=json.loads((raw/'publication-record.json').read_text())
rows=[]; bundles={}
for bundle in record['bundles']:
    directory=raw/'bundles'/bundle
    declared={f['path']:f for f in record['files']}
    actual={p.relative_to(directory).as_posix():p for p in directory.rglob('*') if p.is_file()}
    for path,f in declared.items():
        original=f['original_sha256']; public=f['public_sha256']
        relation='unchanged' if original==public else ('redacted_derivative' if f.get('path_redacted') is True else 'undocumented_difference')
        p=actual.get(path)
        data=p.read_bytes() if p is not None else None
        digest=hashlib.sha256(data).hexdigest() if data is not None else ''
        status='missing' if data is None else ('verified' if digest==public else 'mismatch')
        rows.append(dict(bundle=bundle,path=path,status=status,observed_bytes=len(data) if data is not None else '',observed_sha256=digest,declared_public_sha256=public,original_sha256=original,publication_relation=relation))
    for path in sorted(actual.keys()-declared.keys()):
        data=actual[path].read_bytes()
        rows.append(dict(bundle=bundle,path=path,status='unlisted',observed_bytes=len(data),observed_sha256=hashlib.sha256(data).hexdigest(),declared_public_sha256='',original_sha256='',publication_relation='unknown'))
    br=[r for r in rows if r['bundle']==bundle]
    counts=collections.Counter(r['status'] for r in br)
    bundles[bundle]={s:counts[s] for s in ('verified','mismatch','missing','unlisted')}
    bundles[bundle]['handoff_ready']=all(r['status']=='verified' for r in br)
counts=collections.Counter(r['status'] for r in rows)
summary={'declared_files':len(record['bundles'])*len(record['files']), 'verified_files':counts['verified'],'mismatched_files':counts['mismatch'],'missing_files':counts['missing'],'unlisted_files':counts['unlisted'],'verified_redacted_derivatives':sum(r['status']=='verified' and r['publication_relation']=='redacted_derivative' for r in rows),'handoff_ready':all(r['status']=='verified' for r in rows),'bundles':bundles}
fields=['bundle','path','status','observed_bytes','observed_sha256','declared_public_sha256','original_sha256','publication_relation']
with (out/'audit.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
result={'schema':1,'task_id':'primary_01','data_kind':'historical_inputs_with_controlled_integrity_variants','source_sha256':before,'summary':summary}
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
lines=['# 离线交接审计','',f"共 {summary['declared_files']} 个声明文件组合：{counts['verified']} 个通过、{counts['mismatch']} 个不匹配、{counts['missing']} 个缺失；另有 {counts['unlisted']} 个未列文件。整体 handoff_ready：{str(summary['handoff_ready']).lower()}。",'', '| 目录 | 通过 | 不匹配 | 缺失 | 未列 | 可交接 |','| --- | ---: | ---: | ---: | ---: | --- |']
for b,c in bundles.items(): lines.append(f"| {b} | {c['verified']} | {c['mismatch']} | {c['missing']} | {c['unlisted']} | {str(c['handoff_ready']).lower()} |")
lines+=['','## 异常与待处理','']
for r in rows:
    if r['status']!='verified':
        lines.append(f"- `{r['bundle']}/{r['path']}`：{r['status']}。"+(f"公开声明 `{r['declared_public_sha256']}`；实际 `{r['observed_sha256']}`。" if r['status']=='mismatch' else ''))
lines+=['','应按公开清单恢复不匹配和缺失文件，确认并移除或正式声明未列文件，然后重新核验。本次保留输入原状，未修复运输变体。','','## 证据范围','',f"`audit.csv` 逐项提供字节数、实际 SHA-256、公开声明哈希及原始来源哈希；`result.json` 记录所有 {len(before)} 个 raw 文件的实际哈希。核验依据为 `input/raw/publication-record.json`。已验证脱敏衍生文件共 {summary['verified_redacted_derivatives']} 个，原始哈希与公开哈希不同是已声明的来源关系，不是交付不匹配。",'','结论仅针对本次历史输入与受控运输变体。原始来源文件未提供，无法独立核实其历史原始字节；原始哈希仅作为声明保留。未执行输入内命令，未验证历史测试、业务功能或实时官方发布；这些运输异常不能证明历史官方发布损坏。','','采用经验 `learning/experience/mechanism/context-support/experience.md` 的条件化证据原则：每个结论绑定具体目录和字节，其他目录的异常不撤销独立通过结果。未迁移发票领域根因；缺少的源经验回执仍属未核实。']
(out/'report.md').write_text('\n'.join(lines)+'\n')
assert sources()==before and sha(inp/'task.md')==task_before
loaded=list(csv.DictReader((out/'audit.csv').open(newline='')))
assert len(loaded)==summary['declared_files']+summary['unlisted_files']
assert len({(r['bundle'],r['path']) for r in loaded})==len(loaded)
assert json.loads((out/'result.json').read_text())==result
receipt={'stage':'audit_generated_and_consistency_checked','exit_status':0,'raw_file_count':len(before),'csv_rows':len(loaded),'inputs_unchanged':True,'python':sys.version,'artifacts_sha256':{p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file()},'summary':summary}
(root/'scratch/verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
