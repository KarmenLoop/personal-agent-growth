# 离线交接审计

共 18 个声明文件组合：16 个通过、1 个不匹配、1 个缺失；另有 1 个未列文件。整体 handoff_ready：false。

| 目录 | 通过 | 不匹配 | 缺失 | 未列 | 可交接 |
| --- | ---: | ---: | ---: | ---: | --- |
| handoff-a | 6 | 0 | 0 | 0 | true |
| handoff-b | 5 | 1 | 0 | 0 | false |
| handoff-c | 5 | 0 | 1 | 1 | false |

## 异常与待处理

- `handoff-b/final-tests.stderr`：mismatch。公开声明 `fce44eea8a1322b604cbad38cc3a0ea2f9fd7c3ae964a4b95d89556b21aacf43`；实际 `d4a03401234ee9a70026284e17f3ca0c1a96533e97db8e1ae8a3ad7ff4ab0416`。
- `handoff-c/ledger-green.stderr`：missing。
- `handoff-c/local-note.txt`：unlisted。

应按公开清单恢复不匹配和缺失文件，确认并移除或正式声明未列文件，然后重新核验。本次保留输入原状，未修复运输变体。

## 证据范围

`audit.csv` 逐项提供字节数、实际 SHA-256、公开声明哈希及原始来源哈希；`result.json` 记录所有 19 个 raw 文件的实际哈希。核验依据为 `input/raw/publication-record.json`。已验证脱敏衍生文件共 9 个，原始哈希与公开哈希不同是已声明的来源关系，不是交付不匹配。

结论仅针对本次历史输入与受控运输变体。原始来源文件未提供，无法独立核实其历史原始字节；原始哈希仅作为声明保留。未执行输入内命令，未验证历史测试、业务功能或实时官方发布；这些运输异常不能证明历史官方发布损坏。

采用经验 `learning/experience/mechanism/context-support/experience.md` 的条件化证据原则：每个结论绑定具体目录和字节，其他目录的异常不撤销独立通过结果。未迁移发票领域根因；缺少的源经验回执仍属未核实。
