# primary_01 完成节点

目标和执行前预测见 ../scratch/plan.md，执行助手见 ../scratch/audit.py；独立输出核验见 ../scratch/verify.py 与 ../scratch/verification.txt。输入只读，实际核验使用逐文件哈希一致的 scratch 副本。

结果：18 个声明项，16 verified、1 mismatch、1 missing，另有 1 unlisted；9 个 verified redacted_derivative。handoff-a 六项通过；handoff-b 的 final-tests.stderr 不匹配；handoff-c 缺 ledger-green.stderr 且多 local-note.txt。整体 handoff_ready=false。三份交付物在 ../output/。

来源使用：context-support / context-support-model 的变量及有向关系映射见执行前记录，读取版本哈希见 verification.txt。两个记录来自同一源，不独立计证。当前 publication-record 的 public_sha256、original_sha256、path_redacted 明确区分两个版本，决定性条件成立；九项实际字节匹配公开哈希而非原始哈希，支持有限采用按上下文绑定证据的做法。来源缓存故障的机制解释拒绝直接迁移。

反馈：预测在本次审计范围得到支持，脱敏差异不构成交付损坏，但 handoff-b 实际公开哈希差异仍须判 mismatch。该结果不改变旧任务中两个独立缺陷的结论，不证明经验在其他领域普适。

未解决：字节差异的产生原因、历史软件功能、现场发布状态、私有原文件完整性均未核验。没有运行额外实验，没有估算宿主原生 token、成本或通用能力。后继条件为形成修复后的交接包再独立审计，本次不修改输入或安排后台工作。
