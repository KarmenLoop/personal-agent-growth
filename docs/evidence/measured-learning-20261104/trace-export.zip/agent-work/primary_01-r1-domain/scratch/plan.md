# primary_01 执行前记录
目标：逐一审计三个交接目录的全部声明项及额外文件；仅交付字节完整性审计，不运行历史日志内命令或发布验收。
完成依据：CSV 完整覆盖、public_sha256 决定状态、结果严格 JSON、所有 raw 文件实际哈希、简短报告。
当前未知：哪些交付字节偏离公开声明、是否缺项及额外文件。下一步复制 input/raw 后枚举并计算 SHA-256；若与源副本不一致则停止，不沿用结果。

## 来源经验映射与预测
读取 learning/experience/mechanism/context-support/experience.md、context-support-model/experience.md 以及 learning/evidence/response-4.md；两个经验来自同一来源，不算独立证据。
旧变量 context → 本任务的 bundle、路径、公开/原始版本；evidence → 当前文件字节及 SHA-256；decision → 该项状态和交接就绪结论。
有向关系：版本/路径上下文限定可使用的哈希证据；实际字节与对应公开哈希的比较支持完整性结论；逐项完整性及未列项共同决定 handoff_ready。
必须条件：记录确实为目标公开导出声明且每项能对应目标路径。最可能破坏类比的缺失条件：没有区分原始版本与公开版本的权威声明。此处待核记录的 public_sha256、original_sha256 和 path_redacted 能否提供该区分。
可观察预测：若实际字节匹配 public_sha256，即便不匹配 original_sha256 且标注 path_redacted，也应验证通过并标 redacted_derivative；不同 bundle 需分别检查。
反证：若实际字节与公开哈希不同，脱敏标志不能证明该交付项完整；若记录无法对应版本，则结论只能未知。来源中的缓存/计算缺陷不迁移为本任务根因。
行动选项：直接逐文件读取即可解决决定性未知，无需网络、额外实验或历史程序执行。
