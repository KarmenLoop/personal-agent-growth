from pathlib import Path
import csv,json,hashlib,collections
r=Path.cwd()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result=json.loads((r/'output/result.json').read_text(),parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
rows=list(csv.DictReader((r/'output/audit.csv').open(newline='')))
record=json.loads((r/'input/raw/publication-record.json').read_text())
expected={(b,e['path']) for b in record['bundles'] for e in record['files']}
actual={(p.parent.name,p.name) for p in (r/'input/raw/bundles').rglob('*') if p.is_file()}
keys=[(x['bundle'],x['path']) for x in rows]
assert len(keys)==len(set(keys)) and set(keys)==expected|actual
for row in rows:
 p=r/'input/raw/bundles'/row['bundle']/row['path']
 if p.is_file():
  assert row['observed_sha256']==h(p) and int(row['observed_bytes'])==len(p.read_bytes())
 else: assert row['status']=='missing' and row['observed_sha256']==row['observed_bytes']==''
 if (row['bundle'],row['path']) in expected:
  e=next(x for x in record['files'] if x['path']==row['path'])
  assert row['declared_public_sha256']==e['public_sha256'] and row['original_sha256']==e['original_sha256']
  assert row['status']==('missing' if not p.is_file() else 'verified' if h(p)==e['public_sha256'] else 'mismatch')
 else: assert row['status']=='unlisted' and row['declared_public_sha256']==row['original_sha256']==''
assert result['source_sha256']=={'raw/'+p.relative_to(r/'input/raw').as_posix():h(p) for p in (r/'input/raw').rglob('*') if p.is_file()}
assert result['schema']==1 and result['task_id']=='primary_01'
assert result['summary']==dict(declared_files=18,verified_files=16,mismatched_files=1,missing_files=1,unlisted_files=1,verified_redacted_derivatives=9,handoff_ready=False)
print('PASS: strict JSON; 19 unique audit rows; complete declared/actual coverage; actual hashes and sizes; summary; all 19 raw source hashes.')
paths=['learning/experience/mechanism/context-support/experience.md','learning/experience/mechanism/context-support-model/experience.md','learning/evidence/response-4.md','learning/evidence/receipt-4.json']
for p in paths: print(p,h(r/p))
