from pathlib import Path
import hashlib, json, csv, shutil, collections
root=Path.cwd()
src=root/'input/raw'
work=root/'scratch/raw'
shutil.copytree(src,work)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source={f'raw/{p.relative_to(src).as_posix()}':sha(p) for p in sorted(src.rglob('*')) if p.is_file()}
assert source=={f'raw/{p.relative_to(work).as_posix()}':sha(p) for p in sorted(work.rglob('*')) if p.is_file()}
record=json.loads((work/'publication-record.json').read_text())
rows=[]
for bundle in record['bundles']:
    base=work/'bundles'/bundle
    declared={x['path']:x for x in record['files']}
    for path,entry in declared.items():
        p=base/path
        exists=p.is_file()
        digest=sha(p) if exists else ''
        relation=('unchanged' if entry['original_sha256']==entry['public_sha256'] else 'redacted_derivative' if entry.get('path_redacted') else 'undocumented_difference')
        rows.append(dict(bundle=bundle,path=path,status=('verified' if digest==entry['public_sha256'] else 'mismatch') if exists else 'missing',observed_bytes=p.stat().st_size if exists else '',observed_sha256=digest,declared_public_sha256=entry['public_sha256'],original_sha256=entry['original_sha256'],publication_relation=relation))
    for p in sorted(base.rglob('*')):
        if p.is_file() and p.relative_to(base).as_posix() not in declared:
            rows.append(dict(bundle=bundle,path=p.relative_to(base).as_posix(),status='unlisted',observed_bytes=p.stat().st_size,observed_sha256=sha(p),declared_public_sha256='',original_sha256='',publication_relation='unknown'))
counts=collections.Counter(r['status'] for r in rows)
summary=dict(declared_files=len(record['bundles'])*len(record['files']),verified_files=counts['verified'],mismatched_files=counts['mismatch'],missing_files=counts['missing'],unlisted_files=counts['unlisted'],verified_redacted_derivatives=sum(r['status']=='verified' and r['publication_relation']=='redacted_derivative' for r in rows),handoff_ready=not any(counts[s] for s in ('mismatch','missing','unlisted')))
out=root/'output'
with (out/'audit.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=['bundle','path','status','observed_bytes','observed_sha256','declared_public_sha256','original_sha256','publication_relation'])
    writer.writeheader();writer.writerows(rows)
result=dict(schema=1,task_id='primary_01',data_kind='historical_inputs_with_controlled_integrity_variants',source_sha256=source,summary=summary)
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
lines=['# 离线交接审计','',f"共 {summary['declared_files']} 个声明文件项：{counts['verified']} 项验证通过，{counts['mismatch']} 项不匹配，{counts['missing']} 项缺失；另有 {counts['unlisted']} 个未列文件。整体 handoff_ready 为 {str(summary['handoff_ready']).lower()}。",'', '| 目录 | 通过 | 不匹配 | 缺失 | 未列项 | 就绪 |','|---|---:|---:|---:|---:|---|']
for b in record['bundles']:
    c=collections.Counter(r['status'] for r in rows if r['bundle']==b)
    lines.append(f"| {b} | {c['verified']} | {c['mismatch']} | {c['missing']} | {c['unlisted']} | {'是' if not any(c[x] for x in ('mismatch','missing','unlisted')) else '否'} |")
lines+=['','需处理的交付差异：','']
for r in rows:
    if r['status']!='verified': lines.append(f"- `{r['bundle']}/{r['path']}`：`{r['status']}`。")
lines+=['',f"通过项中有 {summary['verified_redacted_derivatives']} 个已声明的脱敏衍生文件。验收以 `public_sha256` 为准；`original_sha256` 仅保留来源信息，不能用它替代公开版本的验收哈希。关系标签依据声明生成，即使交付项缺失或不匹配也不改变该标签。",'', '`audit.csv` 保留逐项实际字节数、实际哈希、两种声明哈希及出版关系；`result.json` 汇总并列出全部 raw 文件的实际 SHA-256（包含发布记录及额外文件）。本次读取 scratch 中与输入逐文件哈希一致的副本，未修改输入。','', '范围：历史项目公开脱敏输入及受控传输变体的离线字节审计。没有执行日志内指令，也未验证历史测试、软件功能、原始私有文件或现场发布状态。受控变体不证明历史官方发布受损。差异原因与修复后状态尚未知；应按公开声明补齐或替换差异项，并确认未列项用途后形成新的交接包再审计。','', '经验迁移：采用“证据须绑定具体版本与路径”的有限原则。发布记录中明确的公开/原始哈希及脱敏标记满足版本区分条件，实际哈希比较完成决定性核验。来源中的缓存故障不适用于此任务；不据此推断差异根因。']
(out/'report.md').write_text('\n'.join(lines)+'\n')
assert source=={f'raw/{p.relative_to(src).as_posix()}':sha(p) for p in sorted(src.rglob('*')) if p.is_file()}
print(json.dumps(summary,ensure_ascii=False))
print(json.dumps([r for r in rows if r['status']!='verified'],ensure_ascii=False,indent=2))
