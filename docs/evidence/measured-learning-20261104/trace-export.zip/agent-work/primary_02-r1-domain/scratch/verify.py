import csv,json,hashlib
from pathlib import Path
p=Path('output')
a=list(csv.DictReader((p/'audit.csv').open()))
s=list(csv.DictReader((p/'station-days.csv').open()))
r=json.loads((p/'result.json').read_text(),parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
expected=[('a1','accepted','0.1'),('a2','accepted','0.2'),('a3','accepted','0.1'),('a4','accepted','0.2'),('a5','accepted','0.3'),('a6','accepted','-0.1'),('a7','accepted','0.2'),('b1','superseded',''),('b2','accepted','0.3'),('b3','missing_value',''),('b4','rejected_quality',''),('b5','accepted','0.3'),('b6','accepted','0.1'),('b7','superseded',''),('b8','rejected_quality',''),('c1','accepted','0.2'),('c2','accepted','0.3'),('c3','missing_value','')]
assert [tuple(x.values()) for x in a]==expected
assert [tuple(x.values()) for x in s]==[
('2026-01-01','Alder','2','0.150000'),('2026-01-01','Birch','3','0.200000'),('2026-01-01','Cedar','2','0.050000'),
('2026-01-02','Alder','1','0.300000'),('2026-01-02','Birch','1','0.300000'),('2026-01-02','Cedar','1','0.100000'),
('2026-01-03','Alder','1','0.200000'),('2026-01-03','Birch','1','0.300000'),('2026-01-03','Cedar','0','')]
assert r['schema']==1 and r['task_id']=='primary_02' and r['data_kind']=='derived_fixture_not_actual_measurements'
assert r['summary']=={'source_rows':18,'accepted_rows':12,'days':[
{'date':'2026-01-01','expected_stations':3,'present_stations':3,'complete':True,'index_c':0.133333},
{'date':'2026-01-02','expected_stations':3,'present_stations':3,'complete':True,'index_c':0.233333},
{'date':'2026-01-03','expected_stations':3,'present_stations':2,'complete':False,'index_c':None}]}
assert r['source_sha256']=={str(f.relative_to('input')):hashlib.sha256(f.read_bytes()).hexdigest() for f in Path('input/raw').rglob('*') if f.is_file()}
assert set(x.name for x in p.iterdir())=={'audit.csv','station-days.csv','result.json','report.md'}
print('PASS: all 18 audit rows; all 9 station-days; exact expected indices; missing-day null; schema; raw SHA-256; four deliverables.')
