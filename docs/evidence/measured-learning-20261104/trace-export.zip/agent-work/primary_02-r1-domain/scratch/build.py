from pathlib import Path
import csv, json, hashlib
from decimal import Decimal, localcontext, ROUND_HALF_EVEN
from fractions import Fraction
from collections import Counter
root=Path('.')
out=root/'output'
raw=root/'input/raw'
hashes={str(p.relative_to(root/'input')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(raw.rglob('*')) if p.is_file()}
settings=json.loads((raw/'settings.json').read_text())
rows=list(csv.DictReader((raw/'measurements.csv').open(newline='')))
def key(r): return (r['date'],r['station'],r['replicate'])
latest={key(r):max(int(s['revision']) for s in rows if key(s)==key(r)) for r in rows}
def exact(v): return Fraction(Decimal(v))
def dec(v, rounded=False):
    with localcontext() as ctx:
        ctx.prec=80
        d=Decimal(v.numerator)/Decimal(v.denominator)
        if rounded: d=d.quantize(Decimal('.000001'), rounding=ROUND_HALF_EVEN)
        return format(d,'f')
audit=[]; groups={}
for r in rows:
    v=None
    if int(r['revision']) != latest[key(r)]: status='superseded'
    elif r['quality']!='ok': status='rejected_quality'
    elif any(r[c] in ('','NA') for c in ('reading_c','bias_c')): status='missing_value'
    else:
        status='accepted'; v=exact(r['reading_c'])-exact(r['bias_c'])
        groups.setdefault((r['date'],r['station']),[]).append(v)
    audit.append({'row_id':r['row_id'],'disposition':status,'calibrated_c':dec(v) if v is not None else ''})
stationdays=[]; days=[]
for date in settings['dates']:
    means=[]
    for station in settings['stations']:
        values=groups.get((date,station),[])
        mean=sum(values,Fraction())/len(values) if values else None
        if mean is not None: means.append(mean)
        stationdays.append({'date':date,'station':station,'accepted_replicates':len(values),'mean_c':dec(mean,True) if mean is not None else ''})
    complete=len(means)==len(settings['stations'])
    days.append({'date':date,'expected_stations':len(settings['stations']),'present_stations':len(means),'complete':complete,'index_c':float(dec(sum(means,Fraction())/len(means),True)) if complete else None})
for name, data, fields in [('audit.csv',audit,['row_id','disposition','calibrated_c']),('station-days.csv',stationdays,['date','station','accepted_replicates','mean_c'])]:
    with (out/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(data)
result={'schema':1,'task_id':'primary_02','data_kind':'derived_fixture_not_actual_measurements','source_sha256':hashes,'summary':{'source_rows':len(rows),'accepted_rows':sum(r['disposition']=='accepted' for r in audit),'days':days}}
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
(out/'report.md').write_text('''# 站点指数交接

本包是明确标注的离线衍生夹具，不是真实环境观测。共处理 18 条源记录，接受 12 条；2 条被替代、2 条质量拒绝、2 条缺值。

- `audit.csv`：18 条逐行审计，仅 accepted 行含校准值。
- `station-days.csv`：配置的 3 日 × 3 站点，共 9 行；空均值表示无可用重复。
- `result.json`：严格 JSON，含来源 SHA-256、计数、日完整性及指数。

| 日期 | 有值站点/配置站点 | 日指数 |
|---|---|---|
| 2026-01-01 | 3/3 | 0.133333 |
| 2026-01-02 | 3/3 | 0.233333 |
| 2026-01-03 | 2/3 | null |

2026-01-03 的 Cedar 当前记录缺 reading，因此站点均值留空、日指数为 null；未插补。最新修订先于质量筛选，b8 被拒绝后不回退 b7。校准后先取站点内重复均值，再对配置站点等权；指数使用未舍入站点均值计算，报告均值和指数保留六位小数（JSON 数字不强制尾随零）。采用精确有理数计算，最终按十进制 half-even 舍入；本夹具没有六位舍入中点歧义。

输入 raw 和 task.md 未修改。验证证据及经验适用边界见任务目录 learning/primary_02-transfer.md，执行日志见 scratch/。不完整日期是源数据约束，补齐有效当前记录前无法提供完整指数；本次未验证真实环境数据或外部系统。
''')
print(json.dumps({'source_sha256':hashes,'dispositions':dict(Counter(r['disposition'] for r in audit)),'days':days},ensure_ascii=False,indent=2))
