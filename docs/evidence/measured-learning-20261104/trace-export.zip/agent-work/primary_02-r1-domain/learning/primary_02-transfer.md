# primary_02：执行前记录

目标：从只读 input/raw 生成四份可用交付，逐行审计、配置日期站点笛卡尔积、等站点权重；只表示衍生夹具。完成依据为实际输入上的计算及交付物回读检查。不启动额外实验。

已读来源：source-input.md、source-model.md、experience/mechanism/context-support/experience.md、experience/mechanism/context-support-model/experience.md，以及 evidence/response-4.md、evidence/receipt-4.json。两份模型来自同一来源，不算独立证据。原记录中的退出码 1 是缓存复现失败，不能当成本任务失败或当前产品通过。

候选变量映射：来源 scope（入口及输入）→目标 scope（日期、站点、重复编号、修订）；来源 observation（某入口实算金额）→目标 observation（该修订质量和校准值）；来源 conclusion（该入口缺陷判断）→目标 conclusion（本行贡献资格、站点均值和日指数）。有向关系 scope → observation（限定证据）→ conclusion（支持判断）。

必要条件：证据必须绑定具体上下文。最易破坏类比的条件是“新上下文必使旧结论失效”：来源并非如此；目标的旧修订失效则由 task.md 明确规定，不能从缓存经验推导。当前输入 b1/b2、b7/b8 确实有不同修订，前提已在原 CSV 核实。

决定：适配采用证据绑定原则；拒绝迁移缓存根因或经验中的业务公式。预测 b1、b7 均 superseded；b8 为 rejected_quality，b7 不复活；其他身份独立判断。若最高修订仍允许旧行贡献，或不相关身份也被撤回，则否定这次实现。汇总必须先重复→站点，再站点→日期，第三日因 Cedar 缺值应为 null。

执行计划：Python 精确十进制转有理数计算，最终六位舍入；保存源文件 SHA-256。回读输出核对所有行、缺失、修订、等权及严格 JSON。失败原样留在 scratch/ 日志，不作额外实验。未知：原生计费与一般跨任务效果；不估计、不声称能力升级。

## 完成观察与范围

实际运行：指定 Python 3.12.14，`-B scratch/build.py`，退出码 0，原始 stdout/stderr 在 scratch/build.stdout 与 scratch/build.stderr。实际回读：`-B scratch/verify.py`，退出码 0，完整输入、环境、stdout、stderr、检查脚本和交付物哈希见 scratch/verification-receipt.json；原始输出另存 scratch/verify.stdout、scratch/verify.stderr。本次无执行失败；来源任务的历史失败仍保留在原证据中。

18 条审计、9 个站点日、12 条接受记录及两个完整日指数核对通过。b1、b7 superseded，b8 rejected_quality；第三日 Cedar 缺失，日指数 null，符合执行前预测。数值检查使用逐行预期值和站点均值人工展开后的独立回读断言，没有增加任务外实验。原始文件哈希与 result.json 一致。

迁移反馈：证据上下文绑定在本任务中被实际适配使用，帮助明确修订与独立身份的边界；这不能证明缓存和站点修订有同一根因，也不能证明此经验带来提速或普适收益。目标业务规则的权威依据始终是 input/task.md。来源 scope→observation→conclusion 只保留为有条件的准备框架，未升级因果模型置信度。本任务简单且一次执行完成，使用本 Markdown 记录计划、实际动作与观察，未引入额外学习状态机或实验。

未解决：第三日没有完整指数，只有源数据补齐后才能重算；真实环境适用性未测。任务已完成，无后台安排，无待用户决策。原生用量由宿主记录，本任务不估计。
