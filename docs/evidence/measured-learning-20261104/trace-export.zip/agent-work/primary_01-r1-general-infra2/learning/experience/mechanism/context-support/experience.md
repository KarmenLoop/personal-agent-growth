---
{
  "id": "context-support",
  "type": "mechanism-experience",
  "source_task_id": "invoice-judgment-20261103",
  "domain": "invoice-debugging",
  "problem_structure": [
    "evidence-bound-claim",
    "multiple-entry-paths"
  ],
  "mechanisms": [
    "context-dependent-support"
  ],
  "required_conditions": {
    "evidence-bound-to-a-specific-context": true
  },
  "exceptions": [
    "A change in context does not automatically refute independently supported claims.",
    "Structural similarity alone does not prove a common cause or an effective intervention."
  ],
  "intervention": "Bind each observation and conclusion to the actual input, version and execution path; test the changed condition before extending or withdrawing the claim.",
  "explanation": "In the actual source task a new entry path demonstrated a cache defect while the original direct-call calculation defect remained valid. The source artifacts show the distinct inputs and actual results.",
  "validation": "supported",
  "executor": "agent/judgment-candidate-20261103",
  "reviewer": "coordinator/independent-source-review",
  "artifacts": [
    {
      "path": "evidence/response-4.md",
      "sha256": "90140a90bea97ff51d508f2cce951c2ce59e3e04efd2b602ea896c9e2a30083e"
    },
    {
      "path": "evidence/receipt-4.json",
      "sha256": "a1b0e4ee48eeff5f38c923f42094e930ed175911b0e1076650131bddb0e9676c"
    }
  ],
  "schema": 1,
  "created_at": "2026-11-03T17:41:48.358097+00:00"
}
---

Source lesson from an actual completed Agent task. It is not a diagnosis for the held-out task.
