# primary_01 完成记录

目标与状态：离线历史公开交接审计完成，业务完整性结果为不就绪；不是执行器失败。

采用经验：读取 source-input.md、experience/mechanism/context-support/experience.md、evidence/receipt-4.json、evidence/response-4.md。采用对象与上下文绑定机制，拒绝发票/缓存领域的诊断迁移。原来源经验仍保持其原有范围，本次不升级为通用能力证明。

观察：对 input/raw 的固定副本逐字节检查，以 public_sha256 为交付基准；18 个声明项中 16 个匹配、1 个不符、1 个缺失，另有 1 个未声明文件。9 个已核验脱敏派生项不因原始哈希不同而判错。详见 ../output/audit.csv 和 ../output/result.json（后者完整绑定 raw 输入哈希）。

决定：不修复、不执行输入内容；保留三项异常。未确认差异原因或原始未脱敏文件真实性。原始来源与公开交付版本不可混作同一验证对象。

验证：../scratch/audit.py 实际生成交付物，stdout/stderr 分别保留在 ../scratch/audit.stdout、../scratch/audit.stderr；退出码 0。../scratch/receipt.json 记录脚本哈希、环境、输入前后哈希与复制一致性。独立契约检查 ../scratch/verify.py 退出码 0，原始输出见 ../scratch/verify.stdout 和 ../scratch/verify.stderr。检查 CSV 19 个唯一行、严格 JSON、所有 raw 哈希、汇总和输入未修改。未出现工具运行失败；业务异常未被检查器通过状态掩盖。

候选经验（仅本任务本地验证）：审计脱敏导出时分别保存来源哈希与发布哈希，按发布哈希判交付完整性，按记录生成派生关系。适用条件是存在明确的公开字节声明；不能推及缺少可信声明的来源认证。

接续：交付已完成；如需修复交接包，应先处理报告列出的不符、缺失和额外文件，再针对新对象重新核验。未登记后台任务，未启动额外实验。
