# 离线交接审计

共声明 18 个包/文件对：16 项通过、1 项哈希不符、1 项缺失；另有 1 项未声明文件。整体 handoff_ready 为 false。

| 目录 | 通过 | 不符 | 缺失 | 未声明 | 就绪 |
|---|---:|---:|---:|---:|---|
| handoff-a | 6 | 0 | 0 | 0 | 是 |
| handoff-b | 5 | 1 | 0 | 0 | 否 |
| handoff-c | 5 | 0 | 1 | 1 | 否 |

## 需要处理的交接项

- `handoff-b/final-tests.stderr`：mismatch。 实测 SHA-256 `d4a03401234ee9a70026284e17f3ca0c1a96533e97db8e1ae8a3ad7ff4ab0416`；应为 `fce44eea8a1322b604cbad38cc3a0ea2f9fd7c3ae964a4b95d89556b21aacf43`。
- `handoff-c/ledger-green.stderr`：missing。
- `handoff-c/local-note.txt`：unlisted。

## 范围和证据

审计在本工作区的 `scratch/public-copy/` 副本上离线执行。`audit.csv` 保留全部 19 项；`result.json` 记录每个原始 raw 文件的实测 SHA-256。公开版本的 `public_sha256` 是交付完整性的比较基准，`original_sha256` 仅表示原始来源溯源。共有 9 个脱敏派生文件匹配公开版本；其原始哈希不同不构成本次完整性失败。

这些是历史项目输入与受控传输变体，本审计不声称历史正式发布受损。未执行源文件中的命令，也未复跑历史测试；字节完整性通过不等于内容、软件行为或实时发布验收通过。未确认差异成因，也未独立认证声明的真实性或未提供的原始字节。

后续应针对公开声明恢复不符与缺失文件，并确认未声明文件的去留，再重新核验；本次保留所有异常，不修改输入或擅自修复交接包。

本次采用已有 context-support 经验中“证据绑定实际对象和条件”的原则；发票与缓存的具体根因不适用于本任务。
