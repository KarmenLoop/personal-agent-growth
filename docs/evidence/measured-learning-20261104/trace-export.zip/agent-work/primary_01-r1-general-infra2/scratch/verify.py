import csv,json,hashlib
from pathlib import Path
from collections import Counter
root=Path.cwd(); raw=root/'input/raw'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def strict(p):
    def reject(x): raise ValueError(x)
    return json.loads(p.read_text(),parse_constant=reject)
r=strict(root/'output/result.json'); rec=strict(raw/'publication-record.json')
with (root/'output/audit.csv').open(newline='') as f:
    reader=csv.DictReader(f); fields=reader.fieldnames; rows=list(reader)
assert fields=='bundle,path,status,observed_bytes,observed_sha256,declared_public_sha256,original_sha256,publication_relation'.split(',')
expected={(b,e['path']):e for b in rec['bundles'] for e in rec['files']}
actual={(p.parent.name,p.name) for p in (raw/'bundles').rglob('*') if p.is_file()}
assert len(rows)==len(expected.keys()|actual)==19
assert len({(x['bundle'],x['path']) for x in rows})==len(rows)
for x in rows:
    key=x['bundle'],x['path']; p=raw/'bundles'/x['bundle']/x['path']; e=expected.get(key)
    if p.is_file():
        assert x['observed_sha256']==h(p) and int(x['observed_bytes'])==len(p.read_bytes())
    else: assert x['observed_sha256']==x['observed_bytes']==''
    if e:
        assert x['declared_public_sha256']==e['public_sha256'] and x['original_sha256']==e['original_sha256']
        relation='unchanged' if e['original_sha256']==e['public_sha256'] else 'redacted_derivative' if e['path_redacted'] else 'undocumented_difference'
        assert x['publication_relation']==relation
        assert x['status']==('missing' if not p.exists() else 'verified' if h(p)==e['public_sha256'] else 'mismatch')
    else:
        assert x['status']=='unlisted' and x['publication_relation']=='unknown'
        assert x['declared_public_sha256']==x['original_sha256']==''
c=Counter(x['status'] for x in rows)
assert r['schema']==1 and r['task_id']=='primary_01' and r['data_kind']=='historical_inputs_with_controlled_integrity_variants'
assert r['source_sha256']=={p.relative_to(root/'input').as_posix():h(p) for p in raw.rglob('*') if p.is_file()}
assert r['summary']==dict(declared_files=18,verified_files=16,mismatched_files=1,missing_files=1,unlisted_files=1,verified_redacted_derivatives=9,handoff_ready=False)
before=json.loads((root/'scratch/receipt.json').read_text())['input_sha256_before']
assert before=={p.relative_to(root/'input').as_posix():h(p) for p in (root/'input').rglob('*') if p.is_file()}
assert (root/'output/report.md').stat().st_size>0
print('PASS: CSV 19 unique rows; all actual input bytes and declared relations checked; strict JSON, summary and complete source map checked; input unchanged.')
