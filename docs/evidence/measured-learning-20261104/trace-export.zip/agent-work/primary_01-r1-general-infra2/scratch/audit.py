import csv, hashlib, json, shutil, sys, platform
from pathlib import Path
from collections import Counter

root=Path.cwd()
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(base):
    return {p.relative_to(base).as_posix():digest(p) for p in sorted(base.rglob('*')) if p.is_file()}
source_before=inventory(root/'input')
copy=root/'scratch/public-copy'
shutil.copytree(root/'input',copy)
assert inventory(copy)==source_before
raw=copy/'raw'
record=json.loads((raw/'publication-record.json').read_text())
columns=['bundle','path','status','observed_bytes','observed_sha256','declared_public_sha256','original_sha256','publication_relation']
rows=[]
for bundle in record['bundles']:
    base=raw/'bundles'/bundle
    declared=set()
    for entry in record['files']:
        path=entry['path']; declared.add(path)
        original=entry['original_sha256']; public=entry['public_sha256']
        relation='unchanged' if original==public else ('redacted_derivative' if entry.get('path_redacted') else 'undocumented_difference')
        p=base/path
        observed=digest(p) if p.is_file() else ''
        status=('verified' if observed==public else 'mismatch') if observed else 'missing'
        rows.append(dict(zip(columns,[bundle,path,status,p.stat().st_size if observed else '',observed,public,original,relation])))
    for p in sorted(base.rglob('*')):
        if p.is_file() and p.relative_to(base).as_posix() not in declared:
            rows.append(dict(zip(columns,[bundle,p.relative_to(base).as_posix(),'unlisted',p.stat().st_size,digest(p),'','','unknown'])))
counts=Counter(r['status'] for r in rows)
summary={'declared_files':len(record['bundles'])*len(record['files']), 'verified_files':counts['verified'],'mismatched_files':counts['mismatch'],'missing_files':counts['missing'],'unlisted_files':counts['unlisted'],'verified_redacted_derivatives':sum(r['status']=='verified' and r['publication_relation']=='redacted_derivative' for r in rows),'handoff_ready':counts['verified']==len(record['bundles'])*len(record['files']) and counts['unlisted']==0}
result={'schema':1,'task_id':'primary_01','data_kind':'historical_inputs_with_controlled_integrity_variants','source_sha256':{'raw/'+k:v for k,v in inventory(raw).items()},'summary':summary}
out=root/'output'
with (out/'audit.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader();writer.writerows(rows)
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
lines=['# 离线交接审计','',f"共声明 {summary['declared_files']} 个包/文件对：{counts['verified']} 项通过、{counts['mismatch']} 项哈希不符、{counts['missing']} 项缺失；另有 {counts['unlisted']} 项未声明文件。整体 handoff_ready 为 {str(summary['handoff_ready']).lower()}。",'','| 目录 | 通过 | 不符 | 缺失 | 未声明 | 就绪 |','|---|---:|---:|---:|---:|---|']
for bundle in record['bundles']:
    c=Counter(r['status'] for r in rows if r['bundle']==bundle)
    ready=c['verified']==len(record['files']) and c['unlisted']==0
    lines.append(f"| {bundle} | {c['verified']} | {c['mismatch']} | {c['missing']} | {c['unlisted']} | {'是' if ready else '否'} |")
lines+=['','## 需要处理的交接项','']
for r in rows:
    if r['status']!='verified':
        lines.append(f"- `{r['bundle']}/{r['path']}`：{r['status']}。"+(f" 实测 SHA-256 `{r['observed_sha256']}`；应为 `{r['declared_public_sha256']}`。" if r['status']=='mismatch' else ''))
lines+=['','## 范围和证据','',f"审计在本工作区的 `scratch/public-copy/` 副本上离线执行。`audit.csv` 保留全部 {len(rows)} 项；`result.json` 记录每个原始 raw 文件的实测 SHA-256。公开版本的 `public_sha256` 是交付完整性的比较基准，`original_sha256` 仅表示原始来源溯源。共有 {summary['verified_redacted_derivatives']} 个脱敏派生文件匹配公开版本；其原始哈希不同不构成本次完整性失败。",'', '这些是历史项目输入与受控传输变体，本审计不声称历史正式发布受损。未执行源文件中的命令，也未复跑历史测试；字节完整性通过不等于内容、软件行为或实时发布验收通过。未确认差异成因，也未独立认证声明的真实性或未提供的原始字节。', '', '后续应针对公开声明恢复不符与缺失文件，并确认未声明文件的去留，再重新核验；本次保留所有异常，不修改输入或擅自修复交接包。','', '本次采用已有 context-support 经验中“证据绑定实际对象和条件”的原则；发票与缓存的具体根因不适用于本任务。']
(out/'report.md').write_text('\n'.join(lines)+'\n')
assert inventory(root/'input')==source_before
receipt={'python':sys.version,'platform':platform.platform(),'script_sha256':digest(Path(__file__)),'input_sha256_before':source_before,'input_sha256_after':inventory(root/'input'),'input_unchanged':True,'copy_matches_input':True,'stage':'audit generated','summary':summary}
(root/'scratch/receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(summary,indent=2))
print('\n'.join(f"{r['bundle']}/{r['path']}: {r['status']}" for r in rows if r['status']!='verified'))
