# primary_01 执行前记录
目标：完成三个交接目录的逐文件公开字节审计，交付 CSV、严格 JSON 与短报告。
范围：input/raw 的历史输入及受控传输变体；不执行原始文件中的任何命令，不判断当前发布或历史测试是否通过。
决定性未知：每个实际交付文件是否匹配 publication-record.json 的 public_sha256，以及是否存在缺失/未列出文件。
检查：复制 input 到 scratch/public-copy，在副本上逐字节计算 SHA-256，并核对原输入与副本哈希及交付契约。
预测：只有所有声明文件匹配且没有额外文件时 handoff_ready 才为 true；不预设各包结果。
失败后继：若声明无法解析或文件无法读取，保留错误，不把未检查对象记为 verified。
经验：已读取 learning/source-input.md、learning/experience/mechanism/context-support/experience.md 及其两个证据文件。采用“结论绑定实际对象/上下文”的机制；拒绝迁移 invoice/cache 领域诊断。当前无 context/node/policy 文件（已枚举 learning 文件）。
