import csv,json,hashlib
from pathlib import Path
from decimal import Decimal
p=Path('output')
with (p/'audit.csv').open() as f:a=list(csv.DictReader(f))
with (p/'station-days.csv').open() as f:s=list(csv.DictReader(f))
r=json.loads((p/'result.json').read_text(),parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
expected=['accepted']*7+['superseded','accepted','missing_value','rejected_quality','accepted','accepted','superseded','rejected_quality','accepted','accepted','missing_value']
assert [x['disposition'] for x in a]==expected
assert len(a)==18 and len(s)==9
assert all((x['calibrated_c']!='')==(x['disposition']=='accepted') for x in a)
assert [x['mean_c'] for x in s]==['0.150000','0.200000','0.050000','0.300000','0.300000','0.100000','0.200000','0.300000','']
assert [int(x['accepted_replicates']) for x in s]==[2,3,2,1,1,1,1,1,0]
assert [d['index_c'] for d in r['summary']['days']]==[0.133333,0.233333,None]
assert r['summary']['accepted_rows']==12 and r['summary']['source_rows']==18
for name,h in r['source_sha256'].items(): assert hashlib.sha256((Path('input')/name).read_bytes()).hexdigest()==h
assert set(r['source_sha256'])=={'raw/measurements.csv','raw/settings.json'}
assert r['schema']==1 and r['task_id']=='primary_02' and r['data_kind']=='derived_fixture_not_actual_measurements'
print('PASS: all 18 row dispositions, 9 station-day means/counts, 3 indices, strict JSON and both raw hashes.')
