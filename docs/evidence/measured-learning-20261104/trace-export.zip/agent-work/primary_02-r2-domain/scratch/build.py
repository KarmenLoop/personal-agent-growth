import csv, json, hashlib
from pathlib import Path
from fractions import Fraction
from decimal import Decimal, localcontext, ROUND_HALF_EVEN
from collections import Counter
root=Path('.')
raw=root/'input/raw'
out=root/'output'
settings=json.loads((raw/'settings.json').read_text())
with (raw/'measurements.csv').open(newline='') as f:
    rows=list(csv.DictReader(f))
def key(r): return (r['date'],r['station'],r['replicate'])
latest={}
for r in rows:
    k=key(r); latest[k]=max(latest.get(k,-1),int(r['revision']))
def fmt(v):
    with localcontext() as ctx:
        ctx.prec=60
        return format((Decimal(v.numerator)/Decimal(v.denominator)).quantize(Decimal('.000001'),rounding=ROUND_HALF_EVEN),'f')
def num(v): return float(fmt(v))
values={}
audit=[]
for r in rows:
    value=None
    if int(r['revision'])<latest[key(r)]: disposition='superseded'
    elif r['quality']!='ok': disposition='rejected_quality'
    elif any(r[x] in ('','NA') for x in ('reading_c','bias_c')): disposition='missing_value'
    else:
        disposition='accepted'
        value=Fraction(r['reading_c'])-Fraction(r['bias_c'])
        values.setdefault((r['date'],r['station']),[]).append(value)
    # Exact finite decimal calibration, without imposing rounding on audit values.
    if value is not None:
        with localcontext() as ctx:
            ctx.prec=60
            calibrated=format(Decimal(value.numerator)/Decimal(value.denominator),'f')
    else: calibrated=''
    audit.append(dict(row_id=r['row_id'],disposition=disposition,calibrated_c=calibrated))
def writecsv(name,columns,records):
    with (out/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns); w.writeheader(); w.writerows(records)
writecsv('audit.csv',['row_id','disposition','calibrated_c'],audit)
stationdays=[]; days=[]; missing={}
for date in settings['dates']:
    means=[]; absent=[]
    for station in settings['stations']:
        vals=values.get((date,station),[])
        mean=sum(vals,Fraction())/len(vals) if vals else None
        stationdays.append(dict(date=date,station=station,accepted_replicates=len(vals),mean_c=fmt(mean) if mean is not None else ''))
        if mean is None: absent.append(station)
        else: means.append(mean)
    complete=not absent
    if absent: missing[date]=absent
    days.append(dict(date=date,expected_stations=len(settings['stations']),present_stations=len(means),complete=complete,index_c=num(sum(means,Fraction())/len(means)) if complete else None))
writecsv('station-days.csv',['date','station','accepted_replicates','mean_c'],stationdays)
hashes={'raw/'+str(p.relative_to(raw)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(raw.rglob('*')) if p.is_file()}
result=dict(schema=1,task_id='primary_02',data_kind='derived_fixture_not_actual_measurements',source_sha256=hashes,summary=dict(source_rows=len(rows),accepted_rows=sum(a['disposition']=='accepted' for a in audit),days=days))
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
(out/'report.md').write_text('''# 站点指数交接

本包是离线分析用派生夹具，**不是实际环境观测**，单位为摄氏度距平。

- `audit.csv`：逐行保留全部 18 条输入的处置，仅 12 条 accepted 带校准值。
- `station-days.csv`：覆盖配置的 3 天 × 3 站，给出有效重复数及站日均值；缺失均值留空。
- `result.json`：严格 JSON，包含来源 SHA-256、完整性及站点等权日指数。

2026-01-01 日指数为 0.133333；2026-01-02 为 0.233333。
2026-01-03 仅 2/3 站有值：Cedar 当前行缺少 reading，故其站日均值为空、日指数为 null。未插补，也未对剩余站点重新加权。

先按日期/站点/重复身份选择最高修订，再检查质量与缺失。b7 已被拒绝的高修订 b8 取代，不回退；01-02 Cedar 仅 b6 贡献。计算使用精确有理数，均值及指数最终四舍六入五成双至六位小数，指数使用未舍入站日均值。JSON 数字可能省略末尾零。

已检查全部行处置、配置覆盖、来源哈希和严格 JSON；输入未改动。无处理失败；未解决项是 01-03 Cedar 的缺失输入，只有获得新的合格当前数据才能计算该日日指数。此结果不证明源领域的缓存因果模型适用于本任务。
''')
print(json.dumps(dict(dispositions=Counter(a['disposition'] for a in audit),days=days),ensure_ascii=False,indent=2))
