# 执行前记录
目标：生成逐行审计、9 个配置站日、严格 JSON 日指数及中文交接。输入只读，不开展额外实验。
验收：最高 revision 先确定当前行，再判 quality 与缺失；站内重复均值、站间等权；不完整日为 null；绑定全部 raw 哈希。
经验来源：learning/experience/mechanism/context-support/experience.md 与 context-support-model/experience.md（后者只是因果假说）。
映射：source scope → 日期/站点/重复身份及 revision；scope → observation 对应修订状态约束哪些行可支持当前值；observation → conclusion 对应有效校准行支持站日及日指数。
必要条件：证据确实受身份与修订上下文约束。最可能破坏类比的缺失条件是“新路径意味着旧结论失效”并不普遍成立；本任务必须靠明文最高修订规则，而不能靠发票缓存经验推断。
决定性检查：输入 b7/b8 同身份、revision 1/2，b8 reject；task.md 明确被拒绝的最新行仍为当前行，故 b7 superseded、b8 rejected_quality。
可观察预测：Cedar 在 01-02 仅 b6 贡献，mean=0.1；若允许回退或存在更高的有效当前行，此预测失效。实际输入无此证据。
决定：适配“证据绑定上下文”的窄原则，拒绝迁移发票缓存根因。源经验范围不变；目标验收另由任务契约与产物检查支持。
下一步：一次执行本地转换并检查全部输出。失败保留；成本由宿主记录，不估计。
