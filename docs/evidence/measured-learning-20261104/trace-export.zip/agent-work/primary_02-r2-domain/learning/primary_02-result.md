# primary_02：经验应用与交付记录

来源：本地 context-support 与 context-support-model 两份 experience.md；前者为来源任务支持经验，后者仍为因果假说。执行前映射、必要条件、预测与证伪条件见 ../scratch/prepare.md。

结论：适配证据绑定具体身份与修订的窄原则；拒绝将发票缓存故障解释直接搬入站点导入。决定性目标证据为 input/task.md 的最高修订规则及 input/raw/measurements.csv 的 b7/b8：旧行不因新行被拒绝而恢复有效。预测得到输入和逐行产物支持，不能据此声称跨领域因果模型得到普适验证。

实际动作：../scratch/build.py 生成全部四份交付文件；../scratch/check.py 核验全部处置、站日均值/计数、日指数及哈希。原始核验输出见 ../scratch/verification.txt；执行退出码为 0。最终 18 行中 12 accepted、2 superseded、2 rejected_quality、2 missing_value；9 个站日；01-03 缺 Cedar，指数 null。

无执行失败。未知：缺失输入的真实值、现实环境解释、迁移相较不用经验的收益均未验证。没有新增实验、没有估算原生用量或成本。保留源经验原始范围；本次仅支持该固定派生夹具的局部使用。后续若输入改变，须重新绑定哈希并计算，不能沿用本回执。
