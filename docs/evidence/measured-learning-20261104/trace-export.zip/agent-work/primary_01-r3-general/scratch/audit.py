import csv, hashlib, json
from pathlib import Path
raw=Path('input/raw')
out=Path('output')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
baseline={p.relative_to(Path('input')).as_posix():sha(p) for p in sorted(raw.rglob('*')) if p.is_file()}
record=json.loads((raw/'publication-record.json').read_text())
fields=['bundle','path','status','observed_bytes','observed_sha256','declared_public_sha256','original_sha256','publication_relation']
rows=[]
for bundle in record['bundles']:
    root=raw/'bundles'/bundle
    expected={f['path']:f for f in record['files']}
    for path,f in expected.items():
        p=root/path
        relation='unchanged' if f['original_sha256']==f['public_sha256'] else ('redacted_derivative' if f.get('path_redacted') else 'undocumented_difference')
        observed=sha(p) if p.is_file() else ''
        rows.append(dict(zip(fields,[bundle,path,('verified' if observed==f['public_sha256'] else 'mismatch') if observed else 'missing',p.stat().st_size if observed else '',observed,f['public_sha256'],f['original_sha256'],relation])))
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.relative_to(root).as_posix() not in expected:
            rows.append(dict(zip(fields,[bundle,p.relative_to(root).as_posix(),'unlisted',p.stat().st_size,sha(p),'','','unknown'])))
with (out/'audit.csv').open('w',newline='') as file:
    writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader();writer.writerows(rows)
summary={'declared_files':sum(r['status']!='unlisted' for r in rows),'verified_files':sum(r['status']=='verified' for r in rows),'mismatched_files':sum(r['status']=='mismatch' for r in rows),'missing_files':sum(r['status']=='missing' for r in rows),'unlisted_files':sum(r['status']=='unlisted' for r in rows),'verified_redacted_derivatives':sum(r['status']=='verified' and r['publication_relation']=='redacted_derivative' for r in rows)}
summary['handoff_ready']=summary['verified_files']==summary['declared_files'] and summary['unlisted_files']==0
result={'schema':1,'task_id':'primary_01','data_kind':'historical_inputs_with_controlled_integrity_variants','source_sha256':baseline,'summary':summary}
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
lines=['# 离线交接审计','',f"共声明 {summary['declared_files']} 个目录/文件对：{summary['verified_files']} 个验证通过、{summary['mismatched_files']} 个哈希不符、{summary['missing_files']} 个缺失；另有 {summary['unlisted_files']} 个未列出文件。整体 handoff_ready 为 {str(summary['handoff_ready']).lower()}。",'','| 目录 | 通过 | 不符 | 缺失 | 未列出 | 可交接 |','| --- | ---: | ---: | ---: | ---: | --- |']
for b in record['bundles']:
    counts={s:sum(r['bundle']==b and r['status']==s for r in rows) for s in ['verified','mismatch','missing','unlisted']}
    ready=counts['verified']==len(record['files']) and counts['unlisted']==0
    lines.append(f"| {b} | {counts['verified']} | {counts['mismatch']} | {counts['missing']} | {counts['unlisted']} | {'是' if ready else '否'} |")
lines+=['','待处理项：','']
for r in rows:
    if r['status']!='verified': lines.append(f"- `{r['bundle']}/{r['path']}`：{r['status']}。" )
lines+=['','范围与证据：以 `input/raw/publication-record.json` 声明为准，对三个目录逐一读取文件字节、计算 SHA-256 和字节数，递归枚举未列出文件。`audit.csv` 保留每对文件的观察值与两类声明哈希；`result.json` 记录全部 raw 文件的实际哈希。', '',f"其中 {summary['verified_redacted_derivatives']} 个通过项是声明过路径脱敏的衍生文件。原始来源哈希只用于溯源，公开文件以 public_sha256 验证；二者不同不自动构成交付损坏。publication_relation 描述声明的来源关系，即使交付字节不符也保留该关系。",'', '这些是历史输入和受控传输变体；本审计不判定历史官方发布受损，也未运行历史测试、核验原始未脱敏文件或证明内容与产品可用性。异常原因及正确替换字节未独立确认；应依据可信公开副本恢复不符/缺失文件，并确认或移除未列出文件后重新审计。原始输入保持不变。','']
(out/'report.md').write_text('\n'.join(lines))
assert baseline=={p.relative_to(Path('input')).as_posix():sha(p) for p in sorted(raw.rglob('*')) if p.is_file()}
print(json.dumps(summary,indent=2))
print('\n'.join(f"{r['bundle']}/{r['path']}: {r['status']}" for r in rows if r['status']!='verified'))
