# 离线交接审计

共声明 18 个目录/文件对：16 个验证通过、1 个哈希不符、1 个缺失；另有 1 个未列出文件。整体 handoff_ready 为 false。

| 目录 | 通过 | 不符 | 缺失 | 未列出 | 可交接 |
| --- | ---: | ---: | ---: | ---: | --- |
| handoff-a | 6 | 0 | 0 | 0 | 是 |
| handoff-b | 5 | 1 | 0 | 0 | 否 |
| handoff-c | 5 | 0 | 1 | 1 | 否 |

待处理项：

- `handoff-b/final-tests.stderr`：mismatch。
- `handoff-c/ledger-green.stderr`：missing。
- `handoff-c/local-note.txt`：unlisted。

范围与证据：以 `input/raw/publication-record.json` 声明为准，对三个目录逐一读取文件字节、计算 SHA-256 和字节数，递归枚举未列出文件。`audit.csv` 保留每对文件的观察值与两类声明哈希；`result.json` 记录全部 raw 文件的实际哈希。

其中 9 个通过项是声明过路径脱敏的衍生文件。原始来源哈希只用于溯源，公开文件以 public_sha256 验证；二者不同不自动构成交付损坏。publication_relation 描述声明的来源关系，即使交付字节不符也保留该关系。

这些是历史输入和受控传输变体；本审计不判定历史官方发布受损，也未运行历史测试、核验原始未脱敏文件或证明内容与产品可用性。异常原因及正确替换字节未独立确认；应依据可信公开副本恢复不符/缺失文件，并确认或移除未列出文件后重新审计。原始输入保持不变。
