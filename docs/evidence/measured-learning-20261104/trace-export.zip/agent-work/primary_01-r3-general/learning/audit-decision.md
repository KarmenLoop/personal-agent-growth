# primary_01 决策与完成记录

目标：完成三个公开交接目录的字节完整性审计；验收依据为任务规定的 CSV、JSON 和报告契约。

关键未知：公开版本与原始来源不同是否构成异常？判别检查：读取 publication-record.json 的 public_sha256 与 path_redacted，并对实际公开字节计算 SHA-256；不以 original_sha256 替代交付校验值。若匹配则通过，否则保留 mismatch；缺失和额外文件分别记录。

经验读取：learning/source-input.md、learning/experience/mechanism/context-support/experience.md、learning/evidence/response-4.md。经验正文 SHA-256：4f84752132ab1f6a4138b77628601d66a02bb13d6fb7941394439b246a15dd69

采用范围：仅采用“观察绑定具体输入、版本与路径”的原则，每个目录单独核验。拒绝迁移发票计算或缓存根因；它们与本任务无证据关联。经验引用的 receipt-4.json 在本学习根未提供，未将其当作独立核实证据。

本次结果：18 个声明项，16 个通过、1 个不符、1 个缺失，另有 1 个未列出文件。9 个通过项为声明的脱敏衍生。失败均保留在 output/audit.csv，不修改输入、不修复变体。整体不可交接。

产物核验：重新读取 CSV/JSON，检查声明覆盖、唯一性、缺失/未列出空字段和全部实际哈希；与初始 raw 哈希映射一致。脚本正常退出。范围仅是此工作副本的离线字节审计，内容可用性和真实发布状态未知。未做额外实验，也不声称迁移收益。
