from pathlib import Path
import hashlib, json, csv, shutil, sys
from collections import Counter

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
original=Path('input')
before={p.relative_to(original).as_posix():sha(p) for p in original.rglob('*') if p.is_file()}
work=Path('scratch/public-copy')
shutil.copytree(original, work)
raw=work/'raw'
record=json.loads((raw/'publication-record.json').read_text())
fields='bundle,path,status,observed_bytes,observed_sha256,declared_public_sha256,original_sha256,publication_relation'.split(',')
rows=[]
for bundle in record['bundles']:
    root=raw/'bundles'/bundle
    declared={e['path']:e for e in record['files']}
    for name,e in declared.items():
        p=root/name
        relation=('unchanged' if e['original_sha256']==e['public_sha256'] else 'redacted_derivative' if e.get('path_redacted') else 'undocumented_difference')
        present=p.is_file()
        observed=sha(p) if present else ''
        rows.append(dict(zip(fields,[bundle,name,('verified' if observed==e['public_sha256'] else 'mismatch') if present else 'missing',p.stat().st_size if present else '',observed,e['public_sha256'],e['original_sha256'],relation])))
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.relative_to(root).as_posix() not in declared:
            rows.append(dict(zip(fields,[bundle,p.relative_to(root).as_posix(),'unlisted',p.stat().st_size,sha(p),'','','unknown'])))
with Path('output/audit.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
c=Counter(r['status'] for r in rows)
summary=dict(declared_files=len(record['bundles'])*len(record['files']),verified_files=c['verified'],mismatched_files=c['mismatch'],missing_files=c['missing'],unlisted_files=c['unlisted'],verified_redacted_derivatives=sum(r['status']=='verified' and r['publication_relation']=='redacted_derivative' for r in rows),handoff_ready=not(c['mismatch'] or c['missing'] or c['unlisted']))
sources={p.relative_to(work).as_posix():sha(p) for p in sorted(raw.rglob('*')) if p.is_file()}
result=dict(schema=1,task_id='primary_01',data_kind='historical_inputs_with_controlled_integrity_variants',source_sha256=sources,summary=summary)
Path('output/result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
lines=['# 离线交接审计','',f"共声明 {summary['declared_files']} 项：验证通过 {c['verified']}，哈希不符 {c['mismatch']}，缺失 {c['missing']}；另有未列出文件 {c['unlisted']}。整体 handoff_ready = {str(summary['handoff_ready']).lower()}。",'','| 包 | 通过 | 不符 | 缺失 | 未列出 | 就绪 |','|---|---:|---:|---:|---:|---|']
for b in record['bundles']:
    counts=Counter(r['status'] for r in rows if r['bundle']==b)
    ready=not any(counts[x] for x in ('mismatch','missing','unlisted'))
    lines.append(f"| {b} | {counts['verified']} | {counts['mismatch']} | {counts['missing']} | {counts['unlisted']} | {'是' if ready else '否'} |")
lines+=['','## 待处理项','']
for r in rows:
    if r['status']!='verified':
        lines.append(f"- `{r['bundle']}/{r['path']}`：{r['status']}。"+(f"公开声明 `{r['declared_public_sha256']}`，实测 `{r['observed_sha256']}`。" if r['status']=='mismatch' else ''))
lines+=['','缺失项需补齐匹配公开哈希的文件；差异项需从可信公开副本恢复；未列出项需移除或经正式声明后重新审计。本次仅报告，未修改输入或修复交接包。','','## 范围与证据','',f"验收使用 publication-record.json 的 public_sha256。{summary['verified_redacted_derivatives']} 个已通过条目为声明的路径脱敏衍生物；其 original_sha256 仅保留来源溯源，不作为交付字节验收值。publication_relation 描述声明的原始/公开关系，不代表实际字节通过。",'',f"audit.csv 覆盖全部声明及未列出项；result.json 含全部 {len(sources)} 个实际 raw 文件的 SHA-256，缺失文件没有虚构哈希。对 scratch/public-copy 的输入副本执行核验，输入前后哈希检查一致。",'','这是历史材料及受控传输变体的静态完整性审计，不代表历史官方发布损坏，不验证内容真实性、原始未脱敏文件或历史测试是否能在当前环境运行。差异形成原因未判定；未开展额外实验。','','## 经验适配','', '采用 learning 中 context-support 的证据归属原则：调用上下文→具体包/路径与版本，运行观测→实际字节哈希，局部诊断→文件状态；上下文限定观测，观测支持结论。关键前提是存在明确公开基准，本次声明满足；源发票及缓存诊断不迁移。预测“脱敏文件可匹配公开值而不匹配原始值”得到本次条目支持；任何不匹配公开值的条目均按 mismatch 处理，不能以脱敏为借口豁免。源经验的有效范围保留，当前只证明本次审计的适用性，不证明一般迁移收益。执行前映射见 ../scratch/preparation.md；脚本和回执见 ../scratch/audit.py、../scratch/audit-receipt.json。']
Path('output/report.md').write_text('\n'.join(lines)+'\n')
after={p.relative_to(original).as_posix():sha(p) for p in original.rglob('*') if p.is_file()}
assert before==after
assert sources=={p.relative_to(original).as_posix():sha(p) for p in (original/'raw').rglob('*') if p.is_file()}
loaded=list(csv.DictReader(Path('output/audit.csv').open()))
assert len(loaded)==summary['declared_files']+summary['unlisted_files']
assert len({(r['bundle'],r['path']) for r in loaded})==len(loaded)
assert json.loads(Path('output/result.json').read_text())==result
receipt=dict(stage='copy audit and deliverable readback complete',python=sys.version,script_sha256=sha(Path('scratch/audit.py')),input_unchanged=before==after,input_sha256=before,output_sha256={p.as_posix():sha(p) for p in sorted(Path('output').iterdir())},summary=summary,rows=len(rows))
Path('scratch/audit-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(summary=summary,rows=len(rows),input_unchanged=True),indent=2))
