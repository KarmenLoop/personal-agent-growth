# primary_01 执行前记录
目标：审计 input/raw/bundles 三个包，生成完整 CSV、严格 JSON 与可交接报告；不修复或改变输入，不开展额外实验。
验收：每个声明 bundle/file 及实际额外文件均有一行；按 public_sha256 判断；记录所有 raw 文件哈希。
经验读取：learning/source-input.md、source-model.md、experience/mechanism/context-support/experience.md、experience/mechanism/context-support-model/experience.md 及引用的 evidence。
候选映射：源 scope（调用路径与输入）→目标 bundle/path 与公开/原始版本；源 observation（实际运行结果）→目标实际字节和哈希；源 conclusion（特定缺陷判断）→目标逐文件完整性及包就绪状态。
方向关系：上下文限定观测对象，观测支持局部结论，逐项结论共同决定就绪状态。源经验中一个入口的失败不撤销另一入口已有证据；目标中一个包失败不撤销另一个包的验证。
必要条件：公开基准和原始来源可区分，且观测可绑定实际交付文件。最可能破坏类比的缺失条件：没有明确版本基准，导致来源差异被误当交付损坏；publication-record.json 已明确给出 public_sha256、original_sha256、path_redacted，满足该条件。
预测：按 public 哈希验证的脱敏文件，即使不等于 original 哈希，也可 verified；不同交付副本应逐项测量。
反证：如果现有字节不匹配 public 哈希，则不能由脱敏标记推断 verified；如果另有独立当前字节证据，应以其为准而非套用旧上下文。
选择：适配采用证据归属原则，不迁移发票计算或缓存缺陷诊断；目标结果待实际审计，不预设失败位置。
环境：离线本地，使用用户指定 Python -B；脚本及原始输出保存在 scratch/。
