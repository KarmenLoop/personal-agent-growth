# 离线交接审计

共声明 18 项：验证通过 16，哈希不符 1，缺失 1；另有未列出文件 1。整体 handoff_ready = false。

| 包 | 通过 | 不符 | 缺失 | 未列出 | 就绪 |
|---|---:|---:|---:|---:|---|
| handoff-a | 6 | 0 | 0 | 0 | 是 |
| handoff-b | 5 | 1 | 0 | 0 | 否 |
| handoff-c | 5 | 0 | 1 | 1 | 否 |

## 待处理项

- `handoff-b/final-tests.stderr`：mismatch。公开声明 `fce44eea8a1322b604cbad38cc3a0ea2f9fd7c3ae964a4b95d89556b21aacf43`，实测 `d4a03401234ee9a70026284e17f3ca0c1a96533e97db8e1ae8a3ad7ff4ab0416`。
- `handoff-c/ledger-green.stderr`：missing。
- `handoff-c/local-note.txt`：unlisted。

缺失项需补齐匹配公开哈希的文件；差异项需从可信公开副本恢复；未列出项需移除或经正式声明后重新审计。本次仅报告，未修改输入或修复交接包。

## 范围与证据

验收使用 publication-record.json 的 public_sha256。9 个已通过条目为声明的路径脱敏衍生物；其 original_sha256 仅保留来源溯源，不作为交付字节验收值。publication_relation 描述声明的原始/公开关系，不代表实际字节通过。

audit.csv 覆盖全部声明及未列出项；result.json 含全部 19 个实际 raw 文件的 SHA-256，缺失文件没有虚构哈希。对 scratch/public-copy 的输入副本执行核验，输入前后哈希检查一致。

这是历史材料及受控传输变体的静态完整性审计，不代表历史官方发布损坏，不验证内容真实性、原始未脱敏文件或历史测试是否能在当前环境运行。差异形成原因未判定；未开展额外实验。

## 经验适配

采用 learning 中 context-support 的证据归属原则：调用上下文→具体包/路径与版本，运行观测→实际字节哈希，局部诊断→文件状态；上下文限定观测，观测支持结论。关键前提是存在明确公开基准，本次声明满足；源发票及缓存诊断不迁移。预测“脱敏文件可匹配公开值而不匹配原始值”得到本次条目支持；任何不匹配公开值的条目均按 mismatch 处理，不能以脱敏为借口豁免。源经验的有效范围保留，当前只证明本次审计的适用性，不证明一般迁移收益。执行前映射见 ../scratch/preparation.md；脚本和回执见 ../scratch/audit.py、../scratch/audit-receipt.json。
