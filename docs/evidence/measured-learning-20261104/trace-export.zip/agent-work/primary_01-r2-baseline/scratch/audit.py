from pathlib import Path
import hashlib, json, csv, shutil, sys, platform
root = Path.cwd()
source = root/'input'
copy = root/'scratch/public'
out = root/'output'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(base):
    return {p.relative_to(base).as_posix():sha(p) for p in sorted((base/'raw').rglob('*')) if p.is_file()}
before = snapshot(source)
task_before = sha(source/'task.md')
shutil.copytree(source, copy)
assert snapshot(copy) == before
record = json.loads((copy/'raw/publication-record.json').read_text())
rows = []
per_bundle = {}
for bundle in record['bundles']:
    base = copy/'raw/bundles'/bundle
    declared = {e['path'] for e in record['files']}
    for entry in record['files']:
        p = base/entry['path']
        original, public = entry['original_sha256'], entry['public_sha256']
        relation = ('unchanged' if original == public else
                    'redacted_derivative' if entry.get('path_redacted') else 'undocumented_difference')
        exists = p.is_file()
        observed = sha(p) if exists else ''
        rows.append(dict(bundle=bundle,path=entry['path'],status=('verified' if observed == public else 'mismatch') if exists else 'missing', observed_bytes=p.stat().st_size if exists else '',observed_sha256=observed,declared_public_sha256=public,original_sha256=original,publication_relation=relation))
    for p in sorted(base.rglob('*')):
        if p.is_file() and p.relative_to(base).as_posix() not in declared:
            rows.append(dict(bundle=bundle,path=p.relative_to(base).as_posix(),status='unlisted',observed_bytes=p.stat().st_size,observed_sha256=sha(p),declared_public_sha256='',original_sha256='',publication_relation='unknown'))
    br = [r for r in rows if r['bundle']==bundle]
    per_bundle[bundle] = {s:sum(r['status']==s for r in br) for s in ['verified','mismatch','missing','unlisted']}
summary = dict(declared_files=len(record['bundles'])*len(record['files']), verified_files=sum(r['status']=='verified' for r in rows),mismatched_files=sum(r['status']=='mismatch' for r in rows),missing_files=sum(r['status']=='missing' for r in rows),unlisted_files=sum(r['status']=='unlisted' for r in rows),verified_redacted_derivatives=sum(r['status']=='verified' and r['publication_relation']=='redacted_derivative' for r in rows),handoff_ready=all(r['status']=='verified' for r in rows))
fields = ['bundle','path','status','observed_bytes','observed_sha256','declared_public_sha256','original_sha256','publication_relation']
with (out/'audit.csv').open('w',newline='',encoding='utf-8') as f:
    writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader(); writer.writerows(rows)
result = dict(schema=1,task_id='primary_01',data_kind='historical_inputs_with_controlled_integrity_variants',source_sha256=before,summary=summary)
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
lines=['# 公开证据交接审计','',f"共声明 {summary['declared_files']} 项：通过 {summary['verified_files']}，错配 {summary['mismatched_files']}，缺失 {summary['missing_files']}；另有未列文件 {summary['unlisted_files']}。整体 handoff_ready = {str(summary['handoff_ready']).lower()}。",'', '| 目录 | 通过 | 错配 | 缺失 | 未列 |','|---|---:|---:|---:|---:|']
for b,c in per_bundle.items():
    lines.append(f"| {b} | {c['verified']} | {c['mismatch']} | {c['missing']} | {c['unlisted']} |")
lines += ['','## 待处理项','']
for r in rows:
    if r['status']!='verified':
        lines.append(f"- `{r['bundle']}/{r['path']}`：{r['status']}。" + ('需提供与公开声明一致的文件。' if r['status'] in ['mismatch','missing'] else '需明确是否应纳入声明，或从交接副本移除。'))
lines += ['','## 范围与证据','',f"`audit.csv` 给出逐项实际字节数、SHA-256、公开声明哈希及原始来源哈希；`result.json` 给出汇总与所有 raw 文件的实际哈希（路径相对 input/）。在 scratch/public 副本执行本地 SHA-256 核验，复制前后及执行后核对原输入未变。",'',f"通过项中 {summary['verified_redacted_derivatives']} 项为声明标注路径脱敏的衍生物；与原始来源哈希不同并不构成交付错配。publication_relation 仅描述声明中的来源关系，不证明脱敏内容正确或原始材料真实性。",'','本批输入是历史项目材料及受控完整性变体。异常仅绑定本次对应目录及文件，不意味着历史正式发布受损；日志中的失败内容是输入数据，未执行其命令，也未复跑历史测试。公开字节通过不代表历史产品验收通过。原始未脱敏字节未提供，无法独立核验其来源哈希。','', '既有 context-support 经验仅用于将判断绑定实际对象、版本与执行路径；未迁移发票领域根因。本次未修复或删除异常文件。交接前应处理上述异常，再按同一公开声明复核。']
(out/'report.md').write_text('\n'.join(lines)+'\n')
assert snapshot(source)==before and sha(source/'task.md')==task_before
receipt=dict(command='python3 -B scratch/audit.py',stage='audit and deliverable generation completed',python=sys.version,platform=platform.platform(),input_unchanged=True,task_unchanged=True,copied_raw_matches=True,output_sha256={p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file()},summary=summary,per_bundle=per_bundle)
(root/'scratch/receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
