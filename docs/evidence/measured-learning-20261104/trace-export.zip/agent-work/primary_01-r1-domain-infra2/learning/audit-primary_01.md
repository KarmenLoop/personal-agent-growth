# primary_01 局部应用记录
状态：交付完成；整批交接未就绪。未修改来源经验、skill 或 input。
实际读取：source-input.md、source-model.md、experience/mechanism/context-support/experience.md、experience/mechanism/context-support-model/experience.md。它们描述同一源任务；模型仍为假设，不能作为另一份独立证明。读取内容和目标声明保留在本次工具回执；执行前关系映射与条件检验见 ../scratch/plan.md。
行动：使用指定 Python -B 执行 ../scratch/audit.py，从 input 创建 scratch/public-copy；生成 ../output/audit.csv、../output/result.json、../output/report.md。实际执行输出见 ../scratch/audit-receipt.txt。交付检查命令为同一 Python -B scratch/validate.py，原始结果见 ../scratch/validation-receipt.txt；检查对象哈希绑定于该回执。
观察：18 个声明对，16 verified、1 mismatch、1 missing；另有 1 unlisted。9 个 redacted_derivative 实际匹配 public_sha256。这证明在本次输入中，将 original_sha256 直接用于交付核验会误判合法公开派生。handoff-a 全部匹配，不能抵消 handoff-b 的 final-tests.stderr 不匹配或 handoff-c 的缺失/额外项。
判断更新：保留并适配证据绑定上下文的原则；不迁移发票计算/缓存根因。关键条件已由发布记录的双哈希、path_redacted 与实际公开字节核验得到支持。当前结果支持此次具体应用，但没有进行方法效益因果实验、跨任务效果或成本比较。
失败与未知：交接异常完整保留于 CSV 和执行回执；没有修补输入。未提供原始源字节，来源哈希真实性未知；不推断历史正式发布损坏。原生 token、实收费用与推理成本未测量，不估计。无额外实验、网络或子 Agent。
后继条件：维护者恢复所需公开字节、处理未列出文件后，可按新副本再次审计；本次不代为更改声明。无后台或唤醒任务。
