---
{
  "id": "context-support-model",
  "type": "mechanism-experience",
  "source_task_id": "invoice-judgment-20261103",
  "domain": "invoice-debugging",
  "problem_structure": [
    "evidence-bound-claim",
    "multiple-entry-paths"
  ],
  "mechanisms": [
    "context-dependent-support"
  ],
  "required_conditions": {
    "evidence-bound-to-a-specific-context": true
  },
  "exceptions": [
    "A change in context does not automatically refute independently supported claims.",
    "Structural similarity alone does not prove a common cause or an effective intervention."
  ],
  "intervention": "Bind each observation and conclusion to the actual input, version and execution path; test the changed condition before extending or withdrawing the claim.",
  "explanation": "In the actual source task a new entry path demonstrated a cache defect while the original direct-call calculation defect remained valid. The source artifacts show the distinct inputs and actual results.",
  "validation": "hypothesis",
  "executor": "coordinator/source-modeler",
  "reviewer": null,
  "artifacts": [
    {
      "path": "evidence/response-4.md",
      "sha256": "90140a90bea97ff51d508f2cce951c2ce59e3e04efd2b602ea896c9e2a30083e"
    },
    {
      "path": "evidence/receipt-4.json",
      "sha256": "a1b0e4ee48eeff5f38c923f42094e930ed175911b0e1076650131bddb0e9676c"
    }
  ],
  "causal_model": {
    "variables": {
      "scope": "context",
      "observation": "evidence",
      "conclusion": "decision"
    },
    "relations": [
      {
        "from": "scope",
        "to": "observation",
        "relation": "conditions"
      },
      {
        "from": "observation",
        "to": "conclusion",
        "relation": "supports"
      }
    ],
    "predictions": [
      {
        "intervention": "Change a condition on which the observation depends",
        "expected": "Check whether support for the dependent conclusion still applies",
        "falsifier": "The conclusion has independent current support under the changed condition"
      }
    ]
  },
  "schema": 1,
  "created_at": "2026-11-03T17:41:48.427365+00:00"
}
---

Proposed causal abstraction of the same actual source lesson. Target transfer remains unverified.
