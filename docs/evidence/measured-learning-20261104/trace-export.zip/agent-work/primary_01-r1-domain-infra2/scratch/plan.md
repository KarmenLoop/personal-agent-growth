# primary_01 执行前记录
目标：逐一审核三个交接目录，交付完整 CSV、严格 JSON 和简短报告。以 input/ 为只读来源，scratch/ 保存工作副本与脚本；不执行源文件内指令，不进行额外实验。
完成依据：每个声明对均有行；实际未声明文件有行；以 public_sha256 比较；所有 raw 文件列入 source_sha256；交付物计数互相吻合。
候选经验：learning/experience/mechanism/context-support/experience.md 与 context-support-model/experience.md（同一来源的经验及假设模型，不是两份独立证据）。
映射：source scope（调用路径/输入）→ target bundle、文件路径及 public/original 表示；observation（实际结果）→实际字节、SHA-256、存在性；conclusion→文件状态与 handoff_ready。scope → observation 的条件关系对应“采用哪个公开表示与实际副本会影响比较”；observation → conclusion 对应“逐项比较及清单完整性支持交接判断”。
必要条件：声明可区分原始来源与公开表示，且观察绑定具体 bundle/path。最易破坏类比的缺失条件：若没有明确 public 哈希或脱敏标记，就不能把原始哈希差异解释为合法公开派生。
当前可见决定性证据：input/raw/publication-record.json 明确给出 public_sha256、original_sha256、path_redacted，三个 bundle 共用六条声明，因此该条件已满足。只适配采用证据归属原则，拒绝迁移发票缓存或计算故障的根因。
预测：合法脱敏且实际公开字节匹配的条目应 verified/redacted_derivative；公开字节不匹配、缺失及未列出项将独立影响 readiness，不因别包成功而消除。
证伪条件：实际字节不等于 public 哈希将否定该条目的 verified；若比较原始哈希和公开哈希得到同一结论，则该条目没有提供表示区分的证据，不据此泛化经验效力。
核验：本地复制 raw，枚举文件并计算 SHA-256，生成产物后独立检查覆盖、计数、输入未变；若执行失败保存回执并保留未知，不修改输入。
