from pathlib import Path
import csv, hashlib, json, shutil, sys
root=Path.cwd()
raw=root/'input/raw'
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before={p.relative_to(root/'input').as_posix():sha(p) for p in sorted(raw.rglob('*')) if p.is_file()}
task_hash=sha(root/'input/task.md')
copy=root/'scratch/public-copy'
shutil.copytree(root/'input',copy)
record=json.loads((copy/'raw/publication-record.json').read_text())
fields='bundle,path,status,observed_bytes,observed_sha256,declared_public_sha256,original_sha256,publication_relation'.split(',')
rows=[]
for bundle in record['bundles']:
    directory=copy/'raw/bundles'/bundle
    declared={f['path'] for f in record['files']}
    for f in record['files']:
        p=directory/f['path']
        observed=sha(p) if p.is_file() else ''
        relation=('unchanged' if f['original_sha256']==f['public_sha256'] else 'redacted_derivative' if f.get('path_redacted') is True else 'undocumented_difference')
        rows.append(dict(zip(fields,[bundle,f['path'],'missing' if not p.is_file() else 'verified' if observed==f['public_sha256'] else 'mismatch',p.stat().st_size if p.is_file() else '',observed,f['public_sha256'],f['original_sha256'],relation])))
    for p in sorted(directory.rglob('*')):
        if p.is_file() and p.relative_to(directory).as_posix() not in declared:
            rows.append(dict(zip(fields,[bundle,p.relative_to(directory).as_posix(),'unlisted',p.stat().st_size,sha(p),'','','unknown'])))
summary={
'declared_files':sum(r['status']!='unlisted' for r in rows),
'verified_files':sum(r['status']=='verified' for r in rows),
'mismatched_files':sum(r['status']=='mismatch' for r in rows),
'missing_files':sum(r['status']=='missing' for r in rows),
'unlisted_files':sum(r['status']=='unlisted' for r in rows),
'verified_redacted_derivatives':sum(r['status']=='verified' and r['publication_relation']=='redacted_derivative' for r in rows),
'handoff_ready':all(r['status']=='verified' for r in rows)}
result={'schema':1,'task_id':'primary_01','data_kind':'historical_inputs_with_controlled_integrity_variants','source_sha256':before,'summary':summary}
out=root/'output'
with (out/'audit.csv').open('w',newline='',encoding='utf-8') as fp:
    writer=csv.DictWriter(fp,fieldnames=fields);writer.writeheader();writer.writerows(rows)
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
lines=['# 离线交接审计','',f"共 {summary['declared_files']} 个声明文件对：{summary['verified_files']} 个通过、{summary['mismatched_files']} 个不匹配、{summary['missing_files']} 个缺失；另有 {summary['unlisted_files']} 个未列出文件。整体 handoff_ready 为 false。",'', '| 交接包 | verified | mismatch | missing | unlisted | 就绪 |','|---|---:|---:|---:|---:|---|']
for b in record['bundles']:
    rr=[r for r in rows if r['bundle']==b]
    counts=[sum(r['status']==s for r in rr) for s in ['verified','mismatch','missing','unlisted']]
    lines.append('| '+b+' | '+' | '.join(map(str,counts))+' | '+('是' if all(r['status']=='verified' for r in rr) else '否')+' |')
lines+=['','待处理项：']
for r in rows:
    if r['status']!='verified':lines.append(f"- `{r['bundle']}/{r['path']}`：{r['status']}。详见 audit.csv 的实际与声明哈希。")
lines+=['',f"有 {summary['verified_redacted_derivatives']} 个公开脱敏派生文件通过验证。verified 仅表示实际交付字节等于 public_sha256；original_sha256 保留来源追溯作用。哈希差异且标记 path_redacted 的声明归为 redacted_derivative，不因此判为传输损坏。即使某派生文件实际不匹配，其声明关系与当前字节状态仍分别保留。",'','范围：以 input/ 的只读副本执行，覆盖声明的三个目录及其中全部实际文件。result.json 的 source_sha256 包含全部实际 raw 文件（含未列出文件），路径相对 input/。audit.csv 包含全部声明对和未列出文件；空观察值表示缺失，未列出项的声明字段留空。','', '这是历史项目输入与受控传输变体的字节一致性审计，不是实时发布审计。未运行历史测试、未验证业务内容正确性，也未验证脱敏是否充分；原始源字节未提供，无法独立验证其哈希真实性或重建脱敏过程。当前异常不证明历史官方发布受损。','', '需由交接维护者恢复不匹配和缺失的公开副本，并核实未列出文件应移除还是经批准纳入新声明；本次保留现状与失败证据，未修改清单或输入。', '', '经验使用：适配 context-support 的“证据绑定当前上下文”原则，区分 bundle/path 与 public/original 表示；迁移映射与执行前预测见 scratch/plan.md，本次反馈见 learning/audit-primary_01.md。此局部应用不证明来源因果模型普适。']
(out/'report.md').write_text('\n'.join(lines)+'\n')
after={p.relative_to(root/'input').as_posix():sha(p) for p in sorted(raw.rglob('*')) if p.is_file()}
assert before==after and task_hash==sha(root/'input/task.md')
(root/'scratch/input-baseline.json').write_text(json.dumps({'raw':before,'task_sha256':task_hash},indent=2)+'\n')
print(json.dumps({'summary':summary,'exceptions':[r for r in rows if r['status']!='verified'],'input_unchanged':True},ensure_ascii=False,indent=2))
