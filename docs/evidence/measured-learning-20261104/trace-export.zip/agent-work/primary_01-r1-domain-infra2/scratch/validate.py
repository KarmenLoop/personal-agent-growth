import csv,hashlib,json
from pathlib import Path
root=Path.cwd(); raw=root/'input/raw'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((root/'output/result.json').read_text(),parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
rows=list(csv.DictReader((root/'output/audit.csv').open()))
m=json.loads((raw/'publication-record.json').read_text())
expected={(b,f['path']) for b in m['bundles'] for f in m['files']}
actual={(b,p.relative_to(raw/'bundles'/b).as_posix()) for b in m['bundles'] for p in (raw/'bundles'/b).rglob('*') if p.is_file()}
assert len(rows)==len(expected|actual)==19
assert {(x['bundle'],x['path']) for x in rows}==expected|actual
for x in rows:
 p=raw/'bundles'/x['bundle']/x['path']
 if x['status']=='missing':assert not p.exists() and x['observed_bytes']==x['observed_sha256']==''
 else:assert int(x['observed_bytes'])==len(p.read_bytes()) and x['observed_sha256']==sha(p)
 if x['status']=='unlisted':assert x['declared_public_sha256']==x['original_sha256']=='' and x['publication_relation']=='unknown'
 else:
  f=next(f for f in m['files'] if f['path']==x['path'])
  assert x['declared_public_sha256']==f['public_sha256'] and x['original_sha256']==f['original_sha256']
  assert x['publication_relation']==('unchanged' if f['public_sha256']==f['original_sha256'] else 'redacted_derivative' if f['path_redacted'] else 'undocumented_difference')
  if p.exists():assert x['status']==('verified' if sha(p)==f['public_sha256'] else 'mismatch')
assert r['schema']==1 and r['task_id']=='primary_01' and r['data_kind']=='historical_inputs_with_controlled_integrity_variants'
assert r['source_sha256']=={p.relative_to(root/'input').as_posix():sha(p) for p in raw.rglob('*') if p.is_file()}
s=r['summary']
for key,status in [('verified_files','verified'),('mismatched_files','mismatch'),('missing_files','missing'),('unlisted_files','unlisted')]:assert s[key]==sum(x['status']==status for x in rows)
assert s['declared_files']==len(expected)
assert s['verified_redacted_derivatives']==sum(x['status']=='verified' and x['publication_relation']=='redacted_derivative' for x in rows)
assert s['handoff_ready'] is all(x['status']=='verified' for x in rows)
baseline=json.loads((root/'scratch/input-baseline.json').read_text())
assert baseline['raw']==r['source_sha256'] and baseline['task_sha256']==sha(root/'input/task.md')
print('PASS: strict JSON; 19 unique rows; exhaustive declared/actual coverage; byte counts and hashes; publication relations; summary; complete raw hash map; input unchanged.')
print('Artifact SHA-256:')
for p in sorted((root/'output').iterdir()): print(p.name,sha(p))
