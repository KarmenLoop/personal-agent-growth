# 离线交接审计

共 18 个声明文件对：16 个通过、1 个不匹配、1 个缺失；另有 1 个未列出文件。整体 handoff_ready 为 false。

| 交接包 | verified | mismatch | missing | unlisted | 就绪 |
|---|---:|---:|---:|---:|---|
| handoff-a | 6 | 0 | 0 | 0 | 是 |
| handoff-b | 5 | 1 | 0 | 0 | 否 |
| handoff-c | 5 | 0 | 1 | 1 | 否 |

待处理项：
- `handoff-b/final-tests.stderr`：mismatch。详见 audit.csv 的实际与声明哈希。
- `handoff-c/ledger-green.stderr`：missing。详见 audit.csv 的实际与声明哈希。
- `handoff-c/local-note.txt`：unlisted。详见 audit.csv 的实际与声明哈希。

有 9 个公开脱敏派生文件通过验证。verified 仅表示实际交付字节等于 public_sha256；original_sha256 保留来源追溯作用。哈希差异且标记 path_redacted 的声明归为 redacted_derivative，不因此判为传输损坏。即使某派生文件实际不匹配，其声明关系与当前字节状态仍分别保留。

范围：以 input/ 的只读副本执行，覆盖声明的三个目录及其中全部实际文件。result.json 的 source_sha256 包含全部实际 raw 文件（含未列出文件），路径相对 input/。audit.csv 包含全部声明对和未列出文件；空观察值表示缺失，未列出项的声明字段留空。

这是历史项目输入与受控传输变体的字节一致性审计，不是实时发布审计。未运行历史测试、未验证业务内容正确性，也未验证脱敏是否充分；原始源字节未提供，无法独立验证其哈希真实性或重建脱敏过程。当前异常不证明历史官方发布受损。

需由交接维护者恢复不匹配和缺失的公开副本，并核实未列出文件应移除还是经批准纳入新声明；本次保留现状与失败证据，未修改清单或输入。

经验使用：适配 context-support 的“证据绑定当前上下文”原则，区分 bundle/path 与 public/original 表示；迁移映射与执行前预测见 scratch/plan.md，本次反馈见 learning/audit-primary_01.md。此局部应用不证明来源因果模型普适。
