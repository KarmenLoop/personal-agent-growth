# primary_02 — 完成记录

## 来源、采用和拒绝
实际读取：`source-input.md`、`experience/mechanism/context-support/experience.md`、`evidence/response-4.md`、`evidence/receipt-4.json`（来源任务 invoice-judgment-20261103）。本根没有既有项目 context 或 node。

采用该经验的有限部分：把判断绑定实际输入、版本、路径和验证阶段。本次将 input/raw 全部文件的真实 SHA-256 写入 result.json；验证实际 output 文件而非只信生成程序的退出码。拒绝直接迁移缓存缺陷解释：本任务是静态 CSV 修订选择和聚合，无缓存入口证据。源案例失败保留于原始 evidence，不能算作本任务失败。

## 决定与结果
执行前预测及验收范围见 `../scratch/plan.md`。最高修订先于质量、缺失过滤；b8 使 b7 失效，即使 b8 被拒绝。校准、均值和指数以精确有理数计算，仅最终报告舍入。该样本未触及恰好半位的舍入分歧，所选规则为半偶舍入。

实际运行：指定 Python 3.12.14，`-B scratch/build.py`，退出码 0；原始 stdout/stderr 在 `../scratch/build.stdout`、`../scratch/build.stderr`。再以 `-B scratch/verify.py` 重读交付物核对全部逐行处分、校准值、9 个站日结果、3 个日指数、严格 JSON、数量和源文件哈希，退出码 0；原始回执在 `../scratch/verify.stdout`、`../scratch/verify.stderr`，包含实际输出哈希。未发生本任务执行失败；未开展额外实验。

交付：`../output/audit.csv`、`../output/station-days.csv`、`../output/result.json`、`../output/report.md`。18 源行，12 接受行；前两日指数 0.133333、0.233333；末日 Cedar 缺值，指数 null。输入与 skill 未改。

## 限制与可迁移候选
局部经验候选：有修订的数据先确定当前身份版本，再评估可用性；否则会复活被当前拒绝版本替代的旧值。证据仅限本任务实际样本，未宣称跨任务或跨宿主验证。未知值保留为空/null，需新合格源数据后重算；不安排未来动作。没有一般能力或成本结论。
