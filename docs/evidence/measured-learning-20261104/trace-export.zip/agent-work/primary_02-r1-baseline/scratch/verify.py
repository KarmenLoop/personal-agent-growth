import csv,json,hashlib,sys
from pathlib import Path
out=Path('output')
a=list(csv.DictReader((out/'audit.csv').open()))
s=list(csv.DictReader((out/'station-days.csv').open()))
r=json.loads((out/'result.json').read_text(),parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
assert len(a)==18 and len(s)==9
by={x['row_id']:x for x in a}
expected={'a1':'0.1','a2':'0.2','a3':'0.1','a4':'0.2','a5':'0.3','a6':'-0.1','a7':'0.2','b2':'0.3','b5':'0.3','b6':'0.1','c1':'0.2','c2':'0.3'}
from decimal import Decimal
for k,v in expected.items():
    assert by[k]['disposition']=='accepted' and Decimal(by[k]['calibrated_c'])==Decimal(v)
for k,d in {'b1':'superseded','b3':'missing_value','b4':'rejected_quality','b7':'superseded','b8':'rejected_quality','c3':'missing_value'}.items():
    assert by[k]['disposition']==d and by[k]['calibrated_c']==''
assert [(x['accepted_replicates'],x['mean_c']) for x in s]==[('2','0.150000'),('3','0.200000'),('2','0.050000'),('1','0.300000'),('1','0.300000'),('1','0.100000'),('1','0.200000'),('1','0.300000'),('0','')]
assert r['schema']==1 and r['task_id']=='primary_02' and r['data_kind']=='derived_fixture_not_actual_measurements'
assert r['summary']['source_rows']==18 and r['summary']['accepted_rows']==12
assert [d['index_c'] for d in r['summary']['days']]==[0.133333,0.233333,None]
assert [d['present_stations'] for d in r['summary']['days']]==[3,3,2]
assert [d['complete'] for d in r['summary']['days']]==[True,True,False]
assert all(d['expected_stations']==3 for d in r['summary']['days'])
actual={p.relative_to('input').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('input/raw').rglob('*') if p.is_file()}
assert r['source_sha256']==actual
print(json.dumps({'stage':'actual_output_readback_and_contract_checks','status':'passed','python':sys.version,'source_sha256':actual,'output_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}},ensure_ascii=False,indent=2))
