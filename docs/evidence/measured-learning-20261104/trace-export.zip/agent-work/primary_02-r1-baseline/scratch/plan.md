# primary_02 执行前记录
目标：仅对 input/raw 的派生夹具生成逐行审计、配置站日矩阵、等站权指数与交接报告。
验收：最高 revision 优先于质量/缺失判定；精确十进制运算；仅报告时舍入六位；完整原始文件 SHA-256；严格 JSON。
预测：2026-01-03 Cedar 缺失导致当天指数 null；被拒绝的新修订不能恢复旧修订。
核验：对实际输出重读，独立核对已知站日均值、逐行处分、条数和源文件哈希。不开展额外实验。
经验：读取 learning/source-input.md、learning/experience/mechanism/context-support/experience.md 及其两份 evidence。采用证据与输入绑定原则；拒绝迁移缓存根因。无项目 context/node 可恢复。
边界：只读 input/ 与 skill/；不联网、不委派；运行帮助文件放 scratch/。
失败后继：保留回执，定位到导入、计算或验收阶段；若任务语义缺口无法消除，报告未知而非补造数据。
