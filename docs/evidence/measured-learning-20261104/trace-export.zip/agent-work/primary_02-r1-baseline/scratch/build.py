import csv, json, hashlib, sys
from pathlib import Path
from fractions import Fraction
from decimal import Decimal, localcontext, ROUND_HALF_EVEN
root=Path('input'); out=Path('output')
files=sorted((root/'raw').rglob('*'))
hashes={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
settings=json.loads((root/'raw/settings.json').read_text())
rows=list(csv.DictReader((root/'raw/measurements.csv').open(newline='')))
key=lambda r:(r['date'],r['station'],r['replicate'])
latest={}
for r in rows: latest[key(r)]=max(latest.get(key(r),-1),int(r['revision']))
def fixed(v):
    with localcontext() as c:
        c.prec=80
        return format((Decimal(v.numerator)/Decimal(v.denominator)).quantize(Decimal('.000001'),rounding=ROUND_HALF_EVEN),'f')
groups={}; audit=[]
for r in rows:
    v=None
    if int(r['revision']) != latest[key(r)]: d='superseded'
    elif r['quality']!='ok': d='rejected_quality'
    elif r['reading_c'] in ('','NA') or r['bias_c'] in ('','NA'): d='missing_value'
    else:
        d='accepted'; v=Fraction(r['reading_c'])-Fraction(r['bias_c'])
        groups.setdefault((r['date'],r['station']),[]).append(v)
    # Preserve exact replicate values (all supplied values terminate).
    if v is not None:
        with localcontext() as c:
            c.prec=80
            value=format(Decimal(v.numerator)/Decimal(v.denominator),'f')
    else: value=''
    audit.append((r['row_id'],d,value))
with (out/'audit.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['row_id','disposition','calibrated_c']); w.writerows(audit)
sd=[]; days=[]
for date in settings['dates']:
    means=[]
    for station in settings['stations']:
        values=groups.get((date,station),[])
        mean=sum(values,Fraction(0))/len(values) if values else None
        if mean is not None: means.append(mean)
        sd.append((date,station,len(values),fixed(mean) if mean is not None else ''))
    complete=len(means)==len(settings['stations'])
    days.append(dict(date=date,expected_stations=len(settings['stations']),present_stations=len(means),complete=complete,index_c=float(fixed(sum(means,Fraction(0))/len(means))) if complete else None))
with (out/'station-days.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['date','station','accepted_replicates','mean_c']); w.writerows(sd)
result=dict(schema=1,task_id='primary_02',data_kind='derived_fixture_not_actual_measurements',source_sha256=hashes,summary=dict(source_rows=len(rows),accepted_rows=sum(r[1]=='accepted' for r in audit),days=days))
(out/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
(out/'report.md').write_text('''# 站点指数交接

本交付仅为离线分析用的派生夹具，不是真实环境观测，单位为摄氏度距平。

- `audit.csv`：18 条源记录的逐行处分与已接受记录的校准值；12 条被接受。
- `station-days.csv`：全部 3 日期 × 3 配置站点，包含接受的重复数与均值。
- `result.json`：严格 JSON，包含源文件 SHA-256、计数及每日完整性与指数。

按日期/站点/重复编号先取最高修订，再判质量和缺失；拒绝的新修订不会回退至旧数据。先按 reading − bias 校准，再算站日均值，最后对站点等权平均，使用未舍入均值计算指数；报告的均值与指数按六位小数舍入（半偶舍入）。

2026-01-01：3/3 站点，指数 0.133333。2026-01-02：3/3 站点，指数 0.233333。2026-01-03：2/3 站点，Cedar 的当前记录 c3 缺少 reading，站日均值为空、指数为 null；未插补。

b1 与 b7 已被较高修订取代；b8 虽被质量拒绝，仍使 b7 失效。没有未解决的导入异常；不完整日需要新的合格源数据才能补齐。原始输入保持不变。
''')
print(json.dumps({'stage':'artifacts_written','source_rows':len(rows),'accepted_rows':result['summary']['accepted_rows'],'days':days},ensure_ascii=False))
