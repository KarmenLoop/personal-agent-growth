import csv, json, hashlib
from pathlib import Path
from fractions import Fraction
from decimal import Decimal
from collections import Counter

root=Path('input'); out=Path('output')
raw_files=sorted((root/'raw').rglob('*'))
hashes={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in raw_files if p.is_file()}
settings=json.loads((root/'raw/settings.json').read_text())
with (root/'raw/measurements.csv').open(newline='') as f: rows=list(csv.DictReader(f))
def key(r): return r['date'],r['station'],r['replicate']
latest={}
for r in rows: latest[key(r)]=max(latest.get(key(r),-1),int(r['revision']))
def number(s): return Fraction(Decimal(s))
def rounded(x):
    # Exact nearest integer, ties to even, at the six decimal scale.
    n,d=x.numerator*1000000,x.denominator
    q,rem=divmod(n,d)
    if rem*2>d or (rem*2==d and q%2): q+=1
    return f'{q/1000000:.6f}'
def exact(x):
    # All calibrated source decimals terminate; use integer arithmetic.
    d=x.denominator; a=b=0
    while d%2==0: d//=2; a+=1
    while d%5==0: d//=5; b+=1
    assert d==1
    places=max(a,b); n=x.numerator*(10**places//x.denominator)
    sign='-' if n<0 else ''; n=abs(n)
    if not places: return sign+str(n)
    digits=str(n).zfill(places+1)
    return (sign+digits[:-places]+'.'+digits[-places:]).rstrip('0').rstrip('.')
audit=[]; groups={}
for r in rows:
    value=None
    if int(r['revision'])<latest[key(r)]: disposition='superseded'
    elif r['quality']!='ok': disposition='rejected_quality'
    elif r['reading_c'] in ('','NA') or r['bias_c'] in ('','NA'): disposition='missing_value'
    else:
        disposition='accepted'; value=number(r['reading_c'])-number(r['bias_c'])
        groups.setdefault((r['date'],r['station']),[]).append(value)
    audit.append({'row_id':r['row_id'],'disposition':disposition,'calibrated_c':exact(value) if value is not None else ''})
means={k:sum(v,Fraction())/len(v) for k,v in groups.items()}
station_days=[]; days=[]
for date in settings['dates']:
    present=0; station_means=[]
    for station in settings['stations']:
        k=(date,station); mean=means.get(k)
        station_days.append(dict(date=date,station=station,accepted_replicates=len(groups.get(k,[])),mean_c=rounded(mean) if mean is not None else ''))
        if mean is not None: present+=1; station_means.append(mean)
    complete=present==len(settings['stations'])
    days.append(dict(date=date,expected_stations=len(settings['stations']),present_stations=present,complete=complete,index_c=float(rounded(sum(station_means,Fraction())/len(station_means))) if complete else None))
for name,data,fields in [('audit.csv',audit,['row_id','disposition','calibrated_c']),('station-days.csv',station_days,['date','station','accepted_replicates','mean_c'])]:
    with (out/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(data)
result=dict(schema=1,task_id='primary_02',data_kind='derived_fixture_not_actual_measurements',source_sha256=hashes,summary=dict(source_rows=len(rows),accepted_rows=sum(r['disposition']=='accepted' for r in audit),days=days))
(out/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
(out/'report.md').write_text('''# 站点指数交接

本交付仅为离线分析用的派生夹具，不是真实环境观测。单位：摄氏度异常。

- `audit.csv`：逐源行记录当前修订判定与有效校准值。
- `station-days.csv`：全部 3 日期 × 3 站点，提供有效重复数与均值；缺失均值留空。
- `result.json`：严格 JSON，包含输入 SHA-256、总计与每日等站点权重指数。

共 18 条源记录，12 条 accepted、2 条 superseded、2 条 rejected_quality、2 条 missing_value。最高修订优先，拒绝的新修订不会恢复旧行。

2026-01-01 与 2026-01-02 均具备 3 个站点，指数分别为 0.133333 与 0.233333。2026-01-03 只有 2 个站点：Cedar 当前读数缺失，站点均值为空，日指数为 null；未作插补。

均值及指数由未舍入的精确值计算，报告时保留六位小数（half-even）；JSON 数字可能省略尾零。审计校准值保持精确。未解决项仅为夹具中 Cedar 的缺值，完整指数需提供有效源记录后重新生成。
''')
print(json.dumps({'counts':dict(Counter(r['disposition'] for r in audit)),'days':days,'hashes':hashes},indent=2))
