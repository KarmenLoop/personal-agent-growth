import csv,json,hashlib,sys
from pathlib import Path
p=Path('output')
r=json.loads((p/'result.json').read_text(),parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))
def read(n):
    with (p/n).open(newline='') as f:return list(csv.DictReader(f))
a=read('audit.csv'); s=read('station-days.csv')
assert len(a)==18 and len({x['row_id'] for x in a})==18
expected={'a1':'.1','a2':'.2','a3':'.1','a4':'.2','a5':'.3','a6':'-.1','a7':'.2','b2':'.3','b5':'.3','b6':'.1','c1':'.2','c2':'.3'}
from decimal import Decimal
for x in a:
    rid=x['row_id']
    if rid in expected:
        assert x['disposition']=='accepted' and Decimal(x['calibrated_c'])==Decimal(expected[rid])
    else:
        assert x['calibrated_c']==''
        assert x['disposition']==({'b1':'superseded','b7':'superseded','b4':'rejected_quality','b8':'rejected_quality','b3':'missing_value','c3':'missing_value'}[rid])
expected_means=[('2','0.150000'),('3','0.200000'),('2','0.050000'),('1','0.300000'),('1','0.300000'),('1','0.100000'),('1','0.200000'),('1','0.300000'),('0','')]
assert [(x['accepted_replicates'],x['mean_c']) for x in s]==expected_means
settings=json.loads(Path('input/raw/settings.json').read_text())
assert [(x['date'],x['station']) for x in s]==[(d,t) for d in settings['dates'] for t in settings['stations']]
assert r['schema']==1 and r['task_id']=='primary_02' and r['data_kind']=='derived_fixture_not_actual_measurements'
assert r['summary']['source_rows']==18 and r['summary']['accepted_rows']==12
assert [d['index_c'] for d in r['summary']['days']]==[0.133333,0.233333,None]
assert [d['complete'] for d in r['summary']['days']]==[True,True,False]
assert [(d['expected_stations'],d['present_stations']) for d in r['summary']['days']]==[(3,3),(3,3),(3,2)]
actual={f.relative_to('input').as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in Path('input/raw').rglob('*') if f.is_file()}
assert r['source_sha256']==actual
assert {f.name for f in p.iterdir()}=={'audit.csv','station-days.csv','result.json','report.md'}
print('PASS: all 18 audit rows, 9 station-days, 3 daily results, strict JSON and raw SHA-256 verified.')
print('Python:',sys.version.split()[0])
for f in sorted(p.iterdir()): print(f.as_posix(),hashlib.sha256(f.read_bytes()).hexdigest())
