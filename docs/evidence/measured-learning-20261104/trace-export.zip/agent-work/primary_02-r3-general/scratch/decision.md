# primary_02 执行前决定
目标：按 input/task.md 交付四个离线派生夹具文件。
最小未决问题：拒绝的最高修订是否仍覆盖旧有效行？任务明确为是，数据 b7/b8 是直接核验对象。
预测：b7 为 superseded，b8 为 rejected_quality；c3 缺失使 2026-01-03 指数为空。
执行：有理数精确计算，最后按六位小数 half-even 舍入；审计校准值保持精确十进制。
核验：检查全部源行归属、最高修订优先、完整配置网格、独立手算日指数及输入哈希。
来源经验：读取 learning/source-input.md、learning/experience/mechanism/context-support/experience.md 和 learning/evidence/response-4.md。仅采用输入/版本约束方法，不迁移其缓存诊断。无跨任务有效性或成本收益主张。
失败后继：保留原始输出，定位生成或验收阶段再修复；不启动额外实验。
