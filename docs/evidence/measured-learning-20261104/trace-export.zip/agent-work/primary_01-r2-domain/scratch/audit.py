import csv, hashlib, json
from pathlib import Path
base=Path('input'); raw=base/'raw'; out=Path('output')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source={p.relative_to(base).as_posix():sha(p) for p in sorted(raw.rglob('*')) if p.is_file()}
record=json.loads((raw/'publication-record.json').read_text())
rows=[]; per={}
for bundle in record['bundles']:
    directory=raw/'bundles'/bundle
    declared={f['path']:f for f in record['files']}
    for path,f in sorted(declared.items()):
        p=directory/path
        exists=p.is_file(); digest=sha(p) if exists else ''
        relation='unchanged' if f['original_sha256']==f['public_sha256'] else ('redacted_derivative' if f.get('path_redacted') else 'undocumented_difference')
        rows.append(dict(bundle=bundle,path=path,status=('verified' if digest==f['public_sha256'] else 'mismatch') if exists else 'missing',observed_bytes=p.stat().st_size if exists else '',observed_sha256=digest,declared_public_sha256=f['public_sha256'],original_sha256=f['original_sha256'],publication_relation=relation))
    for p in sorted(directory.rglob('*')):
        if p.is_file() and p.relative_to(directory).as_posix() not in declared:
            rows.append(dict(bundle=bundle,path=p.relative_to(directory).as_posix(),status='unlisted',observed_bytes=p.stat().st_size,observed_sha256=sha(p),declared_public_sha256='',original_sha256='',publication_relation='unknown'))
    br=[r for r in rows if r['bundle']==bundle]
    per[bundle]={s:sum(r['status']==s for r in br) for s in ['verified','mismatch','missing','unlisted']}
    per[bundle]['handoff_ready']=all(r['status']=='verified' for r in br)
summary=dict(declared_files=len(record['bundles'])*len(record['files']),verified_files=sum(r['status']=='verified' for r in rows),mismatched_files=sum(r['status']=='mismatch' for r in rows),missing_files=sum(r['status']=='missing' for r in rows),unlisted_files=sum(r['status']=='unlisted' for r in rows),verified_redacted_derivatives=sum(r['status']=='verified' and r['publication_relation']=='redacted_derivative' for r in rows),handoff_ready=all(r['status']=='verified' for r in rows))
with (out/'audit.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['bundle','path','status','observed_bytes','observed_sha256','declared_public_sha256','original_sha256','publication_relation']); w.writeheader(); w.writerows(rows)
result=dict(schema=1,task_id='primary_01',data_kind='historical_inputs_with_controlled_integrity_variants',source_sha256=source,summary=summary,bundle_summary=per)
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'summary':summary,'bundles':per,'issues':[r for r in rows if r['status']!='verified']},ensure_ascii=False,indent=2))
assert source=={p.relative_to(base).as_posix():sha(p) for p in sorted(raw.rglob('*')) if p.is_file()}
