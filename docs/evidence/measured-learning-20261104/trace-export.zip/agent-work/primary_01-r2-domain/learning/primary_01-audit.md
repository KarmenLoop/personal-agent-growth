# primary_01：完成记录与经验迁移

目标：离线核验三个公开交付副本，产出逐项 CSV、严格 JSON 和可复核报告。完成依据是覆盖全部声明对及未列入文件，按公开哈希判断，保留来源哈希与原始输入。实际执行为 `scratch/audit.py`，产物位于 `output/`。

读取候选：`learning/source-input.md`、`learning/source-model.md`、`learning/experience/mechanism/context-support/experience.md`、`learning/experience/mechanism/context-support-model/experience.md` 与 `learning/evidence/response-4.md`。旧经验原范围是发票计算与缓存两个入口的独立证据；模型抽象仍是假设。本地未提供其引用的 receipt-4.json，未声称复核该原始回执。

变量映射：旧 scope（输入、版本、执行路径）映射为目标的 bundle、文件路径、原始/公开版本；observation 映射为存在性、实际字节数和实际 SHA-256；conclusion 映射为逐文件 verified/mismatch/missing/unlisted 及目录 ready。方向关系为 scope 限定 observation，observation 支持 conclusion；某目录中的不符不会撤销另一目录独立取得的通过证据。

必要条件：有明确的目标版本基准，实际文件可读，观察能绑定到具体目录和路径。最可能破坏类比的缺失条件是混淆原始来源版本和公开脱敏版本，导致选择错误哈希。决定性检查为读取 publication-record：其同时声明 public_sha256、original_sha256 和 path_redacted；因此必须以 public_sha256 验收交付字节。

执行预测：若某文件与公开哈希一致而与原始哈希不同，且清单声明路径脱敏，则它应同时是 verified 和 redacted_derivative。可证伪条件：清单没有目标公开基准或未标脱敏，或实际字节不匹配公开哈希；此时不得把原始哈希差异解释成已验证的脱敏交付。没有预设各目录的损坏数量。

实际观察：18 个声明对中 16 个通过（其中 9 个脱敏衍生）、1 个不符、1 个缺失，另 1 个未列入；a 目录通过，b、c 不通过。适配采用“结论绑定上下文”这一核验纪律；拒绝把来源中的缓存机制、共同根因或修复策略迁入本任务。结果仅支持当前字节完整性结论，不证明一般迁移收益。

不确定性与失败：b 的 final-tests.stderr 不符；c 缺 ledger-green.stderr 且多出 local-note.txt，保留原样。来源原始回执缺失；异常成因和业务功能未知。脚本执行退出码 0 表示审计完成，不表示全部交付通过。未运行额外实验或使用其他 Agent。未将事后记录伪装为事先登记的学习动作；此 Markdown 是实际操作及候选适用性记录。

后继条件：交付负责人处理三个异常后，对修订副本按同一公开清单重新核验；本轮不修复输入。
