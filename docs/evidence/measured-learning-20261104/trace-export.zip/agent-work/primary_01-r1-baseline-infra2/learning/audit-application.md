# primary_01 经验应用记录

读取来源：`source-input.md`、`experience/mechanism/context-support/experience.md`、`evidence/response-4.md`（源经验 ID：context-support，记录版本 created_at 2026-11-03T17:41:48.298134+00:00）。未独立重现源任务，其 receipt-4.json 未读取，来源完整复核未知。

实际采用：将每个目录的交付字节绑定各自公开哈希，将 original_sha256 保留为声明的来源信息。不同目录分别验收，受控运输副本异常不推翻历史官方发布。拒绝将发票缓存根因类比为本次异常原因。

证据：`../output/audit.csv`、`../output/result.json`、`../output/report.md`；执行与断言回执为 `../scratch/audit.stdout`、`../scratch/audit.stderr`，程序为 `../scratch/audit.py`。18 项声明中 16 项匹配，9 项为匹配的脱敏衍生物；另有 1 不符、1 缺失、1 未列文件。

候选经验：审计经过公开脱敏的交接材料时，应分别保存来源声明与实际公开字节的哈希，并限定每个副本结论。前提是有明确的公开哈希和脱敏标记；声明本身不等于来源真实性已验证。仅记录本次实际应用，不宣称新场景复用或普适有效；未开展额外实验。
