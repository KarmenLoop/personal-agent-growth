from pathlib import Path
import csv, hashlib, json, shutil
raw = Path('input/raw')
out = Path('output')
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(root):
    return {f'raw/{p.relative_to(root).as_posix()}': digest(p) for p in sorted(root.rglob('*')) if p.is_file()}
before = inventory(raw)
work = Path('scratch/raw-copy')
shutil.copytree(raw, work)
assert inventory(work) == before
record = json.loads((work/'publication-record.json').read_text())
rows = []
for bundle in record['bundles']:
    directory = work/'bundles'/bundle
    declared = {entry['path']: entry for entry in record['files']}
    for path, entry in declared.items():
        p = directory/path
        original, public = entry['original_sha256'], entry['public_sha256']
        relation = 'unchanged' if original == public else ('redacted_derivative' if entry.get('path_redacted') else 'undocumented_difference')
        observed = digest(p) if p.is_file() else ''
        rows.append(dict(bundle=bundle,path=path,status=('verified' if observed == public else 'mismatch') if p.is_file() else 'missing', observed_bytes=p.stat().st_size if p.is_file() else '',observed_sha256=observed,declared_public_sha256=public,original_sha256=original,publication_relation=relation))
    for p in sorted(directory.rglob('*')):
        if p.is_file() and p.relative_to(directory).as_posix() not in declared:
            rows.append(dict(bundle=bundle,path=p.relative_to(directory).as_posix(),status='unlisted',observed_bytes=p.stat().st_size,observed_sha256=digest(p),declared_public_sha256='',original_sha256='',publication_relation='unknown'))
columns = 'bundle,path,status,observed_bytes,observed_sha256,declared_public_sha256,original_sha256,publication_relation'.split(',')
with (out/'audit.csv').open('w',newline='',encoding='utf-8') as f:
    writer = csv.DictWriter(f,fieldnames=columns)
    writer.writeheader(); writer.writerows(rows)
def summarize(items):
    counts = {name:sum(r['status']==status for r in items) for name,status in [('verified_files','verified'),('mismatched_files','mismatch'),('missing_files','missing'),('unlisted_files','unlisted')]}
    return dict(declared_files=sum(r['status']!='unlisted' for r in items),**counts,verified_redacted_derivatives=sum(r['status']=='verified' and r['publication_relation']=='redacted_derivative' for r in items),handoff_ready=not any(r['status']!='verified' for r in items))
summary = summarize(rows)
summary['bundles'] = {b:summarize([r for r in rows if r['bundle']==b]) for b in record['bundles']}
result = dict(schema=1,task_id='primary_01',data_kind='historical_inputs_with_controlled_integrity_variants',source_sha256=before,summary=summary)
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
report = ['# 离线交接完整性审计','',f"共 {summary['declared_files']} 个声明项：{summary['verified_files']} 项匹配、{summary['mismatched_files']} 项不符、{summary['missing_files']} 项缺失；另有 {summary['unlisted_files']} 个未列文件。整体交接就绪：{'是' if summary['handoff_ready'] else '否'}。",'', '| 目录 | 匹配 | 不符 | 缺失 | 未列 | 可交接 |','|---|---:|---:|---:|---:|---|']
for b,s in summary['bundles'].items():
    report.append(f"| {b} | {s['verified_files']} | {s['mismatched_files']} | {s['missing_files']} | {s['unlisted_files']} | {'是' if s['handoff_ready'] else '否'} |")
report += ['','## 待解决项','']
for r in rows:
    if r['status']!='verified':
        report.append(f"- `{r['bundle']}/{r['path']}`：`{r['status']}`。" + ('应取得与声明公开哈希匹配的副本。' if r['status']=='mismatch' else '应补齐声明的公开文件。' if r['status']=='missing' else '应由交接方确认并移除额外文件，或正式修订声明后重新核验。'))
report += ['','## 范围与证据','',f"`audit.csv` 包含全部 {len(rows)} 项，保存实际大小、实际 SHA-256、公开声明 SHA-256 与原始来源 SHA-256。`result.json` 保存所有 {len(before)} 个 raw 文件的实际哈希及统计。核验对象为 `input/raw/` 的工作副本，副本与原输入的全部文件哈希一致。",'',f"公开脱敏副本以 `public_sha256` 为验收基准；共有 {summary['verified_redacted_derivatives']} 个脱敏衍生项通过。`original_sha256` 仅保留来源声明，不将公开脱敏造成的差异认作损坏，也未独立验证原始未脱敏文件。",'', '这些材料是历史项目输入和受控运输变体；当前不符、缺失和额外文件只描述本次目录，不证明历史官方发布损坏。完整性匹配不代表文件内记录的测试通过，也不证明实时发布、安装或运行可用。未执行来源文件中的命令，未修复或改写输入。','', '已采用既有经验的上下文证据边界：各目录独立判断，来源与实际交付字节分开。没有据此迁移旧任务的缓存诊断或声称普适有效。']
(out/'report.md').write_text('\n'.join(report)+'\n')
assert inventory(raw) == before, 'raw input changed'
assert len(rows) == len(record['bundles'])*len(record['files'])+summary['unlisted_files']
with (out/'audit.csv').open(newline='') as f:
    assert len(list(csv.DictReader(f))) == len(rows)
assert json.loads((out/'result.json').read_text()) == result
print(json.dumps(summary,ensure_ascii=False,indent=2))
print(f'Validation passed: {len(rows)} audit rows; {len(before)} raw hashes; source unchanged; strict JSON parsed.')
