# primary_02 执行准备
目标：完成 input/raw 的离线派生夹具导入、逐行审计、站日均值和等站权每日指数；仅 output 为交付目录。input、skill 不修改，不联网、不使用其他 Agent、不启动额外实验。
验收：18 个来源行全部有审计；3 日期 × 3 配置站点全部有站日记录；最高修订优先；全站完整才有指数；精确计算后最终保留六位小数；原始文件 SHA-256 绑定结果。

## 来源与因果迁移准备
实际读取 learning/source-model.md、learning/source-input.md、learning/experience/mechanism/context-support-model/experience.md、learning/experience/mechanism/context-support/experience.md 及所引用 evidence/response-4.md、evidence/receipt-4.json。旧案例验证了报价入口改变后缓存旧值，而旧的直接计算缺陷仍有独立支持；其失败断言属于旧案例，不是本任务执行失败。
候选关系：旧 scope → observation → conclusion，映射为本任务的 identity+revision → 当前有效行及质量/缺失证据 → 是否计入站日均值；配置站集合 → 完整性证据 → 指数是否可发布。旧输入改变可使缓存证据失效，本任务新修订按契约使旧行失去贡献资格；两者仅在证据作用域上相似，不能据此推断这里存在缓存缺陷。
必要条件：证据确实依赖版本，且新版有取代旧版的授权规则。最可能使类比失效的条件是“版本变化不一定意味着旧记录失效”；原经验明确允许独立旧结论继续有效。本任务 task.md 明确最高修订替代，因此应适配为严格替代，而非保留旧有效数值。
决定性核查：b7/b8 同属 2026-01-02/Cedar/2，b8 revision=2 且 reject；b1/b2 同属 Alder/1，b2 为新版。这是输入事实，不是仅靠标签匹配。
执行前预测：b1、b7 superseded；b8 rejected_quality，不能回退 b7；Cedar 在 01-02 只有 b6，均值 0.1。01-03 Cedar 缺失，指数 null。反证条件：身份或修订并不匹配、契约允许回退、或无其他 Cedar 合格行等预测前提与实际数据不符时，撤回对应预测并核查。
决策：适配来源的证据绑定原则，拒绝直接迁移缓存故障解释。结果仅能支持当前夹具，不代表一般迁移有效性。

## 执行计划
使用 Python -B，以 Decimal 读取所有数值、Fraction 精确求均值，最终按 ROUND_HALF_EVEN 六位小数报告（本数据无舍入中点争议）。保存构建脚本、stdout/stderr，检查审计、聚合、严格 JSON 和来源不变；失败保留，不用历史退出码代替当前验收。

状态：已完成；最新有效节点为 summary.md。实际回执见 scratch/attempt-2.stdout、attempt-2.stderr、attempt-2.exit；已保留首次 shell 失败，不能将其误记为业务计算失败。
