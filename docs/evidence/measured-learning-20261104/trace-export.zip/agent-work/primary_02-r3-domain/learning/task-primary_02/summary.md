# 完成节点
已交付 output/audit.csv、station-days.csv、result.json、report.md。当前夹具 18 行中接受 12 行；每日指数分别为 0.133333、0.233333、null。01-03 Cedar 缺少 reading，不补值。

证据：scratch/build.py 是实际执行程序；scratch/attempt-2.stdout 为当前输入的验收输出，scratch/attempt-2.stderr 为空，scratch/attempt-2.exit 为 0。核查阶段覆盖逐行分类、9 个配置站日、修订拒绝不回退、等站权指数、严格 JSON 回读、input 全部文件前后哈希一致。无外部环境验证或其他执行方复用结论。

失败保留：第一次 Python 输出通过，但外层 zsh 在赋值只读变量 status 时退出 1；Python 原始退出码未捕获，保持未知。详见 scratch/attempt-1.md 与独立 stdout/stderr；随后改用 build_exit 捕获，重跑同一构建验收成功，没有启动额外实验。

迁移反馈：context-support 的证据绑定原则经适配用于当前修订身份，b7/b8 事实支持预测；未采用旧案例的缓存诊断。来源中“旧独立结论仍有效”与目标中“旧修订被替代”不能直接等同，依赖目标契约决定。此结果只支持该任务中证据作用域的适配，不证明因果模型普适有效。候选经验：在具有明确替代契约的修订数据中，先确定当前版本再作资格筛选；新版本拒绝不能恢复旧版本。若契约允许历史回退，此经验不适用。

全部必需产物已完成。剩余未知为来源数据无法补齐的 01-03 Cedar，以及未进行的跨任务迁移；无后续调度。原生用量和费用由宿主记录，本地不估计。
