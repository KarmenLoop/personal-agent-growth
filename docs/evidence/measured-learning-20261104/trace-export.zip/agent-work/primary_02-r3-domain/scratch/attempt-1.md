# 原始执行状态
命令：Python -B scratch/build.py > scratch/build.stdout 2> scratch/build.stderr，随后 shell 尝试 status=$?。
Python 已产生 status=passed 的 stdout，stderr 为空；但 shell 的 status 是 zsh 只读变量，导致外层命令退出码 1，原始错误：zsh:100: read-only variable: status。
不得把该外层退出码解释成计算失败，也不能从已丢失的 $? 还原 Python 退出码。后续使用非保留变量重新执行同一构建与验收，保留本次日志，不作为额外实验。
