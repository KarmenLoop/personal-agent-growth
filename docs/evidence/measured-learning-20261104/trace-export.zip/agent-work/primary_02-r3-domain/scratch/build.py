from pathlib import Path
import csv, json, hashlib
from decimal import Decimal, localcontext, ROUND_HALF_EVEN
from fractions import Fraction
from collections import Counter

root = Path('input')
raw = root / 'raw'
out = Path('output')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = {p.as_posix(): sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
settings = json.loads((raw/'settings.json').read_text())
with (raw/'measurements.csv').open(newline='') as f:
    rows = list(csv.DictReader(f))
identity = lambda r: (r['date'], r['station'], r['replicate'])
latest = {}
for r in rows:
    k = identity(r)
    latest[k] = max(latest.get(k, -1), int(r['revision']))
assert len({(identity(r), int(r['revision'])) for r in rows}) == len(rows), 'Ambiguous tied revisions'
values = {(d,s): [] for d in settings['dates'] for s in settings['stations']}
audit = []
for r in rows:
    assert (r['date'],r['station']) in values
    value = None
    if int(r['revision']) < latest[identity(r)]:
        status = 'superseded'
    elif r['quality'] != 'ok':
        status = 'rejected_quality'
    elif any(r[c] in ('', 'NA') for c in ('reading_c','bias_c')):
        status = 'missing_value'
    else:
        status = 'accepted'
        value = Fraction(Decimal(r['reading_c'])) - Fraction(Decimal(r['bias_c']))
        values[(r['date'],r['station'])].append(value)
    audit.append({'row_id':r['row_id'], 'disposition':status,
                  'calibrated_c': '' if value is None else str(Decimal(value.numerator)/Decimal(value.denominator))})
def rounded(v):
    with localcontext() as ctx:
        ctx.prec = 60
        return (Decimal(v.numerator)/Decimal(v.denominator)).quantize(Decimal('.000001'), rounding=ROUND_HALF_EVEN)
def mean(v):
    return sum(v, Fraction(0))/len(v) if v else None
station_days=[]
for (d,s), v in values.items():
    m=mean(v)
    station_days.append({'date':d, 'station':s, 'accepted_replicates':len(v), 'mean_c':'' if m is None else format(rounded(m),'.6f')})
days=[]
for d in settings['dates']:
    means=[mean(values[(d,s)]) for s in settings['stations']]
    present=sum(m is not None for m in means)
    complete=present == len(means)
    index=mean(means) if complete else None
    days.append({'date':d, 'expected_stations':len(means), 'present_stations':present,
                 'complete':complete, 'index_c':None if index is None else float(rounded(index))})
for name, data, columns in [
    ('audit.csv',audit,['row_id','disposition','calibrated_c']),
    ('station-days.csv',station_days,['date','station','accepted_replicates','mean_c'])]:
    with (out/name).open('w', newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns); w.writeheader(); w.writerows(data)
result={'schema':1,'task_id':'primary_02', 'data_kind':'derived_fixture_not_actual_measurements',
        'source_sha256':{p.relative_to(root).as_posix():sha(p) for p in sorted(raw.rglob('*')) if p.is_file()},
        'summary':{'source_rows':len(rows),'accepted_rows':sum(r['disposition']=='accepted' for r in audit),'days':days}}
(out/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
# Current-input acceptance checks, including cases that distinguish wrong aggregation/revision rules.
a={r['row_id']:r for r in audit}
assert len(audit)==18 and result['summary']['accepted_rows']==12
assert Counter(r['disposition'] for r in audit)=={'accepted':12,'superseded':2,'missing_value':2,'rejected_quality':2}
assert a['b1']['disposition']==a['b7']['disposition']=='superseded'
assert a['b8']['disposition']=='rejected_quality'
assert all((r['calibrated_c']!='') == (r['disposition']=='accepted') for r in audit)
assert len(station_days)==9
assert next(r for r in station_days if r['date']=='2026-01-02' and r['station']=='Cedar')['mean_c']=='0.100000'
assert [d['index_c'] for d in days]==[0.133333,0.233333,None]
assert [d['present_stations'] for d in days]==[3,3,2]
loaded=json.loads((out/'result.json').read_text(),parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
assert loaded==result
assert before=={p.as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
print(json.dumps({'status':'passed','checked':'current input and written outputs','source_rows':len(rows),'dispositions':dict(Counter(r['disposition'] for r in audit)),'days':days,'input_unchanged':True},ensure_ascii=False,indent=2))
