import csv, json, hashlib
from pathlib import Path
from decimal import Decimal, localcontext, ROUND_HALF_EVEN
root=Path('input'); out=Path('output')
rawfiles=sorted(p for p in (root/'raw').rglob('*') if p.is_file())
hashes={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in rawfiles}
settings=json.loads((root/'raw/settings.json').read_text())
rows=list(csv.DictReader((root/'raw/measurements.csv').open(newline='')))
identity=lambda r:tuple(r[k] for k in ('date','station','replicate'))
latest={}
for r in rows:
    key=identity(r); latest[key]=max(latest.get(key,-1),int(r['revision']))
values={}; audits=[]
with localcontext() as ctx:
    ctx.prec=60
    for r in rows:
        val=None
        if int(r['revision'])<latest[identity(r)]: status='superseded'
        elif r['quality']!='ok': status='rejected_quality'
        elif any(r[k] in ('','NA') for k in ('reading_c','bias_c')): status='missing_value'
        else:
            status='accepted'; val=Decimal(r['reading_c'])-Decimal(r['bias_c'])
            values.setdefault((r['date'],r['station']),[]).append(val)
        audits.append((r['row_id'],status,'' if val is None else format(val,'f')))
    def rounded(x): return x.quantize(Decimal('0.000001'),rounding=ROUND_HALF_EVEN)
    means={k:sum(v,Decimal(0))/len(v) for k,v in values.items()}
    with (out/'audit.csv').open('w',newline='') as f:
        w=csv.writer(f); w.writerow(['row_id','disposition','calibrated_c']); w.writerows(audits)
    with (out/'station-days.csv').open('w',newline='') as f:
        w=csv.writer(f); w.writerow(['date','station','accepted_replicates','mean_c'])
        for d in settings['dates']:
            for s in settings['stations']:
                k=(d,s); w.writerow([d,s,len(values.get(k,[])),format(rounded(means[k]),'f') if k in means else ''])
    days=[]
    for d in settings['dates']:
        present=[s for s in settings['stations'] if (d,s) in means]
        complete=len(present)==len(settings['stations'])
        index=sum((means[d,s] for s in present),Decimal(0))/len(settings['stations']) if complete else None
        days.append(dict(date=d,expected_stations=len(settings['stations']),present_stations=len(present),complete=complete,index_c=float(rounded(index)) if index is not None else None))
    result=dict(schema=1,task_id='primary_02',data_kind='derived_fixture_not_actual_measurements',source_sha256=hashes,summary=dict(source_rows=len(rows),accepted_rows=sum(a[1]=='accepted' for a in audits),days=days))
    (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
(out/'report.md').write_text('''# 站点指数交接

本包为明确标记的离线派生夹具，不是真实环境观测。单位为摄氏度距平。

- `audit.csv`：18 条源行的逐行处置，12 条 accepted；仅接受行包含 reading − bias 的校准值。另有 superseded、rejected_quality、missing_value 各 2 条。
- `station-days.csv`：3 日期 × 3 配置站点，共 9 行，含贡献重复数及站点日均值；无贡献值留空。
- `result.json`：严格 JSON，含来源 SHA-256、计数、完整性和按站点等权的每日指数。

2026-01-01 指数为 0.133333；2026-01-02 为 0.233333。2026-01-03 仅有 2/3 站点，Cedar 的当前 reading 缺失，因此该站均值留空，日指数为 null；未插补或回退旧修订。

先选每个日期/站点/重复的最高修订，再依次判断质量与缺失。b8 虽被拒绝，仍取代 b7。所有均值与指数使用未舍入中间值，最终以六位小数报告（半偶舍入）；JSON 数字可能省略末尾零。小数缩写及指数记法均按十进制解析。

不完整日期不能作为完整日指数使用；若需补齐，须提供新的有效源数据并重新计算。范围仅限给定配置与夹具，不推断实际环境或其他日期。
''')
print(json.dumps(result['summary'],ensure_ascii=False))
