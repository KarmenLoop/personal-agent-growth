from pathlib import Path
from fractions import Fraction
from collections import Counter
import csv,json,hashlib,sys,platform
p=Path('input'); o=Path('output')
readcsv=lambda f:list(csv.DictReader(f.open(newline='')))
r=readcsv(p/'raw/measurements.csv'); a=readcsv(o/'audit.csv'); sd=readcsv(o/'station-days.csv')
s=json.loads((p/'raw/settings.json').read_text())
def reject(x): raise ValueError(x)
j=json.loads((o/'result.json').read_text(),parse_float=Fraction,parse_constant=reject)
assert j['schema']==1 and j['task_id']=='primary_02' and j['data_kind']=='derived_fixture_not_actual_measurements'
assert j['source_sha256']=={f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in (p/'raw').rglob('*') if f.is_file()}
assert list(a[0])==['row_id','disposition','calibrated_c']
assert list(sd[0])==['date','station','accepted_replicates','mean_c']
assert len(a)==len(r)==18
v={}
for row, audit in zip(r,a):
    group=[t for t in r if all(t[k]==row[k] for k in ('date','station','replicate'))]
    expected='accepted'
    if any(int(t['revision'])>int(row['revision']) for t in group): expected='superseded'
    elif row['quality']!='ok': expected='rejected_quality'
    elif row['reading_c'] in ('','NA') or row['bias_c'] in ('','NA'): expected='missing_value'
    assert audit['row_id']==row['row_id'] and audit['disposition']==expected
    if expected=='accepted':
        value=Fraction(row['reading_c'])-Fraction(row['bias_c'])
        assert Fraction(audit['calibrated_c'])==value
        v.setdefault((row['date'],row['station']),[]).append(value)
    else: assert audit['calibrated_c']==''
expected_pairs=[(d,t) for d in s['dates'] for t in s['stations']]
assert [(x['date'],x['station']) for x in sd]==expected_pairs
means={k:sum(vs)/len(vs) for k,vs in v.items()}
rounded=lambda x:Fraction(round(x*1000000),1000000)
for x in sd:
    k=x['date'],x['station']
    assert int(x['accepted_replicates'])==len(v.get(k,[]))
    assert (Fraction(x['mean_c'])==rounded(means[k])) if k in means else x['mean_c']==''
assert j['summary']['source_rows']==len(r)
assert j['summary']['accepted_rows']==sum(map(len,v.values()))==12
assert len(j['summary']['days'])==len(s['dates'])
for date,day in zip(s['dates'],j['summary']['days']):
    present=[means[date,t] for t in s['stations'] if (date,t) in means]
    complete=len(present)==len(s['stations'])
    assert day==dict(date=date,expected_stations=len(s['stations']),present_stations=len(present),complete=complete,index_c=rounded(sum(present)/len(s['stations'])) if complete else None)
assert (o/'report.md').is_file()
assert set(x.name for x in o.iterdir())=={'audit.csv','station-days.csv','result.json','report.md'}
receipt={'status':'PASS','scope':'all source rows, configured station-days, independent exact rational calculations, strict JSON, raw SHA-256, four deliverables','dispositions':dict(Counter(x['disposition'] for x in a)),'source_sha256':j['source_sha256'],'artifact_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(o.iterdir())},'python':sys.version,'platform':platform.platform()}
print(json.dumps(receipt,ensure_ascii=False,indent=2))
