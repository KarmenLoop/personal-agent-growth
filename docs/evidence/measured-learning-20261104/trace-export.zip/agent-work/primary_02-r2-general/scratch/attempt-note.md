# 回执说明
生成命令成功，汇总见 output/result.json。
首次验证包装命令在 Python 检查器执行后使用 zsh 只读变量 status，导致 shell 退出 1；此为包装层失败，不据此判断产物错误。原 Python stdout/stderr 已单独保存在 verification.stdout / verification.stderr。保留此失败，重新执行同一检查器以获取明确进程退出码，不增加实验。
