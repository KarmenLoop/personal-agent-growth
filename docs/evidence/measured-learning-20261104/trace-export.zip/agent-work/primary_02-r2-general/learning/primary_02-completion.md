# primary_02 完成节点

状态：完成。产物见 ../output/report.md、../output/result.json 及两份 CSV。

采用经验：将证据绑定当前输入、修订与执行条件；不迁移发票或缓存根因。最高修订选择独立于质量过滤，先选修订后过滤，避免复活旧记录。此为当前夹具内应用，未开展跨任务实验或证明一般收益。

完成依据：../scratch/verify.py 使用独立 Fraction 运算检查全部 18 行和 9 个配置站点日、12 条接受记录、严格 JSON、来源及产物哈希。原始回执 ../scratch/verification-rerun.stdout，stderr 为空，Python 退出 0。环境与具体哈希见该回执。

保留失败：首次包装命令误用 zsh 只读变量 status，shell 退出 1；此前 Python 已完成且 stdout 为 PASS。失败及复跑说明见 ../scratch/attempt-note.md；未覆盖原始输出。

限制：2026-01-03 缺 Cedar，指数 null；无真实环境观测结论。原生费用与用量未知，由宿主记录。无待执行额外实验。

实际读取经验来源 SHA-256：

- `learning/source-input.md`：`b595707b82f7b18fe3f1f0709f5b835edc8edc827ced688feabc1169ce60c849`
- `learning/experience/mechanism/context-support/experience.md`：`4f84752132ab1f6a4138b77628601d66a02bb13d6fb7941394439b246a15dd69`
- `learning/evidence/response-4.md`：`90140a90bea97ff51d508f2cce951c2ce59e3e04efd2b602ea896c9e2a30083e`
- `learning/evidence/receipt-4.json`：`a1b0e4ee48eeff5f38c923f42094e930ed175911b0e1076650131bddb0e9676c`
