from pathlib import Path
import csv, hashlib, json, shutil
from collections import Counter

root = Path.cwd()
source = root / 'input'
work = root / 'scratch' / 'public-copy'
shutil.copytree(source, work, dirs_exist_ok=True)
raw = work / 'raw'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = {p.relative_to(source).as_posix(): digest(p) for p in source.rglob('*') if p.is_file()}
record = json.loads((raw / 'publication-record.json').read_text())
fields = 'bundle,path,status,observed_bytes,observed_sha256,declared_public_sha256,original_sha256,publication_relation'.split(',')
rows = []
for bundle in record['bundles']:
    base = raw / 'bundles' / bundle
    declared = {entry['path']: entry for entry in record['files']}
    for path, entry in declared.items():
        p = base / path
        observed = digest(p) if p.is_file() else ''
        relation = ('unchanged' if entry['original_sha256'] == entry['public_sha256'] else
                    'redacted_derivative' if entry.get('path_redacted') else 'undocumented_difference')
        rows.append(dict(zip(fields, [bundle, path, 'missing' if not p.is_file() else 'verified' if observed == entry['public_sha256'] else 'mismatch', p.stat().st_size if p.is_file() else '', observed, entry['public_sha256'], entry['original_sha256'], relation])))
    for p in sorted(base.rglob('*')):
        if p.is_file() and p.relative_to(base).as_posix() not in declared:
            rows.append(dict(zip(fields, [bundle, p.relative_to(base).as_posix(), 'unlisted', p.stat().st_size, digest(p), '', '', 'unknown'])))
counts = Counter(r['status'] for r in rows)
summary = dict(declared_files=len(record['bundles']) * len(record['files']), verified_files=counts['verified'], mismatched_files=counts['mismatch'], missing_files=counts['missing'], unlisted_files=counts['unlisted'], verified_redacted_derivatives=sum(r['status'] == 'verified' and r['publication_relation'] == 'redacted_derivative' for r in rows), handoff_ready=not any(counts[s] for s in ('mismatch','missing','unlisted')))
source_hashes = {p.relative_to(work).as_posix(): digest(p) for p in sorted(raw.rglob('*')) if p.is_file()}
result = dict(schema=1, task_id='primary_01', data_kind='historical_inputs_with_controlled_integrity_variants', source_sha256=source_hashes, summary=summary)
out = root / 'output'
with (out / 'audit.csv').open('w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)
(out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
lines = ['# 离线交接审计', '', '结论：整体交接尚未就绪（`handoff_ready: false`）。本次仅审计历史公开输入及受控传输变体，不代表历史正式发布受损，也不对日志所述测试重新执行或背书。', '', f"声明文件 {summary['declared_files']} 个；公开字节核验通过 {summary['verified_files']} 个，哈希不符 {summary['mismatched_files']} 个，缺失 {summary['missing_files']} 个，未列出 {summary['unlisted_files']} 个。其中通过核验的脱敏衍生文件 {summary['verified_redacted_derivatives']} 个。", '', '| 交接包 | 通过 | 不符 | 缺失 | 未列出 | 就绪 |', '|---|---:|---:|---:|---:|---|']
for bundle in record['bundles']:
    c = Counter(r['status'] for r in rows if r['bundle'] == bundle)
    ready = not any(c[s] for s in ('mismatch','missing','unlisted'))
    lines.append(f"| {bundle} | {c['verified']} | {c['mismatch']} | {c['missing']} | {c['unlisted']} | {'是' if ready else '否'} |")
lines += ['', '## 待处理项', '']
for r in rows:
    if r['status'] != 'verified':
        lines.append(f"- `{r['bundle']}/{r['path']}`：`{r['status']}`。" + ('需恢复符合声明公开哈希的文件。' if r['status'] in ('missing','mismatch') else '需确认交接范围；本次保留原件，不自动删除或纳入声明。'))
lines += ['', '## 证据与范围', '', '- `audit.csv` 覆盖每个声明的包/文件组合及实际未列出的文件，记录字节数、实际 SHA-256、公开哈希和原始来源哈希。缺失文件的观察字段留空，未列出文件的声明字段留空。', '- `result.json` 给出汇总及全部 raw 文件的实际 SHA-256（路径相对于 input/）；该映射包含声明记录和未列出的文件。', '- 交付字节只与 `public_sha256` 比较；`original_sha256` 保留来源关系。声明中的路径脱敏差异不构成交付不符。原始文件未提供，未独立核验原始来源哈希或脱敏操作的语义正确性。', '- 从 input/ 复制至 scratch/public-copy/ 后审计，以本地 Python hashlib 对实际字节计算 SHA-256；未执行源文件内任何命令。原始 input/ 保持不变。', '', '## 简短决定记录', '', '- 决定性未知：三个包的实际字节是否匹配同一份公开声明，以及是否有缺失或额外文件；通过逐文件哈希和目录枚举区分。', '- 采用 `learning/experience/mechanism/context-support/experience.md` 的有条件经验：将证据绑定到实际包、文件和公开版本。未采用其发票领域诊断，也不将某个包的通过结论推广到其他包。', '- 状态与发布关系独立计算：即便声明为脱敏衍生文件，实际交付仍须匹配公开哈希。保留所有不符与缺失结果；原因超出本次字节审计证据范围，不能据此归因于历史发布。', '- 后续条件：补齐缺失项、恢复不符项并明确额外文件的处置后，对修订后的完整交接重新核验。本次不修改来源或声明，也不开展额外实验。']
(out / 'report.md').write_text('\n'.join(lines) + '\n')
assert before == {p.relative_to(source).as_posix(): digest(p) for p in source.rglob('*') if p.is_file()}, 'input changed'
print(json.dumps(summary, ensure_ascii=False))
print(json.dumps([r for r in rows if r['status'] != 'verified'], ensure_ascii=False, indent=2))
