import csv, json, hashlib
from pathlib import Path
from decimal import Decimal, localcontext, ROUND_HALF_EVEN
from fractions import Fraction
from collections import Counter

root = Path('input')
out = Path('output')
raw_files = sorted((root / 'raw').rglob('*'))
hashes = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in raw_files if p.is_file()}
settings = json.loads((root/'raw/settings.json').read_text())
with (root/'raw/measurements.csv').open(newline='') as f:
    rows = list(csv.DictReader(f))
key = lambda r: (r['date'], r['station'], r['replicate'])
latest = {}
for r in rows:
    latest[key(r)] = max(latest.get(key(r), -1), int(r['revision']))

def rounded(x):
    with localcontext() as ctx:
        ctx.prec = 60
        return (Decimal(x.numerator)/Decimal(x.denominator)).quantize(Decimal('.000001'), rounding=ROUND_HALF_EVEN)

def exact_text(x):
    with localcontext() as ctx:
        ctx.prec = 60
        return format(Decimal(x.numerator)/Decimal(x.denominator), 'f')

audit = []
groups = {(d,s): [] for d in settings['dates'] for s in settings['stations']}
for r in rows:
    value = None
    if int(r['revision']) != latest[key(r)]:
        disposition = 'superseded'
    elif r['quality'] != 'ok':
        disposition = 'rejected_quality'
    elif r['reading_c'] in ('', 'NA') or r['bias_c'] in ('', 'NA'):
        disposition = 'missing_value'
    else:
        disposition = 'accepted'
        value = Fraction(Decimal(r['reading_c'])) - Fraction(Decimal(r['bias_c']))
        groups[(r['date'], r['station'])].append(value)
    audit.append({'row_id': r['row_id'], 'disposition': disposition, 'calibrated_c': '' if value is None else exact_text(value)})
means = {k: sum(v, Fraction())/len(v) if v else None for k,v in groups.items()}
station_days = [{'date': d, 'station': s, 'accepted_replicates': len(groups[d,s]), 'mean_c': '' if means[d,s] is None else str(rounded(means[d,s]))} for d,s in groups]
days = []
for d in settings['dates']:
    values = [means[d,s] for s in settings['stations'] if means[d,s] is not None]
    complete = len(values) == len(settings['stations'])
    days.append({'date': d, 'expected_stations': len(settings['stations']), 'present_stations': len(values), 'complete': complete, 'index_c': float(rounded(sum(values, Fraction())/len(values))) if complete else None})
result = {'schema': 1, 'task_id': 'primary_02', 'data_kind': 'derived_fixture_not_actual_measurements', 'source_sha256': hashes, 'summary': {'source_rows': len(rows), 'accepted_rows': sum(r['disposition']=='accepted' for r in audit), 'days': days}}
for name, data, fields in [('audit.csv',audit,['row_id','disposition','calibrated_c']), ('station-days.csv',station_days,['date','station','accepted_replicates','mean_c'])]:
    with (out/name).open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(data)
(out/'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
counts = Counter(r['disposition'] for r in audit)
(out/'report.md').write_text('''# 站点指数交接

本交付为离线分析用派生夹具（derived_fixture_not_actual_measurements），数值不是真实环境观测；单位为摄氏度距平。

- `audit.csv`：18 条源记录的判定与有效校准值。12 条 accepted，2 条 superseded，2 条 rejected_quality，2 条 missing_value。
- `station-days.csv`：3 日 × 3 站，共 9 条；有效重复先取站内均值。空均值表示没有有效重复。
- `result.json`：含输入文件 SHA-256、源行数、有效行数和每日等站权指数；严格 JSON，未知指数为 null。

2026-01-01 和 2026-01-02 均覆盖 3 站，指数分别为 0.133333、0.233333。2026-01-03 仅覆盖 2 站，Cedar 的 reading 缺失，指数为 null；须补齐有效输入后才能形成完整指数。

先选身份最高修订，再判质量与缺值；最新修订被拒绝时不回退旧记录。b1、b7 已被覆盖，b4、b8 因质量被拒绝，b3、c3 缺值。站日与指数从未舍入的精确值分别计算，最终保留六位小数，使用半偶舍入。JSON 数字可能省略尾零。

核验限于本批配置及源文件：逐行分类、配置站日覆盖、精确聚合和哈希一致性；无待解决的计算问题。未对真实观测、其他输入或生产导入系统作有效性声明。
''')
assert len(audit) == 18 and len(station_days) == 9
assert counts == {'accepted':12,'superseded':2,'rejected_quality':2,'missing_value':2}
assert [d['index_c'] for d in days] == [0.133333,0.233333,None]
assert hashes == {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in raw_files if p.is_file()}
print(json.dumps({'stage':'generated_and_checked','dispositions':dict(counts),'days':days,'source_sha256':hashes}, ensure_ascii=False, indent=2))
