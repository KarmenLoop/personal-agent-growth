# primary_02 执行记录

目标：生成逐行审计、全部配置站日、等站权每日指数和交接说明；仅为派生夹具。

执行前决定：先按 date/station/replicate 选最高 revision，再依质量、缺值判定。预测 b1、b7 被覆盖，b8 拒绝且不回退 b7；第三日缺 Cedar，指数 null。采用 Decimal 解析及 Fraction 精确聚合，最后六位四舍五入（ROUND_HALF_EVEN）。核验来源哈希、逐行数量、分类和汇总关系；失败时保存原始回执并查明阶段，不以成功标签替代检查。

已读取 learning/source-input.md、learning/experience/mechanism/context-support/experience.md 和其两份 evidence。来源任务的缓存与折扣诊断不适用于本任务，拒绝迁移其根因或结果。只采用“证据绑定具体输入和执行条件”的方法：本次重新计算并绑定 input/raw 的实际哈希，不沿用来源任务的通过结论。不存在项目 context/node/policy；本记录承担本任务局部状态。

实际结果：生成完成，stdout 见 build.stdout，stderr 见 build.stderr（空）。随后对已落盘结果执行严格 JSON 解析、源哈希回读、审计行数及仅 accepted 有校准值检查，全部通过；实际输出版本见 output-sha256.json。18 行中 12 accepted、2 superseded、2 rejected_quality、2 missing_value；前两日指数 0.133333、0.233333，第三日 null。预测与实际一致，无失败、无新根因判断。未修改 input/ 或 skill/。命令使用指定 Python 3 与 -B，范围仅本工作区离线处理，无额外实验。

经验结论：具体输入哈希和逐行判定可支撑本批交接；来源经验仅在此局部溯源实践中使用，不据此宣称跨任务通用有效。任务完成，无需用户决定；不完整日期只能等待新的有效源数据后重算。
