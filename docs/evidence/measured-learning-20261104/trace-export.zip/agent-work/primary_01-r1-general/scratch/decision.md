# primary_01 执行前决定
目标：按 publication-record.json 审计三个历史公开交接目录，生成 CSV、严格 JSON 和简短报告。
最小未决问题：每个副本的实际字节是否匹配 public_sha256，是否缺失或有额外文件；其答案决定状态及 handoff_ready。
核验：复制 input 到 scratch/public-copy，逐文件 SHA-256 和字节数，枚举声明/实际路径的并集；最后核对 CSV、汇总及原始 input 未改变。
预测：仅 original/public 不同且标记脱敏的文件不应因此被判 mismatch。是否有运输差异尚未知。
经验采用：learning/experience/mechanism/context-support/experience.md 的对象绑定原则；不迁移发票缺陷诊断，不执行其示例命令，不推定共同根因。
失败后继：若无法读取或结构不支持则保留原始错误，停止对应结论；不把未知判为 verified。范围仅本地完整性，不验证历史测试结果或真实发布。
