import csv,json,hashlib
from pathlib import Path
from collections import Counter
root=Path.cwd()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strict(p):return json.loads(p.read_text(),parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
r=strict(root/'output/result.json')
pub=strict(root/'input/raw/publication-record.json')
rows=list(csv.DictReader((root/'output/audit.csv').open(newline='')))
cols=['bundle','path','status','observed_bytes','observed_sha256','declared_public_sha256','original_sha256','publication_relation']
assert list(rows[0])==cols
assert (r['schema'],r['task_id'],r['data_kind'])==(1,'primary_01','historical_inputs_with_controlled_integrity_variants')
actual_sources={p.relative_to(root/'input').as_posix():sha(p) for p in (root/'input/raw').rglob('*') if p.is_file()}
assert r['source_sha256']==actual_sources
expected_keys=set()
for b in pub['bundles']:
    declared={f['path']:f for f in pub['files']}
    folder=root/'input/raw/bundles'/b
    names=set(declared)|{p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}
    expected_keys|={(b,name) for name in names}
    for name in names:
        matches=[v for v in rows if (v['bundle'],v['path'])==(b,name)]
        assert len(matches)==1
        v=matches[0];p=folder/name;f=declared.get(name)
        if p.is_file():
            assert v['observed_bytes']==str(len(p.read_bytes())) and v['observed_sha256']==sha(p)
        else:assert v['observed_bytes']==v['observed_sha256']==''
        if f is None:
            assert v['status']=='unlisted' and v['declared_public_sha256']==v['original_sha256']=='' and v['publication_relation']=='unknown'
        else:
            assert v['declared_public_sha256']==f['public_sha256'] and v['original_sha256']==f['original_sha256']
            assert v['status']==('missing' if not p.is_file() else 'verified' if sha(p)==f['public_sha256'] else 'mismatch')
            assert v['publication_relation']==('unchanged' if f['original_sha256']==f['public_sha256'] else 'redacted_derivative' if f['path_redacted'] else 'undocumented_difference')
assert len(rows)==len(expected_keys) and {(v['bundle'],v['path']) for v in rows}==expected_keys
c=Counter(v['status'] for v in rows)
assert r['summary']==dict(declared_files=18,verified_files=c['verified'],mismatched_files=c['mismatch'],missing_files=c['missing'],unlisted_files=c['unlisted'],verified_redacted_derivatives=sum(v['status']=='verified' and v['publication_relation']=='redacted_derivative' for v in rows),handoff_ready=c['verified']==18 and c['unlisted']==0)
receipt=strict(root/'scratch/generation-receipt.json')
assert receipt['source_sha256']==actual_sources and receipt['task_sha256']==sha(root/'input/task.md')
assert receipt['output_sha256']=={p.name:sha(p) for p in (root/'output').iterdir() if p.is_file()}
print('PASS: strict JSON; all 19 audit rows; source/public hash separation; summary; raw/task unchanged; output hashes.')
