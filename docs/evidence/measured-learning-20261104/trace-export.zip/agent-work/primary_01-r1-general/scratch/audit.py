import csv, hashlib, json, shutil, sys, platform
from pathlib import Path
from collections import Counter
root=Path.cwd()
inp=root/'input'
out=root/'output'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(base):
    return {p.relative_to(base).as_posix():sha(p) for p in sorted((base/'raw').rglob('*')) if p.is_file()}
before=snapshot(inp)
task_hash=sha(inp/'task.md')
copy=root/'scratch/public-copy'
shutil.copytree(inp,copy)
assert snapshot(copy)==before
record=json.loads((copy/'raw/publication-record.json').read_text())
cols=['bundle','path','status','observed_bytes','observed_sha256','declared_public_sha256','original_sha256','publication_relation']
rows=[]
for bundle in record['bundles']:
    folder=copy/'raw/bundles'/bundle
    declared={f['path']:f for f in record['files']}
    actual={p.relative_to(folder).as_posix():p for p in folder.rglob('*') if p.is_file()}
    for name,f in declared.items():
        relation=('unchanged' if f['original_sha256']==f['public_sha256'] else 'redacted_derivative' if f.get('path_redacted') else 'undocumented_difference')
        p=actual.get(name)
        digest=sha(p) if p is not None else ''
        rows.append(dict(zip(cols,[bundle,name,'missing' if p is None else 'verified' if digest==f['public_sha256'] else 'mismatch',p.stat().st_size if p is not None else '',digest,f['public_sha256'],f['original_sha256'],relation])))
    for name in sorted(actual.keys()-declared.keys()):
        p=actual[name]
        rows.append(dict(zip(cols,[bundle,name,'unlisted',p.stat().st_size,sha(p),'','','unknown'])))
with (out/'audit.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=cols); w.writeheader(); w.writerows(rows)
counts=Counter(r['status'] for r in rows)
summary=dict(declared_files=len(record['bundles'])*len(record['files']),verified_files=counts['verified'],mismatched_files=counts['mismatch'],missing_files=counts['missing'],unlisted_files=counts['unlisted'],verified_redacted_derivatives=sum(r['status']=='verified' and r['publication_relation']=='redacted_derivative' for r in rows),handoff_ready=all(r['status']=='verified' for r in rows))
result={'schema':1,'task_id':'primary_01','data_kind':'historical_inputs_with_controlled_integrity_variants','source_sha256':before,'summary':summary}
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
lines=['# 离线交接完整性审计','',f"结论：整体交接尚未就绪。共声明 {summary['declared_files']} 个文件，核验通过 {counts['verified']} 个、哈希不符 {counts['mismatch']} 个、缺失 {counts['missing']} 个，另有 {counts['unlisted']} 个未列出文件。",'', '| 目录 | 通过 | 不符 | 缺失 | 未列出 | 就绪 |','| --- | ---: | ---: | ---: | ---: | --- |']
for b in record['bundles']:
    c=Counter(r['status'] for r in rows if r['bundle']==b)
    lines.append(f"| {b} | {c['verified']} | {c['mismatch']} | {c['missing']} | {c['unlisted']} | {'是' if all(r['status']=='verified' for r in rows if r['bundle']==b) else '否'} |")
lines+=['','## 待处理项','']
for r in rows:
    if r['status']!='verified':
        action={'mismatch':'实际字节不匹配声明公开哈希；须核对或恢复声明的公开副本。','missing':'声明文件缺失；须补齐公开副本。','unlisted':'文件未列入声明；须确认是否移除或经正式确认后更新清单。'}[r['status']]
        lines.append(f"- `{r['bundle']}/{r['path']}`：`{r['status']}`。{action}")
lines+=['','## 范围与证据','',f"本次从 input/ 制作 scratch/public-copy/ 后只读核验副本；按 publication-record.json 的 public_sha256 判定交付字节。{summary['verified_redacted_derivatives']} 个已通过文件属于标记过路径脱敏的衍生版本。original_sha256 仅保留原始来源声明；未获取原始未脱敏字节，不能据此核实原始来源内容。",'','audit.csv 含所有声明目录/文件对及实际未列出文件，记录实测字节数、哈希、声明哈希与来源关系；缺失文件观察字段为空，未列出文件声明字段为空。publication_relation 描述声明的来源关系，不表示实际交付文件已核验。result.json 汇总结果，并记录每个实际 raw 文件（含发布记录和额外文件）的 SHA-256。','','对象为历史项目输入及受控运输变体，本结论不指称历史正式发布受损。源文件中的测试日志仅为数据；本次未执行其中命令、未重跑项目测试，不能判定业务正确性、部署状态或搬迁后的可用性。所有输入保持不变；未修复交付副本。','']
(out/'report.md').write_text('\n'.join(lines))
assert snapshot(inp)==before and sha(inp/'task.md')==task_hash
receipt={'stage':'audit artifacts generated; original input immutability checked','python':sys.version,'platform':platform.platform(),'input_unchanged':True,'task_sha256':task_hash,'summary':summary,'source_sha256':before,'output_sha256':{p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file()}}
(root/'scratch/generation-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
print('Exceptions:')
for r in rows:
    if r['status']!='verified': print(r['bundle'],r['path'],r['status'])
