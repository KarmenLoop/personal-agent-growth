# primary_01 本地审计记录

完成：交付 output/audit.csv、output/result.json、output/report.md。输入为 input/raw 的历史公开材料与受控运输变体，未修改 input。

采用来源：source-input.md、experience/mechanism/context-support/experience.md，及其 evidence/response-4.md、evidence/receipt-4.json。源经验支持将结论绑定实际输入和路径；本次仅复用此原则，不引入发票/缓存诊断，也不运行历史复现。此任务无已有 context/node 可恢复。

执行前决定与预测见 ../scratch/decision.md；实际脚本 ../scratch/audit.py，在 ../scratch/public-copy 读取工作副本。原始生成输出与错误流分别为 ../scratch/generation.stdout、../scratch/generation.stderr；对象哈希及环境见 ../scratch/generation-receipt.json。独立契约复核脚本 ../scratch/verify.py 及 ../scratch/verification.stdout、../scratch/verification.stderr 绑定相同输入、交付版本。

观察：18 个声明项，16 verified、1 mismatch、1 missing，另 1 unlisted；9 个 verified redacted derivatives。handoff-b/final-tests.stderr 不符；handoff-c/ledger-green.stderr 缺失；handoff-c/local-note.txt 未列出。handoff-a 全部通过。整体 handoff_ready=false。

判断：original_sha256 不同不推翻 public_sha256 匹配；public_sha256 不符也不自动推翻其他副本或历史来源。仅核验本地文件完整性，历史正式发布、原始未脱敏字节、日志对应业务行为与变体形成原因均未验证。失败项保留，未修复。

候选经验：审计脱敏交付时，分别记录公开字节匹配、原始来源关系与清单覆盖。适用条件为存在明确公开哈希及来源声明；本次实际采用并核验，不据此宣称其他任务或宿主已验证。下一条件：若交付副本或声明更新，应重新执行完整性核验；当前任务完成，无后台续跑。
