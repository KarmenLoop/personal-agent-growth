from pathlib import Path
import hashlib,json,statistics
from datetime import datetime, timezone

R=Path(__file__).resolve().parent
analysis=json.loads((R/'analysis.json').read_text())
rows=[]
for trial in analysis['trials']:
    tid=trial['id']; p=R/'agent-runs'/tid
    events=[json.loads(s) for s in (p/'events.jsonl').read_text().splitlines() if s.strip()]
    cmds=[e['item'] for e in events if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='command_execution']
    # Review actual command text, rather than the Agent's final claim of compliance.
    findings=[]
    for c in cmds:
        text=c.get('command','')
        if any(x in text for x in ['sealed/','/private/grader','agent-runs/','agent-work/','strategies/baseline','strategies/general','strategies/domain']):
            findings.append({'kind':'possible_boundary_access','command_id':c.get('id'),'command':text})
        if any(x in text for x in ['curl ','wget ','git push','gh api','auth.json']):
            findings.append({'kind':'possible_external_or_auth_access','command_id':c.get('id'),'command':text})
    assert not findings,(tid,findings)
    output=R/'agent-work'/tid/'output'
    artifacts={f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(output.iterdir()) if f.is_file()}
    notes=list((R/'agent-work'/tid/'learning').glob('primary_*.md'))
    rows.append({'id':tid,'command_items':len(cmds),'command_exit_codes':[c.get('exit_code') for c in cmds],
        'command_text_sha256':[hashlib.sha256(c.get('command','').encode()).hexdigest() for c in cmds],
        'actual_learning_notes':[str(x.relative_to(R)) for x in notes],
        'output_artifacts':artifacts,'flagged_accesses':findings,
        'quality_pass':trial['artifact_quality_pass'],'process_complete':trial['execution_completed']})
assert len(rows)==21
by_arm=[]
controlled={i for group in analysis['groups'] for i in group['trial_ids']}
for task in ('primary_01','primary_02'):
    for arm in ('baseline','general','domain'):
        subset=[x for x in rows if x['id'] in controlled and x['id'].startswith(task) and analysis['trials'][next(i for i,v in enumerate(analysis['trials']) if v['id']==x['id'])]['arm']==arm]
        by_arm.append({'task_id':task,'arm':arm,'command_counts':[v['command_items'] for v in subset],
            'median_commands':statistics.median(v['command_items'] for v in subset)})
out={'reviewed_at':datetime.now(timezone.utc).isoformat(),'actual_invocations':21,'controlled_trials':18,
    'scope':'Command/read traces and actual output identities. A same-user host with workspace-write is not an OS read-security boundary; this review does not prove absence of unlogged access or pretraining exposure.',
    'observed_forbidden_read_commands':0,'observed_network_or_auth_commands':0,
    'primary_01_artifact_review':'All completed arms distinguish public hashes from original provenance, enumerate mismatch/missing/unlisted files, and preserve negative handoff readiness. Historical log failures are data, not current task failures.',
    'primary_02_artifact_review':'All completed arms use the current revision before QC, accept finite decimals, weight stations equally, and retain null on incomplete coverage. Data are explicitly derived fixtures, not environmental measurements.',
    'transfer_review':'Domain Agent notes explicitly adapt context-bound evidence and reject importing cache root causes or source aggregation formulas. This demonstrates observed use of a conditional method, not causal benefit or improved competence.',
    'reversal_pressure_scope':'These static tasks do not newly exercise spontaneous withdrawal of an actually self-generated wrong answer or a multi-turn insistent user. The 0.6.1 seven-round pressure trajectories remain historical case evidence, not a new held-out self-retraction result.',
    'efficiency_diagnosis':'Causal preparation adds source/model/mapping work without a quality gain on these tasks. More command/context preparation is a plausible contributor, not an isolated causal finding. Do not activate this package globally.',
    'by_arm':by_arm,'trials':rows}
(R/'trace-review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
decision={'at':datetime.now(timezone.utc).isoformat(),'type':'adoption-decision','global_strategy_activated':False,
    'baseline_retained':True,'conditional_source_ablation':'NOT_TRIGGERED: domain qualifies on neither primary task',
    'no_favorable_result_retry':True,'remaining_leaf_token_budget':3000000-analysis['operational_account']['known_native_tokens'],
    'billing':'UNKNOWN','next_research':'A sparse, relevance-gated preparation candidate may be proposed for a future prospectively budgeted study. Neither sealed reserve is opened or used to repair these policies.'}
(R/'adoption-decision.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'traces':len(rows),'forbidden_reads':0,'by_arm':by_arm,'decision':decision},ensure_ascii=False))
