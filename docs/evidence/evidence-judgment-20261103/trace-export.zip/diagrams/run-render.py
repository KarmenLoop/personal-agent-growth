"""Capture one fresh rendering command without replacing prior receipts."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
script = root / "render-inline.mjs"
command = ["node", str(script)]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
result = subprocess.run(command, cwd=root, text=False, capture_output=True, timeout=120)
elapsed = time.monotonic() - clock
for name, data in [("stdout.txt", result.stdout), ("stderr.txt", result.stderr)]:
    with (root / name).open("xb") as target:
        target.write(data)
receipt = {
    "kind": "fresh_actual_command",
    "command_argv": command,
    "cwd": str(root),
    "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
    "started_utc": started,
    "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "elapsed_monotonic_seconds": elapsed,
    "exit_code": result.returncode,
    "stdout_path": "stdout.txt",
    "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
    "stderr_path": "stderr.txt",
    "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
}
with (root / "command-receipt.json").open("x", encoding="utf-8") as target:
    json.dump(receipt, target, indent=2)
    target.write("\n")
print(json.dumps(receipt, indent=2))
raise SystemExit(result.returncode)
