import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const output = path.dirname(fileURLToPath(import.meta.url));
const repo = '<REPO>';
const dependency = '<HOME>/Desktop/个人智能体成长系统方案/Windows桌面Agent实测-20261021-01/checks/diagrams/node_modules/mermaid';
const playwrightPath = '<HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright';
const browserPath = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const require = createRequire(import.meta.url);
const { chromium } = require(playwrightPath);
const hash = data => crypto.createHash('sha256').update(data).digest('hex');
const version = JSON.parse(await fs.readFile(path.join(dependency, 'package.json'), 'utf8')).version;
const records = [];
const server = http.createServer(async (req, res) => {
  try {
    if (req.url === '/') {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.end('<!doctype html><html><head><meta charset="utf-8"></head><body style="margin:24px;background:white"></body></html>');
      return;
    }
    const file = path.resolve(dependency, '.' + decodeURIComponent(req.url));
    if (!file.startsWith(dependency + path.sep)) throw new Error('Outside Mermaid dependency');
    res.setHeader('Content-Type', 'text/javascript');
    res.end(await fs.readFile(file));
  } catch {
    res.statusCode = 404;
    res.end('Not found');
  }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
let browser;
try {
  browser = await chromium.launch({ headless: true, executablePath: browserPath });
  const page = await browser.newPage({ viewport: { width: 1400, height: 1000 }, deviceScaleFactor: 1 });
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  await page.evaluate(async () => {
    window.mermaid = (await import('/dist/mermaid.esm.min.mjs')).default;
    window.mermaid.initialize({
      startOnLoad: false, securityLevel: 'strict', theme: 'base',
      themeVariables: {
        fontFamily: 'Arial, "PingFang SC", "Microsoft YaHei", sans-serif',
        fontSize: '18px', primaryColor: '#e4eefb', primaryTextColor: '#14273d',
        lineColor: '#526d86', tertiaryColor: '#eef5ef'
      },
      flowchart: { htmlLabels: false, useMaxWidth: false, curve: 'basis' }
    });
  });
  for (const language of ['en', 'zh-CN']) {
    const relative = `docs/reasoning.${language}.md`;
    const bytes = await fs.readFile(path.join(repo, relative));
    const matches = [...bytes.toString('utf8').matchAll(/```mermaid\n([\s\S]*?)\n```/g)];
    if (matches.length !== 1) throw new Error(`Expected one inline diagram in ${relative}`);
    const source = matches[0][1] + '\n';
    const stem = `evidence-judgment.${language}`;
    await fs.writeFile(path.join(output, stem + '.mmd'), source, { flag: 'wx' });
    const result = await page.evaluate(async source => {
      document.body.innerHTML = '';
      const parsed = await window.mermaid.parse(source);
      const { svg } = await window.mermaid.render('diagram', source);
      document.body.innerHTML = svg;
      const element = document.querySelector('svg');
      const view = element.viewBox.baseVal;
      const labels = [...element.querySelectorAll('text')];
      const clipped = labels.filter(label => {
        const box = label.getBoundingClientRect();
        const bounds = element.getBoundingClientRect();
        return box.left < bounds.left - 1 || box.right > bounds.right + 1 ||
          box.top < bounds.top - 1 || box.bottom > bounds.bottom + 1;
      }).map(label => label.textContent);
      return {
        svg, diagram_type: parsed.diagramType,
        width: view.width, height: view.height,
        nodes: element.querySelectorAll('.node').length,
        edges: element.querySelectorAll('.flowchart-link').length,
        text_labels: labels.length, labels_outside_svg: clipped
      };
    }, source);
    if (result.nodes !== 12 || result.edges !== 14 || result.width <= 0 || result.height <= 0 || result.labels_outside_svg.length) {
      throw new Error('Unexpected rendered structure: ' + JSON.stringify({ ...result, svg: undefined }));
    }
    const svg = result.svg + '\n';
    await fs.writeFile(path.join(output, stem + '.svg'), svg, { flag: 'wx' });
    await page.locator('svg').screenshot({ path: path.join(output, stem + '.png') });
    const record = {
      source_document: relative, source_document_sha256: hash(bytes),
      source: stem + '.mmd', source_sha256: hash(source),
      svg: stem + '.svg', svg_sha256: hash(svg),
      screenshot: stem + '.png', screenshot_sha256: hash(await fs.readFile(path.join(output, stem + '.png'))),
      ...result
    };
    delete record.svg;
    record.svg = stem + '.svg';
    records.push(record);
    console.log(JSON.stringify(record));
  }
  const manifest = {
    scope: 'Actual fresh Chromium rendering of the current inline diagrams; not Agent behavior validation',
    mermaid_version: version, playwright_path: playwrightPath, browser_path: browserPath,
    browser_version: browser.version(), node_version: process.version, diagrams: records
  };
  await fs.writeFile(path.join(output, 'render-result.json'), JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' });
} finally {
  if (browser) await browser.close();
  await new Promise(resolve => server.close(resolve));
}
