# Earlier validation: retrospective summary

This note was written after the original tool calls. It is a summary of their returned results, not preserved raw stdout/stderr or a claim that those earlier scripts were saved.

- The first pure Node Mermaid parse exited 1 with `TypeError: purify.addHook is not a function`, a DOMPurify environment problem.
- A subsequent headless Chromium execution actually parsed and rendered both inline diagrams. The tool returned exit 0 and 12 nodes for each diagram. It reported English dimensions 896 × 1849.5625 and Chinese dimensions 891.84375 × 1600.5625.
- That earlier script selected `.edgePath`, which returned 0. The selector result was not evidence of an absent edge or a valid edge count.
- `render-inline.mjs`, `run-render.py`, and their receipts in this directory belong to a new, actual run. Its explicit rendering theme can change dimensions. It uses `.flowchart-link` to inspect rendered edges and retains standalone outputs.

No original repository diagram, publication manifest, or historical receipt is changed by this rendering task.
