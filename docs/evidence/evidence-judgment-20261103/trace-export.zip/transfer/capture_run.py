"""Capture exact task-local subprocess receipts without replacing earlier runs."""
import hashlib
import json
import platform
import shlex
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def hashes():
    names = ["campaign.csv", "memory.md", "task.md", "intake.json", "report.py",
             "report.before.py", "verify_metric.py", "verify_csv.py", "verify_delivery.py", "capture_run.py",
             "precision_probe.py", "result.csv", "run-record.md", "response.md",
             "skill/SKILL.md", "skill/references/task-record.md",
             "skill/references/evidence-based-judgment.md",
             "skill/references/adaptive-learning.md", "skill/references/learning-and-contact.md"]
    return {name: digest(ROOT / name) for name in names if (ROOT / name).is_file()}


def main():
    mode = sys.argv[1]
    if mode == "init":
        original = (ROOT / "report.py").read_bytes()
        with (ROOT / "report.before.py").open("xb") as saved:
            saved.write(original)
        intake = json.loads((ROOT / "intake.json").read_text())
        for name in ("report.py", "campaign.csv", "memory.md", "task.md"):
            assert digest(ROOT / name) == intake["inputs"][name], name
        data = {
            "task": "visitor-weighted overall conversion rate",
            "cwd": str(ROOT),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "environment": {"python": sys.executable, "version": sys.version,
                            "platform": platform.platform()},
            "original_hashes": hashes(), "attempts": [],
            "limits": [
                "Receipts capture every metric experiment and artifact validation launched through capture_run.py; setup/inspection tool calls remain in the host transcript.",
                "Two disjoint cohorts and one conversion indicator per visitor are the supplied metric contract; person-level deduplication was not independently audited.",
                "This is a task-local repair and semantic check, not a matched agent comparison, cross-host acceptance, skill-wide proof, or external deployment.",
                "Original incorrect runtime output and semantic failures remain attached to report.before.py; a zero process exit does not establish metric correctness.",
                "Skill learning helper scripts were absent; their discovery failed before execution, not at business validation.",
                "Native tokens and monetary cost were not supplied by the host and remain unknown."
            ],
            "native_tokens": None, "monetary_cost": None,
            "initial_inspection": {"records": "Host tool transcript; not reconstructed as local raw output",
                                   "helper_discovery_exit": 1,
                                   "helper_discovery_stderr": "rg: skill/scripts: IO error for operation on skill/scripts: No such file or directory (os error 2)\n"}
        }
        with (ROOT / "receipt.json").open("x", encoding="utf-8") as out:
            json.dump(data, out, ensure_ascii=False, indent=2)
            out.write("\n")
        print("Saved report.before.py; original input hashes match intake.json.")
        return

    label, command = sys.argv[2], sys.argv[3:]
    if mode != "run" or not command:
        raise SystemExit("usage: capture_run.py run LABEL COMMAND [ARG ...]")
    receipt_path = ROOT / "receipt.json"
    data = json.loads(receipt_path.read_text())
    if any(item["id"] == label for item in data["attempts"]):
        raise SystemExit("Refusing to replace an existing attempt")
    before = hashes()
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    entry = {"id": label, "argv": command, "command": shlex.join(command),
             "cwd": str(ROOT), "started_at": started,
             "ended_at": datetime.now(timezone.utc).isoformat(),
             "stdout": result.stdout, "stderr": result.stderr,
             "exit_code": result.returncode, "hashes_before": before, "hashes_after": hashes()}
    attempt_path = ROOT / f"{label}.receipt.json"
    with attempt_path.open("x", encoding="utf-8") as out:
        json.dump(entry, out, ensure_ascii=False, indent=2)
        out.write("\n")
    data["attempts"].append(entry)
    data["current_hashes"] = hashes()
    receipt_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"id": label, "exit_code": result.returncode,
                      "stdout": result.stdout, "stderr": result.stderr}, ensure_ascii=False))


if __name__ == "__main__":
    main()
