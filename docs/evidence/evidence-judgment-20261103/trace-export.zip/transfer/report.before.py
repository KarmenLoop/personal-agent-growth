import csv
from pathlib import Path

def overall_conversion(rows):
    return sum(int(row["conversions"]) / int(row["visitors"]) for row in rows) / len(rows)

if __name__ == "__main__":
    rows = list(csv.DictReader(Path(__file__).with_name("campaign.csv").open()))
    print(overall_conversion(rows))
