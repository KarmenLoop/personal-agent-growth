"""Compare both hypotheses in exact rational arithmetic."""
import csv
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path

rows = list(csv.DictReader(Path(__file__).with_name("campaign.csv").open()))
group_mean = sum(Fraction(int(r["conversions"]), int(r["visitors"])) for r in rows) / len(rows)
visitor_rate = Fraction(sum(int(r["conversions"]) for r in rows), sum(int(r["visitors"]) for r in rows))
print(f"Exact mean of cohort rates: {group_mean}")
print(f"Exact overall visitor rate: {visitor_rate}")
print(f"Exact difference: {group_mean - visitor_rate}")
with localcontext() as ctx:
    ctx.prec = 60
    print(f"Old formula at 60 decimal places: {Decimal(group_mean.numerator) / Decimal(group_mean.denominator):.60f}")
assert group_mean != visitor_rate, "The exact arithmetic must distinguish the formulas"
print("PASS: rounding-only hypothesis rejected by exact arithmetic")
