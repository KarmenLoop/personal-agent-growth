"""Check the emitted artifact, protected inputs, and preserved old source."""
import csv
import hashlib
import json
from decimal import Decimal
from pathlib import Path

root = Path(__file__).resolve().parent
intake = json.loads((root / "intake.json").read_text())
for name in ("campaign.csv", "memory.md", "task.md"):
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == intake["inputs"][name], name
assert hashlib.sha256((root / "report.before.py").read_bytes()).hexdigest() == intake["inputs"]["report.py"]
with (root / "result.csv").open(newline="") as source:
    rows = list(csv.DictReader(source))
assert len(rows) == 1
row = rows[0]
assert row["metric"] == "overall_visitor_conversion"
assert int(row["visitors"]) == 1000
assert int(row["conversions"]) == 107
assert Decimal(row["conversion_rate"]) == Decimal("0.107")
assert Decimal(row["conversion_percent"]) == Decimal("10.7")
print("PASS: result.csv reports 107 conversions / 1000 visitors = 0.107 = 10.7%")
print("PASS: campaign.csv, memory.md, task.md retain intake hashes; report.before.py preserves the exact original source")
