import argparse
import csv
from pathlib import Path


def overall_conversion(rows):
    """Return conversions per visitor across disjoint cohorts."""
    total_visitors = 0
    total_conversions = 0
    for row in rows:
        total_visitors += int(row["visitors"])
        total_conversions += int(row["conversions"])
    return total_conversions / total_visitors


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Report overall visitor conversion.")
    parser.add_argument("--output", type=Path, help="Write the overall metric as CSV.")
    args = parser.parse_args()
    with Path(__file__).with_name("campaign.csv").open(newline="", encoding="utf-8") as source:
        rows = list(csv.DictReader(source))
    rate = overall_conversion(rows)
    print(rate)
    if args.output is not None:
        summary = {
            "metric": "overall_visitor_conversion",
            "visitors": sum(int(row["visitors"]) for row in rows),
            "conversions": sum(int(row["conversions"]) for row in rows),
            "conversion_rate": rate,
            "conversion_percent": rate * 100,
        }
        with args.output.open("w", newline="", encoding="utf-8") as output:
            writer = csv.DictWriter(output, fieldnames=list(summary))
            writer.writeheader()
            writer.writerow(summary)
