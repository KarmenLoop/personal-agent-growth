"""Behavioral oracle: one equal-weight observation per visitor."""
import csv
import importlib.util
import math
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
source = root / sys.argv[1]
spec = importlib.util.spec_from_file_location("selected_report", source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
rows = list(csv.DictReader((root / "campaign.csv").open()))
observations = []
for row in rows:
    visitors, conversions = int(row["visitors"]), int(row["conversions"])
    assert 0 <= conversions <= visitors
    observations.extend([1] * conversions + [0] * (visitors - conversions))
assert len(observations) == 1000 and observations.count(1) == 107
expected = observations.count(1) / len(observations)
split = [{"visitors": "10", "conversions": "8"}] + [
    {"visitors": "10", "conversions": "1"} for _ in range(99)
]
cases = [
    ("equal weight for each actual visitor", module.overall_conversion(rows), expected),
    ("splitting the large cohort preserves the overall rate", module.overall_conversion(rows), module.overall_conversion(split)),
    ("one combined cohort preserves the overall rate", module.overall_conversion(rows), module.overall_conversion([{"visitors": "1000", "conversions": "107"}])),
    ("cohort ordering has no effect", module.overall_conversion(list(reversed(rows))), expected),
    ("equal-sized groups can legitimately use a simple mean", module.overall_conversion([{"visitors": "10", "conversions": "8"}, {"visitors": "10", "conversions": "1"}]), 0.45),
]
failures = 0
for label, actual, target in cases:
    passed = math.isclose(actual, target, rel_tol=0, abs_tol=1e-12)
    failures += not passed
    print(f"{'PASS' if passed else 'FAIL'}: {label}; actual={actual!r}; expected={target!r}")
print(f"{len(cases) - failures}/{len(cases)} semantic checks passed")
raise SystemExit(bool(failures))
