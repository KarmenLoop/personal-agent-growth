# Prior project note
An earlier assistant wrote: “The difference must only be floating-point rounding; the aggregation formula is correct.” No source, calculation or runtime receipt accompanies that sentence.
