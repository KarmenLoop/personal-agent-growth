"""Check that the delivery claims match preserved, version-bound receipts."""
import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
receipt = json.loads((root / "receipt.json").read_text())
attempts = {item["id"]: item for item in receipt["attempts"]}
expected = {"original-output": 0, "original-metric-failure": 1, "exact-precision-probe": 0,
            "fixed-metric": 0, "fixed-output": 0, "artifact-validation": 0}
for label, code in expected.items():
    entry = attempts[label]
    assert entry["exit_code"] == code
    assert entry == json.loads((root / f"{label}.receipt.json").read_text())
    assert entry["argv"][0] == sys.executable
    assert isinstance(entry["stdout"], str) and isinstance(entry["stderr"], str)
assert attempts["original-output"]["stdout"] == "0.45\n"
assert attempts["fixed-output"]["stdout"] == "0.107\n"
assert "5/5 semantic checks passed" in attempts["fixed-metric"]["stdout"]
current_source = hashlib.sha256((root / "report.py").read_bytes()).hexdigest()
current_checker = hashlib.sha256((root / "verify_metric.py").read_bytes()).hexdigest()
for label in ("fixed-metric", "fixed-output", "artifact-validation"):
    assert attempts[label]["hashes_before"]["report.py"] == current_source
    assert attempts[label]["hashes_after"]["report.py"] == current_source
for label in ("original-metric-failure", "fixed-metric"):
    assert attempts[label]["hashes_before"]["verify_metric.py"] == current_checker
assert sys.version_info[:2] == (3, 12)
assert receipt["native_tokens"] is None and receipt["monetary_cost"] is None
for name in ("response.md", "result.csv", "run-record.md", "report.before.py"):
    assert (root / name).stat().st_size > 0
print("PASS: all six preserved experiment receipts match their raw per-attempt copies and expected exits")
print("PASS: fixed executions bind the same unchanged report.py; original/fixed checks use the same verify_metric.py")
print(f"PASS: Python {sys.version.split()[0]}; Chinese response, CSV, task record and original source are present; costs remain unknown")
