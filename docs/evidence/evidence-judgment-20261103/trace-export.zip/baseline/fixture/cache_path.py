from invoice import total_cents

_cache = {}

def quote(customer_id, items_cents, shipping_cents, discount_percent):
    items = tuple(items_cents)
    key = (customer_id, items, shipping_cents, discount_percent)
    if key in _cache:
        return {"amount": _cache[key], "cache_hit": True}
    amount = total_cents(items, shipping_cents, discount_percent)
    _cache[key] = amount
    return {"amount": amount, "cache_hit": False}
