from cache_path import quote

first = quote("customer-7", [10000], 0, 10)
second = quote("customer-7", [20000], 0, 10)
expected_second = 18000
print({"first": first, "second": second, "expected_second": expected_second})
assert second["amount"] == expected_second, second
