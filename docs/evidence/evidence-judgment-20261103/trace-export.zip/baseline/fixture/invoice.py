def total_cents(items_cents, shipping_cents, discount_percent):
    subtotal = sum(items_cents)
    return subtotal * (100 - discount_percent) // 100 + shipping_cents
