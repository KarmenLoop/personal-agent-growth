from invoice import total_cents
expected = sum([10000]) * 90 // 100 + 1000
actual = total_cents([10000], 1000, 10)
print({"order": "A", "expected": expected, "actual": actual})
assert actual == expected, (actual, expected)
