# Invoice contract
Amounts are integer cents. A percentage discount applies to merchandise only.
Round the discounted merchandise down to integer cents, then add the full shipping charge.
Example order A: merchandise [10000], shipping 1000, discount 10.
The caller in this incident invokes invoice.total_cents directly. The trace is a captured reproduction, not production telemetry.
