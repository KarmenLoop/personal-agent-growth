from pathlib import Path
import sys

root=Path(__file__).resolve().parent
arm=sys.argv[1]
assert arm in ('baseline','candidate')
folder=root/arm/'fixture'
(folder/'cache_path.py').write_text('''from invoice import total_cents

_cache = {}

def quote(customer_id, items_cents, shipping_cents, discount_percent):
    if customer_id in _cache:
        return {"amount": _cache[customer_id], "cache_hit": True}
    amount = total_cents(items_cents, shipping_cents, discount_percent)
    _cache[customer_id] = amount
    return {"amount": amount, "cache_hit": False}
''')
(folder/'reproduce_cache.py').write_text('''from cache_path import quote

first = quote("customer-7", [10000], 0, 10)
second = quote("customer-7", [20000], 0, 10)
expected_second = 18000
print({"first": first, "second": second, "expected_second": expected_second})
assert second["amount"] == expected_second, second
''')
print('Added new controlled evidence for '+arm)
