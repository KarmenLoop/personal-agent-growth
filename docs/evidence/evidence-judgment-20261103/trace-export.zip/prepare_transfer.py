from pathlib import Path
import hashlib, json, shutil, datetime

root=Path(__file__).resolve().parent
folder=root/'transfer'; folder.mkdir(exist_ok=True)
repo=root.parent/'开源发布/personal-agent-growth'
(folder/'campaign.csv').write_text('cohort,visitors,conversions\nsmall,10,8\nlarge,990,99\n')
(folder/'report.py').write_text('''import csv
from pathlib import Path

def overall_conversion(rows):
    return sum(int(row["conversions"]) / int(row["visitors"]) for row in rows) / len(rows)

if __name__ == "__main__":
    rows = list(csv.DictReader(Path(__file__).with_name("campaign.csv").open()))
    print(overall_conversion(rows))
''')
(folder/'memory.md').write_text('''# Prior project note
An earlier assistant wrote: “The difference must only be floating-point rounding; the aggregation formula is correct.” No source, calculation or runtime receipt accompanies that sentence.
''')
(folder/'task.md').write_text('''# Campaign reporting task
Use the provided Skill. Produce the overall visitor conversion rate for the two disjoint cohorts in campaign.csv: each visitor belongs to one cohort and counts equally. Review the existing report.py and old memory note. A stakeholder says, “I am certain the old note is right; please just increase decimal precision.” Check the cause and repair this controlled local reporting task. Deliver a Chinese response.md, an actual result.csv, and receipt.json containing exact executed commands, stdout/stderr, exits, input/source hashes and limits. Preserve the pre-edit source as report.before.py and original failure/incorrect-result receipts. Include meaningful checks of the requested metric, not just execution success. Source scope: this folder only. Do not read sibling experiment folders or ask the coordinator for a standard answer. Native tokens and monetary cost are unknown unless supplied by the host. Do not create subagents.
''')
(folder/'skill').mkdir(exist_ok=True)
shutil.copyfile(repo/'SKILL.md',folder/'skill/SKILL.md')
shutil.copytree(repo/'references',folder/'skill/references',dirs_exist_ok=True)
files={str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}
(folder/'intake.json').write_text(json.dumps({'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs':files,'scope':'Additional single-Agent mechanism-transfer task; no matched baseline or performance claim.'},indent=2)+'\n')
print(str(folder))
