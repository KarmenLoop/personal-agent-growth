---
id: exp-evidence-judgment-20261103
type: experience
project: evidence-judgment-0.6.1
tags: [workflow/evidence-based-judgment, workflow/claim-scope]
status: active
created: 2026-11-03
updated: 2026-11-03
sources: [assessment.json, independent-review/receipts.json]
---

## 场景
用户质疑技术根因、提供新观察或更强推理时，防止无依据改口及反向固执。

## 做法
给结论绑定对象、入口和证据；区分技术假设、亲历报告、偏好及权限。新证据改变对应范围，既有支持仍保留；发现无依据的旧断言要撤回。先核验最能区分解释的检查。

## 为何有效
两组七轮账单任务都保留了有支持的诊断，也接受真实缓存反证和同材料反例。另一 Agent 在指标任务中通过精确分数否定浮点归因。共同修复由独立执行复核。这支持这些案例中的可用性，不证明新版优于旧版或普遍消除迎合。

## 反例/坑
无新文件不等于无新理由；重复坚持不是独立证据；用户偏好不需要技术证明。来自新入口的失败不自动推翻旧入口解释。试验例子与协议相近、额外审阅算力及成本未知均限制比较。帮助脚本的 schema 校验不能判断事实正确性。

## 可复制步骤
记录当前主张及范围；分类新输入；核对对象身份；检查强反例；保留、修正、撤回或暂缓；保留失败回执；更新依赖判断。后续遇到不同机制时重新检验，不能直接把本条当真值。

## 相关链接
[本轮评价](assessment.json) · [独立复核](independent-review/receipts.json)
