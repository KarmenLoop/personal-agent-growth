---
{"id": "smoke-request", "type": "learning-request", "goal": "Verify installed adaptive helper and retained Markdown", "domain": "package-installation", "acceptance": ["helper starts"], "budget_seconds": 300, "max_actions": 2, "allowed_actions": ["research", "deliver"]}
---
Installed helper smoke.
