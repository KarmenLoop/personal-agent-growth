---
{"id": "empty-query", "type": "transfer-query", "task_id": "installed-smoke", "domain": "installation", "problem_structure": ["artifact-identity"], "mechanisms": ["evidence-binding"], "facts": {}, "keywords": []}
---
Empty library expected.
