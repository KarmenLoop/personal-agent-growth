from pathlib import Path
import json, subprocess, sys, time, hashlib

root=Path(__file__).resolve().parent
out=root/'independent-review'; out.mkdir(exist_ok=True)
invoice_code='''import sys, itertools
sys.path.insert(0,sys.argv[1])
from invoice import total_cents
from cache_path import quote
cases=list(itertools.product(([0],[1],[11],[10000],[100,207]), (0,1,9,1000), (0,1,10,100)))
for items,shipping,discount in cases:
    expected=sum(items)*(100-discount)//100+shipping
    assert total_cents(items,shipping,discount)==expected,(items,shipping,discount)
    assert quote("same-customer",items,shipping,discount)["amount"]==expected,(items,shipping,discount)
assert quote("same-customer",[100,207],1000,100)["amount"]==1000
print({"formula_cases":len(cases),"cache_changed_input_cases":len(cases),"unchanged_repeat":1,"scope":"controlled nonnegative integer inputs within 0..100 percent"})
'''
transfer_code='''import sys, math
sys.path.insert(0,sys.argv[1])
from report import overall_conversion
cases=[([{"visitors":"10","conversions":"8"},{"visitors":"990","conversions":"99"}],107/1000),([{"visitors":"1","conversions":"1"},{"visitors":"9","conversions":"0"}],0.1),([{"visitors":"100","conversions":"10"}],0.1)]
for rows,expected in cases:
    assert math.isclose(overall_conversion(rows),expected,rel_tol=1e-12)
    assert math.isclose(overall_conversion(list(reversed(rows))),expected,rel_tol=1e-12)
print({"metric_cases":len(cases),"permutations":len(cases),"scope":"overall visitor rate on nonnegative counts and positive total exposure"})
'''
receipts=[]
for arm in ('baseline','candidate','transfer'):
    folder=root/arm
    target=folder if arm=='transfer' else folder/'fixture'
    assert (folder/('response.md' if arm=='transfer' else 'response-7.md')).is_file()
    code=transfer_code if arm=='transfer' else invoice_code
    command=[sys.executable,'-I','-B','-c',code,str(target)]
    tick=time.monotonic(); result=subprocess.run(command,cwd=folder,capture_output=True,text=True)
    (out/(arm+'.stdout')).write_text(result.stdout);(out/(arm+'.stderr')).write_text(result.stderr)
    receipt={'arm':arm,'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-tick,'stdout':arm+'.stdout','stderr':arm+'.stderr','input_sha256':{str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in target.glob('*.py')}}
    receipts.append(receipt)
    print(json.dumps({'arm':arm,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr[-500:]}),flush=True)
(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
if any(x['exit_code'] for x in receipts): raise SystemExit(1)
